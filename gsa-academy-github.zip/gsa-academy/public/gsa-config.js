// Default backend address baked into the Android APK.
// Change it in the login screen -> "Server address" if your PC uses a different Wi-Fi IP.
window.__GSA_API_BASE__ = 'http://10.161.243.49:4000';
