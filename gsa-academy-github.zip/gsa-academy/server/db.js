import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, scryptSync } from 'node:crypto';

const dbPath = resolve(fileURLToPath(new URL('../data/gsa.db', import.meta.url)));
mkdirSync(dirname(dbPath), { recursive: true });

export const db = new DatabaseSync(dbPath);
db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  email TEXT,
  role TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username) WHERE username IS NOT NULL;

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  student_code TEXT UNIQUE,
  name TEXT NOT NULL,
  age INTEGER,
  body TEXT,
  place_of_birth TEXT,
  identification_mark TEXT,
  address TEXT,
  email TEXT,
  phone TEXT,
  father_name TEXT,
  father_phone TEXT,
  father_email TEXT,
  father_address TEXT,
  father_occupation TEXT,
  mother_name TEXT,
  mother_phone TEXT,
  mother_email TEXT,
  mother_address TEXT,
  mother_occupation TEXT,
  joined_date TEXT,
  ongoing_years INTEGER,
  sport TEXT,
  staff_id INTEGER,
  school_name TEXT,
  school_details TEXT,
  college_name TEXT,
  college_details TEXT,
  academic_year TEXT,
  remarks TEXT,
  regular_medicine TEXT,
  allergy TEXT,
  surgery TEXT,
  health_issues TEXT,
  damage TEXT,
  equipment_purchased TEXT,
  fees_pending REAL DEFAULT 0,
  prize_photo TEXT,
  status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS staff (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  age INTEGER,
  body TEXT,
  place TEXT,
  experience TEXT,
  category TEXT,
  achievement TEXT,
  sports TEXT,
  previously_worked TEXT,
  status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id INTEGER NOT NULL,
  module TEXT NOT NULL,
  can_view INTEGER NOT NULL DEFAULT 1,
  can_edit INTEGER NOT NULL DEFAULT 0,
  UNIQUE(staff_id, module)
);

CREATE TABLE IF NOT EXISTS sports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  types TEXT NOT NULL DEFAULT '[]',
  icon TEXT,
  color TEXT,
  description TEXT
);

CREATE TABLE IF NOT EXISTS achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  sport TEXT,
  category1 TEXT,
  category2 TEXT,
  medal TEXT,
  match_name TEXT,
  match_date TEXT,
  match_details TEXT,
  prize_photo TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  sport TEXT,
  type TEXT,
  amount REAL NOT NULL DEFAULT 0,
  paid_amount REAL NOT NULL DEFAULT 0,
  units TEXT,
  period TEXT,
  due_date TEXT,
  status TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS income (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  sport TEXT,
  amount REAL NOT NULL DEFAULT 0,
  date TEXT NOT NULL,
  description TEXT,
  ref_type TEXT,
  ref_id INTEGER,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sport TEXT NOT NULL,
  item TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  unit TEXT DEFAULT 'pcs',
  unit_price REAL NOT NULL DEFAULT 0,
  reorder_level INTEGER NOT NULL DEFAULT 5,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS equipment_txns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sport TEXT NOT NULL,
  item TEXT NOT NULL,
  qty INTEGER NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  party TEXT,
  date TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  audience TEXT NOT NULL DEFAULT 'all',
  date TEXT NOT NULL,
  author TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  event TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  location TEXT,
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS leaves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  from_date TEXT NOT NULL,
  to_date TEXT NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS queries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'query',
  message TEXT NOT NULL,
  reply TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  audience TEXT NOT NULL DEFAULT 'user',
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  read INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  message TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  reply TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  role TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  details TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS password_resets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL,
  role TEXT NOT NULL,
  code TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`);

export function run(sql, params = []) {
  return db.prepare(sql).run(...params);
}

export function all(sql, params = []) {
  return db.prepare(sql).all(...params);
}

export function get(sql, params = []) {
  return db.prepare(sql).get(...params) || null;
}

export const query = all;

export const MODULES = [
  'students', 'achievements', 'fees', 'attendance', 'stock',
  'finance', 'reports', 'announcements', 'queries'
];

function hashPassword(pw) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(String(pw), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function seed() {
  let state = 20261124;
  const rnd = () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const int = (a, b) => a + Math.floor(rnd() * (b - a + 1));
  const now = new Date();
  const iso = (d = now) => d.toISOString();
  const day = (offset) => iso(new Date(now.getTime() - offset * 86400000)).slice(0, 10);
  const timeStamp = (h, m) => `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;

  function insert(table, obj) {
    const keys = Object.keys(obj);
    return run(
      `INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
      keys.map((k) => obj[k] ?? null)
    );
  }

  const sportsData = [
    { name: 'Chess', types: ['Classical', 'Rapid', 'Blitz', 'Team'], icon: '♟️', color: '#6366f1', description: 'Classical and rapid chess training with regular rated practice and tournaments.' },
    { name: 'Carrom', types: ['Singles', 'Doubles', 'Team'], icon: '🎯', color: '#f59e0b', description: 'Precision carrom coaching for singles, doubles and team formats.' },
    { name: 'Yoga', types: ['Hatha', 'Vinyasa', 'Power Yoga', 'Meditation'], icon: '🧘', color: '#10b981', description: 'Yoga and mindfulness sessions building flexibility, balance and focus.' },
    { name: 'Drawing', types: ['Sketching', 'Watercolour', 'Acrylic', 'Portrait'], icon: '🎨', color: '#ec4899', description: 'Creative drawing and painting classes for all age groups.' },
    { name: 'Fencing', types: ['Foil', 'Épée', 'Sabre', 'Team Foil'], icon: '🤺', color: '#0ea5e9', description: 'Flagship Olympic fencing programme with foil, épée and sabre coaching.' },
    { name: 'Cricket', types: ['U-12', 'U-14', 'U-16', 'T20'], icon: '🏏', color: '#22c55e', description: 'Cricket skills development with batting, bowling and match simulation.' },
    { name: 'Archery', types: ['Recurve', 'Compound', 'Barebow', 'Team'], icon: '🏹', color: '#a855f7', description: 'Archery technique, concentration and competitive range practice.' },
    { name: 'Table Tennis', types: ['Singles', 'Doubles', 'Mixed Doubles', 'Team'], icon: '🏓', color: '#ef4444', description: 'Fast-paced table tennis drills, footwork and tournament preparation.' }
  ];
  const sportIds = {};
  for (const s of sportsData) {
    const r = insert('sports', { ...s, types: JSON.stringify(s.types) });
    sportIds[s.name] = Number(r.lastInsertRowid);
  }

  const ownerId = Number(insert('users', {
    username: 'owner', email: 'globalsportsnkl@gmail.com', role: 'owner',
    password_hash: hashPassword('9042999507'), name: 'Academy Owner',
    status: 'active', created_at: iso()
  }).lastInsertRowid);

  const staffData = [
    { name: 'Ravi Kumar', age: 34, body: 'Athletic', place: 'Delhi', experience: '12 years', category: 'Head Coach - Fencing', achievement: 'Gold, National Fencing Championship 2019', sports: ['Fencing'], previously_worked: 'Sports Authority of India' },
    { name: 'Priya Sharma', age: 29, body: 'Slim', place: 'Pune', experience: '8 years', category: 'Yoga & Chess Coach', achievement: 'State Yoga Champion 2021, FIDE rated player', sports: ['Yoga', 'Chess'], previously_worked: 'Pune Yoga Academy' },
    { name: 'Arjun Mehta', age: 38, body: 'Strong', place: 'Mumbai', experience: '15 years', category: 'Cricket & Archery Coach', achievement: 'Coached U-16 state cricket team', sports: ['Cricket', 'Archery'], previously_worked: 'Mumbai Cricket Association' },
    { name: 'Sneha Iyer', age: 31, body: 'Athletic', place: 'Chennai', experience: '9 years', category: 'Fencing & Table Tennis Coach', achievement: 'Silver, South Asian Épée Meet 2022', sports: ['Fencing', 'Table Tennis'], previously_worked: 'Chennai Sports Club' },
    { name: 'Vikram Singh', age: 41, body: 'Strong', place: 'Jaipur', experience: '18 years', category: 'Fencing & Carrom Coach', achievement: 'National Sabre Medallist 2016', sports: ['Fencing', 'Carrom'], previously_worked: 'Rajasthan Sports Council' },
    { name: 'Anjali Rao', age: 27, body: 'Slim', place: 'Bengaluru', experience: '6 years', category: 'Drawing & Yoga Coach', achievement: 'State Art Exhibition Award 2023', sports: ['Drawing', 'Yoga'], previously_worked: 'Bengaluru Art Foundation' }
  ];
  const staffIds = [];
  const staffUserIds = [];
  staffData.forEach((s, i) => {
    const email = ['ravi.kumar', 'priya.sharma', 'arjun.mehta', 'sneha.iyer', 'vikram.singh', 'anjali.rao'][i] + '@gsa.ac.in';
    const uid = Number(insert('users', {
      username: email, email, role: 'staff',
      password_hash: hashPassword('Coach@123'), name: s.name,
      status: 'active', created_at: iso()
    }).lastInsertRowid);
    const sid = Number(insert('staff', {
      user_id: uid, ...s, sports: JSON.stringify(s.sports), status: 'active'
    }).lastInsertRowid);
    staffUserIds.push(uid);
    staffIds.push(sid);
    for (const module of MODULES) {
      insert('permissions', { staff_id: sid, module, can_view: 1, can_edit: 0 });
    }
  });

  const studentSeed = [
    ['Aarav Sharma', 15, 'Bengaluru', 'Fencing', 0, 'Right elbow scar'],
    ['Diya Nair', 13, 'Kochi', 'Fencing', 3, 'Small mole on left cheek'],
    ['Rohan Verma', 17, 'Delhi', 'Fencing', 0, 'Left knee scar'],
    ['Ishita Patel', 14, 'Ahmedabad', 'Fencing', 4, 'Birth mark on right shoulder'],
    ['Kabir Malhotra', 16, 'Chandigarh', 'Fencing', 0, 'Scar on right thumb'],
    ['Meera Iyer', 12, 'Chennai', 'Fencing', 3, 'Small scar near left eye'],
    ['Aditya Rao', 18, 'Pune', 'Fencing', 4, 'Mole on neck'],
    ['Sania Qureshi', 15, 'Hyderabad', 'Fencing', 0, 'Left wrist mark'],
    ['Vivaan Joshi', 11, 'Nagpur', 'Chess', 1, 'Scar on forehead'],
    ['Ananya Das', 14, 'Kolkata', 'Yoga', 5, 'Mole on right cheek'],
    ['Arnav Gupta', 16, 'Jaipur', 'Cricket', 2, 'Scar on left arm'],
    ['Riya Hegde', 13, 'Mangaluru', 'Archery', 2, 'Birth mark on ankle'],
    ['Neel Menon', 15, 'Thiruvananthapuram', 'Table Tennis', 3, 'Scar on chin'],
    ['Tara Kulkarni', 12, 'Mumbai', 'Drawing', 5, 'Mole near left ear']
  ];
  const occupations = ['Software Engineer', 'Teacher', 'Doctor', 'Business Owner', 'Bank Manager', 'Farmer'];
  const schools = ['Kendriya Vidyalaya', 'Delhi Public School', 'St. Joseph\'s School', 'Navodaya Vidyalaya', 'Bishop Cotton School'];
  const colleges = ['Not applicable', 'Not applicable', 'Government Degree College', 'Not applicable'];
  const studentIds = [];
  const studentUserIds = [];

  studentSeed.forEach((s, i) => {
    const [name, age, place, sport, staffIdx, mark] = s;
    const email = `player${i + 1}@gsa.ac.in`;
    const phone = `9${String(840000000 + i * 13579).slice(-9)}`;
    const uid = Number(insert('users', {
      username: email, email, role: 'student',
      password_hash: hashPassword('Player@123'), name,
      status: 'active', created_at: iso()
    }).lastInsertRowid);
    const joined = day(int(180, 1300));
    const sid = Number(insert('students', {
      user_id: uid,
      student_code: `GSA-${1001 + i}`,
      name, age,
      body: pick(['Athletic', 'Slim', 'Medium', 'Strong']),
      place_of_birth: place,
      identification_mark: mark,
      address: `${int(12, 240)}, ${pick(['MG Road', 'Gandhi Street', 'Lake View', 'Park Road'])}, ${place}`,
      email, phone,
      father_name: `${pick(['Sunil', 'Rajesh', 'Anil', 'Vijay', 'Manoj', 'Suresh'])} ${name.split(' ')[1]}`,
      father_phone: `9${String(810000000 + i * 24680).slice(-9)}`,
      father_email: `father${i + 1}@example.com`,
      father_address: `${int(10, 190)}, ${pick(['Nehru Nagar', 'Station Road', 'Hill View'])}, ${place}`,
      father_occupation: pick(occupations),
      mother_name: `${pick(['Sunita', 'Rekha', 'Kavita', 'Anjali', 'Meena', 'Priya'])} ${name.split(' ')[1]}`,
      mother_phone: `8${String(700000000 + i * 13579).slice(-9)}`,
      mother_email: `mother${i + 1}@example.com`,
      mother_address: `${int(10, 190)}, ${pick(['Nehru Nagar', 'Station Road', 'Hill View'])}, ${place}`,
      mother_occupation: pick(occupations),
      joined_date: joined,
      ongoing_years: int(1, 4),
      sport,
      staff_id: staffIds[staffIdx],
      school_name: pick(schools),
      school_details: `Class ${pick(['VII', 'VIII', 'IX', 'X', 'XI', 'XII'])}, ${place}`,
      college_name: pick(colleges),
      college_details: 'Pre-university coaching alongside academy training',
      academic_year: '2026-2027',
      remarks: pick(['Very dedicated and regular in practice.', 'Needs focus on fitness and warm-up.', 'Promising performer, selected for state camp.', 'Improving steadily with good attendance.']),
      regular_medicine: pick(['None', 'None', 'Vitamin supplement', 'Asthma inhaler as needed']),
      allergy: pick(['None', 'Dust', 'Peanuts', 'None']),
      surgery: pick(['None', 'None', 'Appendicitis surgery (2023)']),
      health_issues: pick(['None', 'Mild asthma', 'None', 'Occasional knee pain']),
      damage: pick(['None', 'Minor wrist strain during practice', 'None']),
      equipment_purchased: pick(['Foil blade and mask', 'Chess clock', 'Yoga mat', 'Bat and gloves', 'Nothing yet']),
      fees_pending: [0, 0, 2500, 0, 5000, 0, 12000, 0, 2500, 0, 3000, 0, 2500, 0][i],
      prize_photo: `https://images.gsa.example/achievements/student-${i + 1}.jpg`,
      status: 'active'
    }).lastInsertRowid);
    studentIds.push(Number(sid));
    studentUserIds.push(uid);
  });

  const categories1 = ['District', 'State', 'National', 'International'];
  const categories2 = ['Sub-Junior', 'Junior', 'Senior', 'Youth'];
  const medals = ['Gold', 'Silver', 'Bronze', 'Participation'];
  for (let i = 0; i < 24; i++) {
    const studentIdx = i % studentSeed.length;
    const student = studentSeed[studentIdx];
    const c1 = categories1[i % 4];
    const c2 = categories2[(i + 1) % 4];
    const medal = medals[i % 4];
    const year = 2023 + (i % 4);
    insert('achievements', {
      student_id: studentIds[studentIdx],
      sport: student[3],
      category1: c1,
      category2: c2,
      medal,
      match_name: `${c1} ${student[3]} Championship ${year}`,
      match_date: day(int(30, 900)),
      match_details: `${medal} medal in ${c2} category at the ${c1.toLowerCase()} level ${student[3]} championship.`,
      prize_photo: `https://images.gsa.example/achievements/medal-${i + 1}.jpg`,
      created_at: iso()
    });
  }

  for (let i = 0; i < 24; i++) {
    const studentIdx = i % studentSeed.length;
    const yearly = i % 4 === 0;
    const amount = yearly ? 24000 : (studentSeed[studentIdx][3] === 'Fencing' ? 3500 : 2500);
    const paid = i % 5 === 0 ? 0 : (i % 3 === 0 ? amount / 2 : amount);
    insert('fees', {
      student_id: studentIds[studentIdx],
      sport: studentSeed[studentIdx][3],
      type: yearly ? 'yearly' : 'monthly',
      amount,
      paid_amount: paid,
      units: yearly ? '12 months' : '1 month',
      period: yearly ? '2026-2027' : `2026-${String((i % 9) + 1).padStart(2, '0')}`,
      due_date: day(-int(5, 90)),
      status: paid >= amount ? 'paid' : (paid > 0 ? 'partial' : 'pending'),
      created_at: iso()
    });
  }

  const incomeSources = ['Student Fees', 'Entry Fees', 'Cash Prize Entry', 'Equipment Sold'];
  for (let i = 0; i < 24; i++) {
    insert('income', {
      source: incomeSources[i % 4],
      sport: sportsData[i % sportsData.length].name,
      amount: int(800, 18000) + (i % 3) * 500,
      date: day(i * 12),
      description: `${incomeSources[i % 4]} receipt for ${sportsData[i % sportsData.length].name} programme`,
      ref_type: i % 4 === 0 ? 'fees' : null,
      ref_id: i % 4 === 0 ? (i + 1) : null,
      created_at: iso()
    });
  }

  const stockItems = {
    Chess: [['Chess Boards', 18, 4, 850], ['Chess Clocks', 2, 3, 1600], ['Chess Piece Sets', 22, 5, 600]],
    Carrom: [['Carrom Boards', 12, 4, 2200], ['Carrom Coins', 16, 5, 350]],
    Yoga: [['Yoga Mats', 30, 8, 700], ['Yoga Blocks', 10, 5, 450], ['Resistance Bands', 6, 8, 300]],
    Drawing: [['Sketch Books', 40, 10, 250], ['Watercolour Sets', 8, 4, 950], ['Acrylic Paints', 5, 6, 780]],
    Fencing: [['Foil Blades', 9, 5, 3200], ['Fencing Masks', 2, 4, 4100], ['Electric Jackets', 3, 4, 7800]],
    Cricket: [['Cricket Bats', 14, 5, 2800], ['Leather Balls', 24, 8, 550], ['Wicket Sets', 3, 3, 1800]],
    Archery: [['Recurve Bows', 6, 4, 6500], ['Arrows (dozen)', 9, 6, 1200], ['Arm Guards', 4, 5, 900]],
    'Table Tennis': [['TT Bats', 16, 6, 900], ['TT Balls (box)', 12, 5, 400], ['TT Nets', 2, 3, 1100]]
  };
  const stockIds = {};
  for (const [sport, items] of Object.entries(stockItems)) {
    stockIds[sport] = [];
    for (const [item, quantity, reorder_level, unit_price] of items) {
      const r = insert('stock', {
        sport, item, quantity, unit: 'pcs', unit_price, reorder_level, updated_at: iso()
      });
      stockIds[sport].push({ id: Number(r.lastInsertRowid), item, unit_price });
    }
  }
  for (const [sport, items] of Object.entries(stockItems)) {
    const first = stockIds[sport][0];
    const second = stockIds[sport][stockIds[sport].length - 1];
    insert('equipment_txns', {
      sport, item: first.item, qty: int(5, 15), type: 'purchase',
      amount: int(8000, 45000), party: pick(['Deccan Sports Supplies', 'Khel Store', 'Pro Gear India']),
      date: day(int(30, 180)), created_at: iso()
    });
    insert('equipment_txns', {
      sport, item: second.item, qty: int(1, 4), type: 'sold',
      amount: int(1200, 12000), party: pick(['Student purchase', 'Local club', 'Walk-in customer']),
      date: day(int(5, 90)), created_at: iso()
    });
  }

  const announcements = [
    { title: 'State Fencing Camp - Registration Open', body: 'Students selected for the state fencing camp must submit their consent forms by the 30th of this month.', audience: 'all' },
    { title: 'Annual Sports Day 2026', body: 'Annual Sports Day will be held at the academy ground. All students and parents are cordially invited.', audience: 'all' },
    { title: 'Staff Meeting on Friday', body: 'All coaches must attend the review meeting at 5:00 PM in the main hall.', audience: 'staff' },
    { title: 'Fee Submission Reminder', body: 'Please clear pending monthly and yearly fees before the end of the month to avoid a late fee.', audience: 'students' }
  ];
  for (const a of announcements) {
    insert('announcements', { ...a, date: day(int(1, 25)), author: 'Academy Owner', created_at: iso() });
  }

  const locations = ['Fencing Hall', 'Main Ground', 'Chess Room', 'Yoga Studio', 'Archery Range', 'TT Hall'];
  for (let i = 0; i < 48; i++) {
    const studentIdx = i % studentSeed.length;
    const event = i % 2 === 0 ? 'entry' : 'exit';
    insert('attendance', {
      student_id: studentIds[studentIdx],
      event,
      date: day(Math.floor(i / 3)),
      time: event === 'entry' ? timeStamp(int(7, 8), int(0, 55)) : timeStamp(int(16, 18), int(0, 55)),
      location: pick(locations),
      notes: event === 'entry' ? pick(['Regular practice session', 'Arrived for fitness training', 'Morning drills']) : pick(['Completed training', 'Left after practice', 'Session closed']),
      created_at: iso()
    });
  }

  for (let i = 0; i < 5; i++) {
    insert('leaves', {
      student_id: studentIds[i],
      from_date: day(int(2, 20)), to_date: day(int(1, 10)),
      reason: pick(['Family function', 'Medical check-up', 'School examination', 'Personal work']),
      status: ['approved', 'pending', 'approved', 'rejected', 'pending'][i],
      created_at: iso()
    });
  }

  const queryMessages = [
    'Requesting a certificate for the state level tournament.',
    'Suggestion: please extend the fencing hall timings on weekends.',
    'Need help with the online fee payment process.',
    'Can I get a copy of my attendance record for the last month?',
    'Please add more beginner-level yoga batches.'
  ];
  for (let i = 0; i < 5; i++) {
    insert('queries', {
      user_id: i % 2 === 0 ? studentUserIds[i] : staffUserIds[i - 1],
      role: i % 2 === 0 ? 'student' : 'staff',
      type: ['query', 'suggestion', 'help', 'query', 'suggestion'][i],
      message: queryMessages[i],
      reply: i % 2 === 0 ? 'Thank you, we will review your request shortly.' : null,
      status: i % 2 === 0 ? 'replied' : 'open',
      created_at: iso()
    });
  }

  const notificationSeed = [
    { user_id: studentUserIds[0], audience: 'user', title: 'Attendance recorded', body: 'Entry marked at the Fencing Hall today.' },
    { user_id: studentUserIds[2], audience: 'user', title: 'Fee reminder', body: 'Your monthly fee payment is pending.' },
    { user_id: staffUserIds[0], audience: 'user', title: 'New query assigned', body: 'A student has raised a query about tournament certificates.' },
    { user_id: null, audience: 'all', title: 'Annual Sports Day 2026', body: 'Annual Sports Day announcements are now live.' },
    { user_id: null, audience: 'students', title: 'Practice schedule update', body: 'Practice will start at 8:00 AM from next Monday.' },
    { user_id: null, audience: 'staff', title: 'Staff review meeting', body: 'Please attend the review meeting this Friday at 5 PM.' }
  ];
  notificationSeed.forEach((n, i) => {
    insert('notifications', { ...n, read: i % 3 === 0 ? 0 : 1, created_at: iso() });
  });

  const chatSeed = [
    { user_id: ownerId, role: 'owner', message: 'How many students are enrolled?', lang: 'en', reply: 'There are 14 students currently enrolled across 8 sports.' },
    { user_id: studentUserIds[0], role: 'student', message: 'Do I have any pending fees?', lang: 'en', reply: 'Yes, you have pending fees. Please check the Fees section for details.' },
    { user_id: staffUserIds[0], role: 'staff', message: 'Show recent achievements', lang: 'en', reply: 'Recent achievements of your students are available in the Achievements section.' }
  ];
  for (const c of chatSeed) insert('chat_messages', { ...c, created_at: iso() });
}

if (!get('SELECT COUNT(*) AS n FROM users')?.n) {
  db.exec('BEGIN');
  try {
    seed();
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
