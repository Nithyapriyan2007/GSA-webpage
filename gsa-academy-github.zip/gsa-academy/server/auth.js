import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { all, get } from './db.js';

const SECRET = process.env.GSA_JWT_SECRET || 'gsa-academy-dev-secret-2026';
const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;

export function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password, stored) {
  try {
    if (!stored || typeof stored !== 'string' || !stored.includes(':')) return false;
    const [salt, hex] = stored.split(':');
    const expected = Buffer.from(hex, 'hex');
    const actual = scryptSync(String(password), salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export function validPassword(password) {
  const pw = String(password || '');
  return pw.length >= 8 && /[A-Z]/.test(pw) && /[a-z]/.test(pw) && /\d/.test(pw) && /[^A-Za-z0-9]/.test(pw);
}

function b64url(value) {
  return Buffer.from(value).toString('base64url');
}

export function signToken(user) {
  const payload = {
    id: user.id,
    role: user.role,
    name: user.name,
    exp: Date.now() + THIRTY_DAYS
  };
  const body = b64url(JSON.stringify(payload));
  const signature = createHmac('sha256', SECRET).update(body).digest('base64url');
  return `${body}.${signature}`;
}

export function verifyToken(token) {
  try {
    if (!token || typeof token !== 'string') return null;
    const [body, signature] = token.split('.');
    if (!body || !signature) return null;
    const expected = createHmac('sha256', SECRET).update(body).digest('base64url');
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.id || !payload.role || !payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Authentication required' });
  const user = get('SELECT id, username, email, role, name, status FROM users WHERE id = ? AND status = ?', [payload.id, 'active']);
  if (!user) return res.status(401).json({ error: 'Account not found or inactive' });
  const profile = user.role === 'staff'
    ? get('SELECT id FROM staff WHERE user_id = ?', [user.id])
    : user.role === 'student'
      ? get('SELECT id FROM students WHERE user_id = ?', [user.id])
      : null;
  req.user = { ...user, profileId: profile ? profile.id : null };
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Authentication required' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
}

export function getPermissions(staffId) {
  const map = {};
  if (!staffId) return map;
  for (const row of all('SELECT module, can_view, can_edit FROM permissions WHERE staff_id = ?', [staffId])) {
    map[row.module] = { can_view: row.can_view, can_edit: row.can_edit };
  }
  return map;
}

export function hasPermission(req, module, action = 'can_view') {
  if (!req.user) return false;
  if (req.user.role === 'owner') return true;
  if (req.user.role !== 'staff') return false;
  const row = get('SELECT can_view, can_edit FROM permissions WHERE staff_id = ? AND module = ?', [req.user.profileId, module]);
  if (!row || !row.can_view) return false;
  return action === 'can_edit' ? Boolean(row.can_edit) : Boolean(row[action]);
}

export function requirePermission(module, action = 'can_view') {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Authentication required' });
    if (!hasPermission(req, module, action)) return res.status(403).json({ error: `No ${action === 'can_edit' ? 'edit' : 'view'} permission for ${module}` });
    next();
  };
}
