import { Router } from 'express';
import { randomInt } from 'node:crypto';
import { all, get, run, MODULES } from './db.js';
import {
  hashPassword, verifyPassword, validPassword, signToken,
  requireAuth, getPermissions, hasPermission
} from './auth.js';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export const router = Router();

const ok = (res, data, status = 200) => res.status(status).json(data);
const fail = (res, status, message) => res.status(status).json({ error: message });
const nowIso = () => new Date().toISOString();
const num = (value, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};
const round = (n) => Math.round(Number(n) * 100) / 100;
const missing = (body = {}, fields = []) => fields.filter((f) => body[f] === undefined || body[f] === null || body[f] === '');
function pickFields(body = {}, fields = []) {
  const out = {};
  for (const f of fields) if (body[f] !== undefined) out[f] = body[f];
  return out;
}
function patchTable(table, id, values) {
  const keys = Object.keys(values);
  if (!keys.length) return;
  run(`UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, [...keys.map((k) => values[k]), id]);
}
function audit(req, action, entity, entityId, details = {}) {
  run(
    'INSERT INTO audit_logs (user_id, role, action, entity, entity_id, details, created_at) VALUES (?,?,?,?,?,?,?)',
    [req.user?.id || null, req.user?.role || null, action, entity, String(entityId ?? ''),
      typeof details === 'string' ? details : JSON.stringify(details), nowIso()]
  );
}
function normalizeTypes(value) {
  if (Array.isArray(value)) return JSON.stringify(value);
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return JSON.stringify(parsed);
    } catch { /* treat as comma-separated list */ }
    return JSON.stringify(value.split(',').map((v) => v.trim()).filter(Boolean));
  }
  return '[]';
}
function serializeSport(row) {
  if (!row) return null;
  try { return { ...row, types: JSON.parse(row.types || '[]') }; }
  catch { return { ...row, types: [] }; }
}
function staffSports(req) {
  if (req.user?.role !== 'staff') return [];
  const row = get('SELECT sports FROM staff WHERE id = ?', [req.user.profileId]);
  if (!row) return [];
  try { return JSON.parse(row.sports || '[]'); } catch { return []; }
}
function scopeFor(req, alias = 's', module = null) {
  if (req.user.role === 'owner') return { sql: '1 = 1', params: [] };
  if (req.user.role === 'staff') {
    if (module && !hasPermission(req, module, 'can_view')) return null;
    const sports = staffSports(req);
    const sid = req.user.profileId;
    if (sports.length) {
      return { sql: `(${alias}.staff_id = ? OR ${alias}.sport IN (${sports.map(() => '?').join(',')}))`, params: [sid, ...sports] };
    }
    return { sql: `${alias}.staff_id = ?`, params: [sid] };
  }
  if (req.user.role === 'student') return { sql: `${alias}.user_id = ?`, params: [req.user.id] };
  return { sql: '0 = 1', params: [] };
}
function scopedStudents(req, module = 'students', strict = false) {
  const scope = scopeFor(req, 's', module);
  if (!scope) return strict ? null : [];
  return all(
    `SELECT s.*, sp.name AS sportName, st.name AS staffName
     FROM students s LEFT JOIN sports sp ON sp.name = s.sport
     LEFT JOIN staff st ON st.id = s.staff_id
     WHERE ${scope.sql} ORDER BY s.id`, scope.params
  );
}
function scopedAchievements(req, strict = false) {
  const scope = scopeFor(req, 's', 'achievements');
  if (!scope) return strict ? null : [];
  return all(
    `SELECT a.*, s.name AS student_name FROM achievements a
     JOIN students s ON s.id = a.student_id
     WHERE ${scope.sql} ORDER BY a.match_date DESC, a.id DESC`, scope.params
  );
}
function scopedFees(req, strict = false) {
  const scope = scopeFor(req, 's', 'fees');
  if (!scope) return strict ? null : [];
  return all(
    `SELECT f.*, s.name AS student_name FROM fees f
     JOIN students s ON s.id = f.student_id
     WHERE ${scope.sql} ORDER BY f.id DESC`, scope.params
  );
}
function scopedAttendance(req, strict = false) {
  const scope = scopeFor(req, 's', 'attendance');
  if (!scope) return strict ? null : [];
  return all(
    `SELECT at.*, s.name AS student_name FROM attendance at
     JOIN students s ON s.id = at.student_id
     WHERE ${scope.sql} ORDER BY at.date DESC, at.id DESC`, scope.params
  );
}
function scopedLeaves(req) {
  const scope = scopeFor(req, 's', 'students');
  if (!scope) return [];
  return all(
    `SELECT l.*, s.name AS student_name FROM leaves l
     JOIN students s ON s.id = l.student_id
     WHERE ${scope.sql} ORDER BY l.id DESC`, scope.params
  );
}
function scopedAnnouncements(req) {
  if (req.user.role === 'owner') return all('SELECT * FROM announcements ORDER BY date DESC, id DESC');
  const audience = req.user.role === 'staff' ? 'staff' : 'students';
  return all('SELECT * FROM announcements WHERE audience IN (?, ?) ORDER BY date DESC, id DESC', ['all', audience]);
}
function scopedStock(req, strict = false) {
  if (req.user.role === 'owner') return all('SELECT * FROM stock ORDER BY sport, item');
  if (req.user.role === 'staff' && hasPermission(req, 'stock', 'can_view')) {
    return all('SELECT * FROM stock ORDER BY sport, item');
  }
  return strict ? null : [];
}
function notificationsFor(req) {
  if (req.user.role === 'owner') {
    return all('SELECT * FROM notifications ORDER BY id DESC LIMIT 100');
  }
  const audience = req.user.role === 'staff' ? 'staff' : 'students';
  return all(
    'SELECT * FROM notifications WHERE user_id = ? OR audience IN (?, ?) ORDER BY id DESC LIMIT 100',
    [req.user.id, 'all', audience]
  );
}
function studentOf(req) {
  if (req.user.role !== 'student') return null;
  return get('SELECT * FROM students WHERE user_id = ?', [req.user.id]);
}
function canAccessStudent(req, id) {
  if (req.user.role === 'owner') return true;
  if (req.user.role === 'student') return studentOf(req)?.id === Number(id);
  const scope = scopeFor(req, 's', 'students');
  if (!scope) return false;
  return Boolean(get(`SELECT s.id FROM students s WHERE s.id = ? AND ${scope.sql}`, [Number(id), ...scope.params]));
}
function sumRows(rows, field) {
  return round(rows.reduce((acc, r) => acc + num(r[field]), 0));
}
function groupSum(rows, keyField, valueField) {
  const map = new Map();
  for (const r of rows) map.set(r[keyField] || 'Other', (map.get(r[keyField] || 'Other') || 0) + num(r[valueField]));
  return [...map.entries()].map(([key, value]) => ({ [keyField]: key, total: round(value) })).sort((a, b) => b.total - a.total);
}

/* ------------------------------ public ------------------------------ */

router.get('/health', (_req, res) => ok(res, { ok: true, time: nowIso() }));

router.get('/bootstrap', (_req, res) => {
  const sports = all('SELECT * FROM sports ORDER BY id').map(serializeSport);
  const students = get('SELECT COUNT(*) n FROM students')?.n || 0;
  const medals = get("SELECT COUNT(*) n FROM achievements WHERE medal IN ('Gold','Silver','Bronze')")?.n || 0;
  ok(res, {
    contact: {
      phone: '9042999507',
      email: 'globalsportsnkl@gmail.com',
      whatsapp: '9042999507',
      mapUrl: 'https://maps.app.goo.gl/diXTb2Q2biaQ7ePq6'
    },
    sports,
    highlights: { experienceYears: 25, cctv: '24/7', view: '360°', students, medals }
  });
});

router.post('/auth/login', (req, res) => {
  const { role, identifier, password } = req.body || {};
  if (!role || !identifier || password === undefined) return fail(res, 400, 'role, identifier and password are required');
  if (!['owner', 'staff', 'student'].includes(role)) return fail(res, 400, 'Invalid role');

  if (role === 'owner') {
    if (identifier !== 'owner' || password !== '9042999507') return fail(res, 401, 'Invalid credentials');
    const owner = get("SELECT * FROM users WHERE role = 'owner' AND username = 'owner'");
    if (!owner) return fail(res, 401, 'Invalid credentials');
    const permissions = Object.fromEntries(MODULES.map((m) => [m, { can_view: 1, can_edit: 1 }]));
    return ok(res, {
      token: signToken(owner),
      user: { id: owner.id, role: 'owner', name: owner.name, email: owner.email, permissions, profileId: owner.id }
    });
  }

  const user = get('SELECT * FROM users WHERE email = ? AND role = ?', [String(identifier).trim(), role]);
  if (!user || user.status !== 'active' || !verifyPassword(password, user.password_hash)) {
    return fail(res, 401, 'Invalid credentials');
  }
  const profile = role === 'staff'
    ? get('SELECT * FROM staff WHERE user_id = ?', [user.id])
    : get('SELECT * FROM students WHERE user_id = ?', [user.id]);
  if (!profile) return fail(res, 401, 'Profile not found');
  if (profile.status && profile.status !== 'active') return fail(res, 401, 'Account is inactive');
  const permissions = role === 'staff' ? getPermissions(profile.id) : {};
  ok(res, {
    token: signToken(user),
    user: {
      id: user.id, role, name: user.name, email: user.email, permissions,
      profileId: profile.id, student_code: profile.student_code || undefined
    }
  });
});

router.post('/auth/forgot/request', (req, res) => {
  const { email, role } = req.body || {};
  if (!email || !role) return fail(res, 400, 'email and role are required');
  const user = get('SELECT id FROM users WHERE email = ? AND role = ?', [String(email).trim(), role]);
  if (!user) return fail(res, 404, 'No account found for that email and role');
  const code = String(randomInt(100000, 999999));
  run(
    'INSERT INTO password_resets (email, role, code, expires_at, created_at) VALUES (?,?,?,?,?)',
    [String(email).trim(), role, code, new Date(Date.now() + 10 * 60 * 1000).toISOString(), nowIso()]
  );
  ok(res, { code, message: 'Demo verification code generated (valid for 10 minutes)' });
});

router.post('/auth/forgot/reset', (req, res) => {
  const { email, code, password } = req.body || {};
  if (!email || !code || !password) return fail(res, 400, 'email, code and password are required');
  if (!validPassword(password)) {
    return fail(res, 400, 'Password must be at least 8 characters with upper, lower, number and special character');
  }
  const reset = get(
    'SELECT * FROM password_resets WHERE email = ? AND code = ? ORDER BY id DESC LIMIT 1',
    [String(email).trim(), String(code)]
  );
  if (!reset) return fail(res, 400, 'Invalid verification code');
  if (new Date(reset.expires_at).getTime() < Date.now()) return fail(res, 400, 'Verification code has expired');
  const result = run('UPDATE users SET password_hash = ? WHERE email = ?', [hashPassword(password), String(email).trim()]);
  if (!result.changes) return fail(res, 404, 'Account not found');
  run('DELETE FROM password_resets WHERE email = ?', [String(email).trim()]);
  ok(res, { success: true, message: 'Password reset successfully' });
});

/* --------------------------- authenticated --------------------------- */

router.use(requireAuth);

router.get('/auth/me', (req, res) => {
  const permissions = req.user.role === 'owner'
    ? Object.fromEntries(MODULES.map((m) => [m, { can_view: 1, can_edit: 1 }]))
    : req.user.role === 'staff' ? getPermissions(req.user.profileId) : {};
  const profile = req.user.role === 'student' ? studentOf(req)
    : req.user.role === 'staff' ? get('SELECT * FROM staff WHERE id = ?', [req.user.profileId]) : null;
  ok(res, { user: { ...req.user, permissions, profile } });
});

/* ------------------------------ dashboard ----------------------------- */

function ownerDashboard() {
  const students = all('SELECT id, joined_date FROM students');
  const medals = all('SELECT medal, sport FROM achievements');
  const incomeRows = all('SELECT amount, date, source, sport FROM income');
  const expenseRows = all("SELECT amount, date, sport FROM equipment_txns WHERE type = 'purchase'");
  const feesRows = all('SELECT amount, paid_amount FROM fees');
  const stockRows = all('SELECT * FROM stock');
  const today = new Date();
  const monthKeys = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - i, 1));
    monthKeys.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  const monthly = monthKeys.map((month) => ({
    month,
    income: sumRows(incomeRows.filter((r) => String(r.date || '').slice(0, 7) === month), 'amount'),
    expense: sumRows(expenseRows.filter((r) => String(r.date || '').slice(0, 7) === month), 'amount')
  }));
  const sportPerformance = all('SELECT name FROM sports ORDER BY id').map((s) => ({
    sport: s.name,
    students: students.filter((st) => get('SELECT sport FROM students WHERE id = ?', [st.id])?.sport === s.name).length,
    medals: medals.filter((m) => m.sport === s.name && m.medal !== 'Participation').length,
    revenue: sumRows(incomeRows.filter((r) => r.sport === s.name), 'amount')
  }));
  const recentAchievements = all(
    `SELECT a.*, s.name AS student_name FROM achievements a JOIN students s ON s.id = a.student_id
     ORDER BY a.match_date DESC, a.id DESC LIMIT 6`
  );
  const stockAlerts = stockRows.filter((r) => num(r.quantity) <= num(r.reorder_level))
    .sort((a, b) => a.quantity - b.quantity).slice(0, 10);
  const recentAttendance = all(
    `SELECT at.*, s.name AS student_name FROM attendance at JOIN students s ON s.id = at.student_id
     ORDER BY at.date DESC, at.id DESC LIMIT 8`
  );
  const entry30 = get('SELECT COUNT(*) n FROM attendance WHERE event = ? AND date >= ?',
    ['entry', new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)])?.n || 0;
  const currentMonth = monthKeys[11];
  const prevMonth = monthKeys[10];
  const currJoins = students.filter((s) => String(s.joined_date || '').slice(0, 7) === currentMonth).length;
  const prevJoins = students.filter((s) => String(s.joined_date || '').slice(0, 7) === prevMonth).length;
  return {
    summary: {
      students: students.length,
      staff: get('SELECT COUNT(*) n FROM staff')?.n || 0,
      sports: sportPerformance.length,
      medals: medals.filter((m) => m.medal !== 'Participation').length,
      totalIncome: sumRows(incomeRows, 'amount'),
      totalExpense: sumRows(expenseRows, 'amount'),
      pendingFees: round(feesRows.reduce((acc, f) => acc + Math.max(0, num(f.amount) - num(f.paid_amount)), 0)),
      lowStock: stockRows.filter((r) => num(r.quantity) <= num(r.reorder_level)).length,
      attendanceRate: Math.min(100, Math.round((entry30 / Math.max(1, students.length * 20)) * 100)),
      monthGrowth: Math.round(((currJoins - prevJoins) / Math.max(1, prevJoins)) * 100)
    },
    monthly,
    sportPerformance,
    recentAchievements,
    stockAlerts,
    recentAttendance,
    finance: {
      incomeBySource: groupSum(incomeRows, 'source', 'amount'),
      expenseBySport: groupSum(expenseRows, 'sport', 'amount')
    },
    announcements: scopedAnnouncements({ user: { role: 'owner' } }).slice(0, 5)
  };
}

function staffDashboard(req) {
  const permissionMap = getPermissions(req.user.profileId);
  const students = scopedStudents(req, 'students');
  const achievements = scopedAchievements(req);
  const attendance = scopedAttendance(req);
  const today = nowIso().slice(0, 10);
  const studentIds = new Set(students.map((s) => s.id));
  const scopedAttendanceAll = all('SELECT * FROM attendance ORDER BY date DESC, id DESC').filter((a) => studentIds.has(a.student_id));
  return {
    summary: {
      students: students.length,
      medals: achievements.filter((a) => a.medal !== 'Participation').length,
      attendanceToday: scopedAttendanceAll.filter((a) => a.date === today && a.event === 'entry').length
    },
    students: students.map((s) => ({
      id: s.id, student_code: s.student_code, name: s.name, age: s.age, sport: s.sport,
      staff_id: s.staff_id, joined_date: s.joined_date, fees_pending: s.fees_pending,
      email: s.email, phone: s.phone
    })),
    achievements,
    attendance: attendance.slice(0, 30),
    announcements: scopedAnnouncements(req),
    queries: hasPermission(req, 'queries', 'can_view')
      ? all('SELECT * FROM queries ORDER BY id DESC')
      : all('SELECT * FROM queries WHERE user_id = ? ORDER BY id DESC', [req.user.id]),
    permissionMap
  };
}

function studentDashboard(req) {
  const profile = studentOf(req);
  if (!profile) return failResponse(404, 'Student profile not found');
  const achievements = all('SELECT * FROM achievements WHERE student_id = ? ORDER BY match_date DESC', [profile.id]);
  const attendance = all('SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC, id DESC LIMIT 30', [profile.id]);
  const fees = all('SELECT * FROM fees WHERE student_id = ? ORDER BY id DESC', [profile.id]);
  const leaves = all('SELECT * FROM leaves WHERE student_id = ? ORDER BY id DESC', [profile.id]);
  const sportName = get('SELECT name FROM sports WHERE name = ?', [profile.sport])?.name || profile.sport;
  const staffName = get('SELECT name FROM staff WHERE id = ?', [profile.staff_id])?.name || null;
  return {
    profile: { ...profile, sportName, staffName },
    achievements,
    attendance,
    fees,
    leaves,
    announcements: scopedAnnouncements(req),
    notifications: notificationsFor(req),
    passport: {
      id: `GSA/2026/${String(profile.id).padStart(3, '0')}`,
      joined: profile.joined_date,
      years: profile.ongoing_years,
      sport: sportName,
      medals: achievements.filter((a) => a.medal !== 'Participation').length
    }
  };
}
function failResponse(status, message) { return { __error: [status, message] }; }

router.get('/dashboard', (req, res) => {
  if (req.user.role === 'owner') return ok(res, ownerDashboard());
  if (req.user.role === 'staff') return ok(res, staffDashboard(req));
  const data = studentDashboard(req);
  if (data.__error) return fail(res, ...data.__error);
  ok(res, data);
});

/* ------------------------------ students ------------------------------ */

const STUDENT_FIELDS = [
  'student_code', 'name', 'age', 'body', 'place_of_birth', 'identification_mark', 'address',
  'email', 'phone', 'father_name', 'father_phone', 'father_email', 'father_address', 'father_occupation',
  'mother_name', 'mother_phone', 'mother_email', 'mother_address', 'mother_occupation',
  'joined_date', 'ongoing_years', 'sport', 'staff_id', 'school_name', 'school_details',
  'college_name', 'college_details', 'academic_year', 'remarks', 'regular_medicine', 'allergy',
  'surgery', 'health_issues', 'damage', 'equipment_purchased', 'fees_pending', 'prize_photo', 'status'
];

router.get('/students', (req, res) => {
  const rows = scopedStudents(req, 'students', true);
  if (rows === null) return fail(res, 403, 'No view permission for students');
  ok(res, rows);
});

router.get('/students/me', (req, res) => {
  if (req.user.role === 'student') {
    const profile = studentOf(req);
    if (!profile) return fail(res, 404, 'Student profile not found');
    return ok(res, profile);
  }
  if (req.user.role === 'staff') {
    return ok(res, get('SELECT * FROM staff WHERE id = ?', [req.user.profileId]));
  }
  ok(res, get('SELECT * FROM users WHERE id = ?', [req.user.id]));
});

router.get('/students/:id', (req, res) => {
  const row = get(
    `SELECT s.*, sp.name AS sportName, st.name AS staffName FROM students s
     LEFT JOIN sports sp ON sp.name = s.sport LEFT JOIN staff st ON st.id = s.staff_id WHERE s.id = ?`,
    [req.params.id]
  );
  if (!row) return fail(res, 404, 'Student not found');
  if (!canAccessStudent(req, row.id)) return fail(res, 403, 'Forbidden');
  ok(res, row);
});

router.post('/students', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const body = req.body || {};
  const required = missing(body, ['name', 'email']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  if (get('SELECT id FROM users WHERE email = ?', [body.email])) return fail(res, 400, 'Email already in use');
  const uid = Number(run(
    'INSERT INTO users (username, email, role, password_hash, name, status, created_at) VALUES (?,?,?,?,?,?,?)',
    [body.email, body.email, 'student', hashPassword('Player@123'), body.name, body.status === 'inactive' ? 'inactive' : 'active', nowIso()]
  ).lastInsertRowid);
  const values = pickFields(body, STUDENT_FIELDS);
  values.user_id = uid;
  values.student_code = values.student_code || `GSA-${String(1001 + (get('SELECT COUNT(*) n FROM students')?.n || 0))}`;
  values.created_at = undefined;
  delete values.created_at;
  const keys = Object.keys(values);
  const sid = Number(run(
    `INSERT INTO students (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => (k === 'sports' ? normalizeTypes(values[k]) : values[k]))
  ).lastInsertRowid);
  audit(req, 'create', 'students', sid, { name: body.name });
  ok(res, get('SELECT * FROM students WHERE id = ?', [sid]), 201);
});

router.put('/students/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const existing = get('SELECT * FROM students WHERE id = ?', [req.params.id]);
  if (!existing) return fail(res, 404, 'Student not found');
  const values = pickFields(req.body || {}, STUDENT_FIELDS);
  patchTable('students', existing.id, values);
  if (req.body?.name || req.body?.email) {
    patchTable('users', existing.user_id, pickFields(req.body, ['name', 'email']));
  }
  audit(req, 'update', 'students', existing.id, values);
  ok(res, get('SELECT * FROM students WHERE id = ?', [existing.id]));
});

router.delete('/students/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const existing = get('SELECT * FROM students WHERE id = ?', [req.params.id]);
  if (!existing) return fail(res, 404, 'Student not found');
  const uid = existing.user_id;
  for (const table of ['achievements', 'fees', 'attendance', 'leaves']) {
    run(`DELETE FROM ${table} WHERE student_id = ?`, [existing.id]);
  }
  run('DELETE FROM notifications WHERE user_id = ?', [uid]);
  run('DELETE FROM queries WHERE user_id = ?', [uid]);
  run('DELETE FROM chat_messages WHERE user_id = ?', [uid]);
  run('DELETE FROM students WHERE id = ?', [existing.id]);
  run('DELETE FROM users WHERE id = ?', [uid]);
  audit(req, 'delete', 'students', existing.id, { name: existing.name });
  ok(res, { success: true });
});

/* -------------------------------- staff ------------------------------- */

const STAFF_FIELDS = [
  'name', 'age', 'body', 'place', 'experience', 'category', 'achievement',
  'sports', 'previously_worked', 'status'
];
function serializeStaff(row) {
  if (!row) return null;
  const copy = { ...row };
  try { copy.sports = JSON.parse(copy.sports || '[]'); } catch { copy.sports = []; }
  return copy;
}
function staffWithEmail(row) {
  if (!row) return null;
  return { ...serializeStaff(row), email: get('SELECT email FROM users WHERE id = ?', [row.user_id])?.email || null };
}

router.get('/staff', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  ok(res, all('SELECT * FROM staff ORDER BY id').map(staffWithEmail));
});

router.get('/staff/me', (req, res) => {
  if (req.user.role !== 'staff') return fail(res, 403, 'Staff only');
  ok(res, staffWithEmail(get('SELECT * FROM staff WHERE id = ?', [req.user.profileId])));
});

router.get('/staff/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const row = get('SELECT * FROM staff WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Staff not found');
  ok(res, staffWithEmail(row));
});

router.post('/staff', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const body = req.body || {};
  const required = missing(body, ['name', 'email']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  if (!validPassword(body.password || 'Coach@123')) return fail(res, 400, 'Password does not meet the policy');
  if (get('SELECT id FROM users WHERE email = ?', [body.email])) return fail(res, 400, 'Email already in use');
  const uid = Number(run(
    'INSERT INTO users (username, email, role, password_hash, name, status, created_at) VALUES (?,?,?,?,?,?,?)',
    [body.email, body.email, 'staff', hashPassword(body.password || 'Coach@123'), body.name, 'active', nowIso()]
  ).lastInsertRowid);
  const values = pickFields(body, STAFF_FIELDS);
  values.user_id = uid;
  values.sports = normalizeTypes(values.sports || []);
  const keys = Object.keys(values);
  const sid = Number(run(
    `INSERT INTO staff (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => (k === 'sports' ? normalizeTypes(values[k]) : values[k]))
  ).lastInsertRowid);
  for (const module of MODULES) {
    run('INSERT INTO permissions (staff_id, module, can_view, can_edit) VALUES (?,?,?,?)', [sid, module, 1, 0]);
  }
  audit(req, 'create', 'staff', sid, { name: body.name });
  ok(res, staffWithEmail(get('SELECT * FROM staff WHERE id = ?', [sid])), 201);
});

router.put('/staff/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const existing = get('SELECT * FROM staff WHERE id = ?', [req.params.id]);
  if (!existing) return fail(res, 404, 'Staff not found');
  const values = pickFields(req.body || {}, STAFF_FIELDS);
  if (values.sports !== undefined) values.sports = normalizeTypes(values.sports);
  patchTable('staff', existing.id, values);
  if (req.body?.name || req.body?.email || req.body?.password) {
    const userValues = pickFields(req.body, ['name', 'email']);
    if (req.body.password) {
      if (!validPassword(req.body.password)) return fail(res, 400, 'Password does not meet the policy');
      userValues.password_hash = hashPassword(req.body.password);
    }
    patchTable('users', existing.user_id, userValues);
  }
  audit(req, 'update', 'staff', existing.id, values);
  ok(res, staffWithEmail(get('SELECT * FROM staff WHERE id = ?', [existing.id])));
});

router.delete('/staff/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const existing = get('SELECT * FROM staff WHERE id = ?', [req.params.id]);
  if (!existing) return fail(res, 404, 'Staff not found');
  run('DELETE FROM permissions WHERE staff_id = ?', [existing.id]);
  run('DELETE FROM notifications WHERE user_id = ?', [existing.user_id]);
  run('DELETE FROM staff WHERE id = ?', [existing.id]);
  run('DELETE FROM users WHERE id = ?', [existing.user_id]);
  audit(req, 'delete', 'staff', existing.id, { name: existing.name });
  ok(res, { success: true });
});

/* ----------------------------- permissions ---------------------------- */

router.get('/permissions', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  ok(res, all(
    `SELECT p.*, s.name AS staff_name, u.email FROM permissions p
     JOIN staff s ON s.id = p.staff_id JOIN users u ON u.id = s.user_id ORDER BY p.staff_id, p.module`
  ));
});

router.put('/permissions/:staffId/:module', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const { staffId, module } = req.params;
  if (!MODULES.includes(module)) return fail(res, 400, `Invalid module. Allowed: ${MODULES.join(', ')}`);
  if (!get('SELECT id FROM staff WHERE id = ?', [staffId])) return fail(res, 404, 'Staff not found');
  const { can_view, can_edit } = req.body || {};
  const view = can_view === undefined ? undefined : (can_view ? 1 : 0);
  const edit = can_edit === undefined ? undefined : (can_edit ? 1 : 0);
  const existing = get('SELECT id FROM permissions WHERE staff_id = ? AND module = ?', [staffId, module]);
  if (existing) {
    if (view !== undefined || edit !== undefined) {
      patchTable('permissions', existing.id, {
        ...(view !== undefined ? { can_view: view } : {}),
        ...(edit !== undefined ? { can_edit: edit } : {})
      });
    }
  } else {
    run('INSERT INTO permissions (staff_id, module, can_view, can_edit) VALUES (?,?,?,?)',
      [staffId, module, view ?? 1, edit ?? 0]);
  }
  audit(req, 'update', 'permissions', staffId, { module, can_view: view, can_edit: edit });
  ok(res, get('SELECT * FROM permissions WHERE staff_id = ? AND module = ?', [staffId, module]));
});

/* -------------------------------- sports ------------------------------ */

const SPORT_FIELDS = ['name', 'types', 'icon', 'color', 'description'];

router.get('/sports', (_req, res) => ok(res, all('SELECT * FROM sports ORDER BY id').map(serializeSport)));

router.get('/sports/:id', (req, res) => {
  const row = get('SELECT * FROM sports WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Sport not found');
  ok(res, serializeSport(row));
});

router.post('/sports', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['name']);
  if (required.length) return fail(res, 400, 'name is required');
  if (get('SELECT id FROM sports WHERE name = ?', [req.body.name])) return fail(res, 400, 'Sport already exists');
  const values = pickFields(req.body, SPORT_FIELDS);
  values.types = normalizeTypes(values.types);
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO sports (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'sports', id, { name: values.name });
  ok(res, serializeSport(get('SELECT * FROM sports WHERE id = ?', [id])), 201);
});

router.put('/sports/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM sports WHERE id = ?', [req.params.id])) return fail(res, 404, 'Sport not found');
  const values = pickFields(req.body || {}, SPORT_FIELDS);
  if (values.types !== undefined) values.types = normalizeTypes(values.types);
  patchTable('sports', req.params.id, values);
  audit(req, 'update', 'sports', req.params.id, values);
  ok(res, serializeSport(get('SELECT * FROM sports WHERE id = ?', [req.params.id])));
});

router.delete('/sports/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM sports WHERE id = ?', [req.params.id])) return fail(res, 404, 'Sport not found');
  run('DELETE FROM sports WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'sports', req.params.id, {});
  ok(res, { success: true });
});

/* ----------------------------- achievements --------------------------- */

const ACHIEVEMENT_FIELDS = [
  'student_id', 'sport', 'category1', 'category2', 'medal', 'match_name',
  'match_date', 'match_details', 'prize_photo'
];

router.get('/achievements', (req, res) => {
  const rows = scopedAchievements(req, true);
  if (rows === null) return fail(res, 403, 'No view permission for achievements');
  ok(res, rows);
});

router.get('/achievements/:id', (req, res) => {
  const row = get(
    `SELECT a.*, s.name AS student_name FROM achievements a JOIN students s ON s.id = a.student_id WHERE a.id = ?`,
    [req.params.id]
  );
  if (!row) return fail(res, 404, 'Achievement not found');
  if (!canAccessStudent(req, row.student_id)) return fail(res, 403, 'Forbidden');
  ok(res, row);
});

router.post('/achievements', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['student_id', 'match_name']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  const student = get('SELECT * FROM students WHERE id = ?', [req.body.student_id]);
  if (!student) return fail(res, 404, 'Student not found');
  const values = pickFields(req.body, ACHIEVEMENT_FIELDS);
  values.sport = values.sport || student.sport;
  values.created_at = nowIso();
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO achievements (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'achievements', id, { student_id: values.student_id });
  ok(res, get('SELECT * FROM achievements WHERE id = ?', [id]), 201);
});

router.put('/achievements/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM achievements WHERE id = ?', [req.params.id])) return fail(res, 404, 'Achievement not found');
  patchTable('achievements', req.params.id, pickFields(req.body || {}, ACHIEVEMENT_FIELDS));
  audit(req, 'update', 'achievements', req.params.id, req.body || {});
  ok(res, get('SELECT * FROM achievements WHERE id = ?', [req.params.id]));
});

router.delete('/achievements/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM achievements WHERE id = ?', [req.params.id])) return fail(res, 404, 'Achievement not found');
  run('DELETE FROM achievements WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'achievements', req.params.id, {});
  ok(res, { success: true });
});

/* --------------------------------- fees -------------------------------- */

const FEE_FIELDS = ['student_id', 'sport', 'type', 'amount', 'paid_amount', 'units', 'period', 'due_date', 'status'];

router.get('/fees', (req, res) => {
  const rows = scopedFees(req, true);
  if (rows === null) return fail(res, 403, 'No view permission for fees');
  ok(res, rows);
});

router.post('/fees/pay', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const { id, amount, method = 'Cash' } = req.body || {};
  const fee = get('SELECT * FROM fees WHERE id = ?', [id]);
  if (!fee) return fail(res, 404, 'Fee record not found');
  const paid = num(amount);
  if (paid <= 0) return fail(res, 400, 'amount must be greater than zero');
  const newPaid = round(num(fee.paid_amount) + paid);
  const status = newPaid >= num(fee.amount) ? 'paid' : (newPaid > 0 ? 'partial' : 'pending');
  patchTable('fees', fee.id, { paid_amount: newPaid, status });
  run(
    'INSERT INTO income (source, sport, amount, date, description, ref_type, ref_id, created_at) VALUES (?,?,?,?,?,?,?,?)',
    ['Student Fees', fee.sport, paid, nowIso().slice(0, 10), `Fee payment via ${method} for record #${fee.id}`, 'fees', fee.id, nowIso()]
  );
  const student = get('SELECT user_id, name FROM students WHERE id = ?', [fee.student_id]);
  if (student) {
    run('INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
      [student.user_id, 'user', 'Fee payment received', `₹${paid} received via ${method} for ${student.name}.`, 0, nowIso()]);
  }
  audit(req, 'payment', 'fees', fee.id, { amount: paid, method });
  ok(res, get('SELECT * FROM fees WHERE id = ?', [fee.id]));
});

router.get('/fees/:id', (req, res) => {
  const row = get('SELECT * FROM fees WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Fee record not found');
  if (!canAccessStudent(req, row.student_id)) return fail(res, 403, 'Forbidden');
  ok(res, row);
});

router.post('/fees', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['student_id', 'amount']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  const student = get('SELECT * FROM students WHERE id = ?', [req.body.student_id]);
  if (!student) return fail(res, 404, 'Student not found');
  const values = pickFields(req.body, FEE_FIELDS);
  values.sport = values.sport || student.sport;
  const paid = num(values.paid_amount);
  const amount = num(values.amount);
  values.status = values.status || (paid >= amount ? 'paid' : (paid > 0 ? 'partial' : 'pending'));
  values.created_at = nowIso();
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO fees (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'fees', id, { student_id: values.student_id });
  ok(res, get('SELECT * FROM fees WHERE id = ?', [id]), 201);
});

router.put('/fees/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM fees WHERE id = ?', [req.params.id])) return fail(res, 404, 'Fee record not found');
  patchTable('fees', req.params.id, pickFields(req.body || {}, FEE_FIELDS));
  audit(req, 'update', 'fees', req.params.id, req.body || {});
  ok(res, get('SELECT * FROM fees WHERE id = ?', [req.params.id]));
});

router.delete('/fees/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM fees WHERE id = ?', [req.params.id])) return fail(res, 404, 'Fee record not found');
  run('DELETE FROM fees WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'fees', req.params.id, {});
  ok(res, { success: true });
});

/* -------------------------------- income ------------------------------ */

const INCOME_FIELDS = ['source', 'sport', 'amount', 'date', 'description', 'ref_type', 'ref_id'];

router.get('/income', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  ok(res, all('SELECT * FROM income ORDER BY date DESC, id DESC'));
});

router.post('/income', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['source', 'amount']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  const values = pickFields(req.body, INCOME_FIELDS);
  values.date = values.date || nowIso().slice(0, 10);
  values.created_at = nowIso();
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO income (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'income', id, values);
  ok(res, get('SELECT * FROM income WHERE id = ?', [id]), 201);
});

router.put('/income/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM income WHERE id = ?', [req.params.id])) return fail(res, 404, 'Income record not found');
  patchTable('income', req.params.id, pickFields(req.body || {}, INCOME_FIELDS));
  audit(req, 'update', 'income', req.params.id, req.body || {});
  ok(res, get('SELECT * FROM income WHERE id = ?', [req.params.id]));
});

router.delete('/income/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM income WHERE id = ?', [req.params.id])) return fail(res, 404, 'Income record not found');
  run('DELETE FROM income WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'income', req.params.id, {});
  ok(res, { success: true });
});

/* --------------------------------- stock ------------------------------ */

const STOCK_FIELDS = ['sport', 'item', 'quantity', 'unit', 'unit_price', 'reorder_level'];

router.get('/equipment-txns', (req, res) => {
  if (req.user.role !== 'owner' && !(req.user.role === 'staff' && hasPermission(req, 'stock', 'can_view'))) {
    return fail(res, 403, 'No view permission for stock');
  }
  ok(res, all('SELECT * FROM equipment_txns ORDER BY date DESC, id DESC'));
});

router.get('/stock', (req, res) => {
  const rows = scopedStock(req, true);
  if (rows === null) return fail(res, 403, 'No view permission for stock');
  ok(res, rows);
});

router.post('/stock/transaction', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const { sport, item, type, amount, party } = req.body || {};
  const qty = num(req.body?.qty);
  if (!sport || !item || !['purchase', 'sold'].includes(type) || qty <= 0) {
    return fail(res, 400, 'sport, item, positive qty and type (purchase|sold) are required');
  }
  const stock = get('SELECT * FROM stock WHERE sport = ? AND item = ?', [sport, item]);
  if (!stock) return fail(res, 404, 'Stock item not found');
  const newQty = num(stock.quantity) + (type === 'purchase' ? qty : -qty);
  if (newQty < 0) return fail(res, 400, 'Insufficient stock quantity');
  patchTable('stock', stock.id, { quantity: newQty, updated_at: nowIso() });
  const txAmount = amount === undefined ? round(qty * num(stock.unit_price)) : num(amount);
  const txId = Number(run(
    'INSERT INTO equipment_txns (sport, item, qty, type, amount, party, date, created_at) VALUES (?,?,?,?,?,?,?,?)',
    [sport, item, qty, type, txAmount, party || null, nowIso().slice(0, 10), nowIso()]
  ).lastInsertRowid);
  if (type === 'sold') {
    run(
      'INSERT INTO income (source, sport, amount, date, description, ref_type, ref_id, created_at) VALUES (?,?,?,?,?,?,?,?)',
      ['Equipment Sold', sport, txAmount, nowIso().slice(0, 10), `Sold ${qty} x ${item} to ${party || 'walk-in customer'}`, 'equipment_txns', txId, nowIso()]
    );
  }
  audit(req, type === 'sold' ? 'sale' : 'purchase', 'stock', stock.id, { sport, item, qty, amount: txAmount });
  ok(res, {
    transaction: get('SELECT * FROM equipment_txns WHERE id = ?', [txId]),
    stock: get('SELECT * FROM stock WHERE id = ?', [stock.id])
  }, 201);
});

router.get('/stock/:id', (req, res) => {
  const row = get('SELECT * FROM stock WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Stock item not found');
  if (scopedStock(req, true) === null) return fail(res, 403, 'No view permission for stock');
  if (req.user.role === 'student') return fail(res, 403, 'Forbidden');
  ok(res, row);
});

router.post('/stock', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['sport', 'item']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  const values = pickFields(req.body, STOCK_FIELDS);
  values.updated_at = nowIso();
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO stock (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'stock', id, values);
  ok(res, get('SELECT * FROM stock WHERE id = ?', [id]), 201);
});

router.put('/stock/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM stock WHERE id = ?', [req.params.id])) return fail(res, 404, 'Stock item not found');
  const values = pickFields(req.body || {}, STOCK_FIELDS);
  values.updated_at = nowIso();
  patchTable('stock', req.params.id, values);
  audit(req, 'update', 'stock', req.params.id, values);
  ok(res, get('SELECT * FROM stock WHERE id = ?', [req.params.id]));
});

router.delete('/stock/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM stock WHERE id = ?', [req.params.id])) return fail(res, 404, 'Stock item not found');
  run('DELETE FROM stock WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'stock', req.params.id, {});
  ok(res, { success: true });
});

/* ---------------------------- announcements --------------------------- */

const ANNOUNCEMENT_FIELDS = ['title', 'body', 'audience', 'date', 'author'];

router.get('/announcements', (req, res) => ok(res, scopedAnnouncements(req)));

router.get('/announcements/:id', (req, res) => {
  const row = get('SELECT * FROM announcements WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Announcement not found');
  if (req.user.role !== 'owner' && !['all', req.user.role === 'staff' ? 'staff' : 'students'].includes(row.audience)) {
    return fail(res, 403, 'Forbidden');
  }
  ok(res, row);
});

router.post('/announcements', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['title', 'body']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  if (req.body.audience && !['all', 'staff', 'students'].includes(req.body.audience)) {
    return fail(res, 400, 'audience must be all, staff or students');
  }
  const values = pickFields(req.body, ANNOUNCEMENT_FIELDS);
  values.audience = values.audience || 'all';
  values.date = values.date || nowIso().slice(0, 10);
  values.author = values.author || req.user.name;
  values.created_at = nowIso();
  const keys = Object.keys(values);
  const id = Number(run(
    `INSERT INTO announcements (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
    keys.map((k) => values[k])
  ).lastInsertRowid);
  audit(req, 'create', 'announcements', id, values);
  ok(res, get('SELECT * FROM announcements WHERE id = ?', [id]), 201);
});

router.put('/announcements/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM announcements WHERE id = ?', [req.params.id])) return fail(res, 404, 'Announcement not found');
  patchTable('announcements', req.params.id, pickFields(req.body || {}, ANNOUNCEMENT_FIELDS));
  audit(req, 'update', 'announcements', req.params.id, req.body || {});
  ok(res, get('SELECT * FROM announcements WHERE id = ?', [req.params.id]));
});

router.delete('/announcements/:id', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  if (!get('SELECT id FROM announcements WHERE id = ?', [req.params.id])) return fail(res, 404, 'Announcement not found');
  run('DELETE FROM announcements WHERE id = ?', [req.params.id]);
  audit(req, 'delete', 'announcements', req.params.id, {});
  ok(res, { success: true });
});

/* ------------------------------ attendance ---------------------------- */

function createAttendance(req, body) {
  const studentId = Number(body.student_id);
  const student = get('SELECT * FROM students WHERE id = ?', [studentId]);
  if (!student) return { error: [404, 'Student not found'] };
  const event = body.event === 'exit' ? 'exit' : 'entry';
  const date = body.date || nowIso().slice(0, 10);
  const time = body.time || nowIso().slice(11, 16);
  const id = Number(run(
    'INSERT INTO attendance (student_id, event, date, time, location, notes, created_at) VALUES (?,?,?,?,?,?,?)',
    [studentId, event, date, time, body.location || 'Main Academy', body.notes || null, nowIso()]
  ).lastInsertRowid);
  const user = get('SELECT id FROM users WHERE id = ?', [student.user_id]);
  if (user) {
    run('INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
      [user.id, 'user', `${event === 'entry' ? 'Entry' : 'Exit'} recorded`,
        `${student.name}: ${event} marked at ${body.location || 'Main Academy'} on ${date} at ${time}.`, 0, nowIso()]);
  }
  run('INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
    [null, 'students', 'Attendance update for parents',
      `${student.name} (${student.student_code}) was marked ${event} on ${date} at ${time}.`, 0, nowIso()]);
  audit(req, 'create', 'attendance', id, { student_id: studentId, event });
  return { row: get('SELECT * FROM attendance WHERE id = ?', [id]) };
}

router.get('/attendance', (req, res) => {
  const rows = scopedAttendance(req, true);
  if (rows === null) return fail(res, 403, 'No view permission for attendance');
  ok(res, rows);
});

router.post('/attendance', (req, res) => {
  if (req.user.role !== 'owner' && !(req.user.role === 'staff' && hasPermission(req, 'attendance', 'can_edit'))) {
    return fail(res, 403, 'Only owner or staff with attendance edit permission can record attendance');
  }
  const required = missing(req.body || {}, ['student_id']);
  if (required.length) return fail(res, 400, 'student_id is required');
  const result = createAttendance(req, req.body || {});
  if (result.error) return fail(res, ...result.error);
  ok(res, result.row, 201);
});

router.post('/attendance/scan', (req, res) => {
  if (req.user.role !== 'owner' && !(req.user.role === 'staff' && hasPermission(req, 'attendance', 'can_edit'))) {
    return fail(res, 403, 'Not allowed to use the scanner');
  }
  const code = String(req.body?.student_code || req.body?.code || '').trim();
  if (!code) return fail(res, 400, 'student_code is required');
  const student = get('SELECT * FROM students WHERE student_code = ? OR phone = ?', [code, code]);
  if (!student) return fail(res, 404, 'Student not found for that code or phone');
  const result = createAttendance(req, {
    student_id: student.id,
    event: req.body.event || 'entry',
    date: req.body.date,
    time: req.body.time,
    location: req.body.location || 'Biometric Scanner - Main Gate',
    notes: req.body.notes || 'Scanner entry'
  });
  if (result.error) return fail(res, ...result.error);
  const studentInfo = { id: student.id, name: student.name, student_code: student.student_code };
  ok(res, {
    ...result.row,
    student_name: student.name,
    student_code: student.student_code,
    student: studentInfo,
    attendance: result.row
  }, 201);
});

/* -------------------------------- leaves ------------------------------ */

router.get('/leaves', (req, res) => ok(res, scopedLeaves(req)));

router.post('/leaves', (req, res) => {
  const body = req.body || {};
  let studentId = Number(body.student_id);
  if (req.user.role === 'student') {
    studentId = studentOf(req)?.id;
  } else if (req.user.role === 'staff' && !canAccessStudent(req, studentId)) {
    return fail(res, 403, 'Forbidden');
  }
  const required = missing({ ...body, student_id: studentId }, ['student_id', 'from_date', 'to_date', 'reason']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  if (!get('SELECT id FROM students WHERE id = ?', [studentId])) return fail(res, 404, 'Student not found');
  const id = Number(run(
    'INSERT INTO leaves (student_id, from_date, to_date, reason, status, created_at) VALUES (?,?,?,?,?,?)',
    [studentId, body.from_date, body.to_date, body.reason, 'pending', nowIso()]
  ).lastInsertRowid);
  audit(req, 'create', 'leaves', id, { student_id: studentId });
  ok(res, get('SELECT * FROM leaves WHERE id = ?', [id]), 201);
});

router.patch('/leaves/:id', (req, res) => {
  if (req.user.role === 'student') return fail(res, 403, 'Students cannot approve leaves');
  const row = get('SELECT * FROM leaves WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Leave request not found');
  if (req.user.role === 'staff' && !canAccessStudent(req, row.student_id)) return fail(res, 403, 'Forbidden');
  const status = req.body?.status;
  if (!['pending', 'approved', 'rejected'].includes(status)) return fail(res, 400, 'Invalid status');
  patchTable('leaves', row.id, { status });
  const student = get('SELECT user_id, name FROM students WHERE id = ?', [row.student_id]);
  if (student) {
    run('INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
      [student.user_id, 'user', 'Leave request updated', `Your leave request is now ${status}.`, 0, nowIso()]);
  }
  audit(req, 'update', 'leaves', row.id, { status });
  ok(res, get('SELECT * FROM leaves WHERE id = ?', [row.id]));
});

/* -------------------------------- queries ----------------------------- */

router.get('/queries', (req, res) => {
  if (req.user.role === 'owner' || (req.user.role === 'staff' && hasPermission(req, 'queries', 'can_view'))) {
    return ok(res, all('SELECT * FROM queries ORDER BY id DESC'));
  }
  ok(res, all('SELECT * FROM queries WHERE user_id = ? ORDER BY id DESC', [req.user.id]));
});

router.post('/queries', (req, res) => {
  const required = missing(req.body || {}, ['message']);
  if (required.length) return fail(res, 400, 'message is required');
  const id = Number(run(
    'INSERT INTO queries (user_id, role, type, message, status, created_at) VALUES (?,?,?,?,?,?)',
    [req.user.id, req.user.role, req.body.type || 'query', req.body.message, 'open', nowIso()]
  ).lastInsertRowid);
  audit(req, 'create', 'queries', id, { type: req.body.type || 'query' });
  ok(res, get('SELECT * FROM queries WHERE id = ?', [id]), 201);
});

router.patch('/queries/:id', (req, res) => {
  if (req.user.role === 'student') return fail(res, 403, 'Owner or staff only');
  if (req.user.role === 'staff' && !hasPermission(req, 'queries', 'can_edit')) {
    return fail(res, 403, 'No edit permission for queries');
  }
  const row = get('SELECT * FROM queries WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Query not found');
  const values = {};
  if (req.body?.reply !== undefined) values.reply = req.body.reply;
  if (req.body?.status !== undefined) {
    if (!['open', 'replied', 'closed'].includes(req.body.status)) return fail(res, 400, 'Invalid status');
    values.status = req.body.status;
  }
  patchTable('queries', row.id, values);
  run('INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
    [row.user_id, 'user', 'Query reply', `Your query has been updated to ${values.status || row.status}.`, 0, nowIso()]);
  audit(req, 'update', 'queries', row.id, values);
  ok(res, get('SELECT * FROM queries WHERE id = ?', [row.id]));
});

/* ----------------------------- notifications -------------------------- */

router.get('/notifications', (req, res) => ok(res, notificationsFor(req)));

router.post('/notifications', (req, res) => {
  if (req.user.role !== 'owner') return fail(res, 403, 'Owner only');
  const required = missing(req.body || {}, ['title', 'body']);
  if (required.length) return fail(res, 400, `Missing fields: ${required.join(', ')}`);
  const audience = req.body.user_id ? 'user' : (req.body.audience || 'all');
  if (!['user', 'all', 'staff', 'students'].includes(audience)) return fail(res, 400, 'Invalid audience');
  const id = Number(run(
    'INSERT INTO notifications (user_id, audience, title, body, read, created_at) VALUES (?,?,?,?,?,?)',
    [req.body.user_id || null, audience, req.body.title, req.body.body, 0, nowIso()]
  ).lastInsertRowid);
  audit(req, 'create', 'notifications', id, { audience });
  ok(res, get('SELECT * FROM notifications WHERE id = ?', [id]), 201);
});

router.patch('/notifications/:id/read', (req, res) => {
  const row = get('SELECT * FROM notifications WHERE id = ?', [req.params.id]);
  if (!row) return fail(res, 404, 'Notification not found');
  const audience = req.user.role === 'staff' ? 'staff' : 'students';
  const allowed = req.user.role === 'owner' || row.user_id === req.user.id ||
    ['all', audience].includes(row.audience);
  if (!allowed) return fail(res, 403, 'Forbidden');
  patchTable('notifications', row.id, { read: 1 });
  ok(res, get('SELECT * FROM notifications WHERE id = ?', [row.id]));
});

/* -------------------------------- chatbot ----------------------------- */

/* Field-aware answers: when someone asks for specific columns, return only those
   columns instead of a summary or an entire dataset. */
const CHAT_ROW_LIMIT = 12;
const FIELD_SPECS = {
  students: [
    { id: 'name', key: 'name', exportKey: 'name', label: { en: 'Name', ta: 'பெயர்', hi: 'नाम' }, re: /\bname\b|athlete|பெயர்|नाम/i },
    { id: 'sport', key: 'sportName', fallback: 'sport', exportKey: 'sport', label: { en: 'Sport', ta: 'விளையாட்டு', hi: 'खेल' }, re: /sport|discipline|விளையாட்டு|खेल|अनुशासन/i },
    { id: 'coach', key: 'staffName', fallback: 'staff_name', exportKey: 'staffName', label: { en: 'Coach', ta: 'பயிற்சியாளர்', hi: 'कोच' }, re: /coach|trainer|பயிற்சியாளர்|कोच|प्रशिक्षक/i },
    { id: 'code', key: 'student_code', exportKey: 'student_code', label: { en: 'Code', ta: 'குறியீடு', hi: 'कोड' }, re: /\bcode\b|\bid\b|GSA-|குறியீடு|कोड/i },
    { id: 'age', key: 'age', exportKey: 'age', label: { en: 'Age', ta: 'வயது', hi: 'आयु' }, re: /\bage\b|வயது|आयु/i },
    { id: 'email', key: 'email', exportKey: 'email', label: { en: 'Email', ta: 'மின்னஞ்சல்', hi: 'ईमेल' }, re: /e-?mail|மின்னஞ்சல்|ईमेल/i },
    { id: 'phone', key: 'phone', exportKey: 'phone', label: { en: 'Phone', ta: 'தொலைபேசி', hi: 'फोन' }, re: /phone|mobile|contact|தொலைபேசி|फोन|मोबाइल/i },
    { id: 'fees', key: 'fees_pending', exportKey: 'fees_pending', type: 'money', label: { en: 'Fees pending', ta: 'நிலுவைக் கட்டணம்', hi: 'बकाया शुल्क' }, re: /fee|due|pending|கட்டண|நிலுவை|शुल्क|बकाया/i },
    { id: 'school', key: 'school_name', exportKey: 'school_name', label: { en: 'School', ta: 'பள்ளி', hi: 'स्कूल' }, re: /school|பள்ளி|स्कूल/i },
    { id: 'college', key: 'college_name', exportKey: 'college_name', label: { en: 'College', ta: 'கல்லூரி', hi: 'कॉलेज' }, re: /college|கல்லூரி|कॉलेज/i },
    { id: 'years', key: 'ongoing_years', exportKey: 'ongoing_years', label: { en: 'Years', ta: 'ஆண்டுகள்', hi: 'वर्ष' }, re: /years?|duration|ஆண்டு|वर्ष/i },
    { id: 'joined', key: 'joined_date', exportKey: 'joined_date', type: 'date', label: { en: 'Joined', ta: 'சேர்ந்தது', hi: 'जोड़ा गया' }, re: /join|started|சேர்ந்த|जोड़/i },
    { id: 'status', key: 'status', exportKey: 'status', label: { en: 'Status', ta: 'நிலை', hi: 'स्थिति' }, re: /status|நிலை|स्थिति/i },
  ],
  fees: [
    { id: 'student', key: 'student_name', exportKey: 'student_name', label: { en: 'Student', ta: 'மாணவர்', hi: 'छात्र' }, re: /student|athlete|மாணவ|छात्र/i },
    { id: 'sport', key: 'sport', exportKey: 'sport', label: { en: 'Sport', ta: 'விளையாட்டு', hi: 'खेल' }, re: /sport|விளையாட்டு|खेल/i },
    { id: 'type', key: 'type', exportKey: 'type', label: { en: 'Type', ta: 'வகை', hi: 'प्रकार' }, re: /type|monthly|yearly|entry|வகை|प्रकार/i },
    { id: 'amount', key: 'amount', exportKey: 'amount', type: 'money', label: { en: 'Amount', ta: 'தொகை', hi: 'राशि' }, re: /amount|fee|pending|due|balance|தொகை|கட்டண|निलंबित|बकाया|राशि/i },
    { id: 'paid', key: 'paid_amount', exportKey: 'paid_amount', type: 'money', label: { en: 'Paid', ta: 'செலுத்தியது', hi: 'भुगतान' }, re: /paid|collected|செலுத்த|भुगतान/i },
    { id: 'period', key: 'period', exportKey: 'period', label: { en: 'Period', ta: 'காலம்', hi: 'अवधि' }, re: /period|month|காலம்|अवधि|महीना/i },
    { id: 'due', key: 'due_date', exportKey: 'due_date', type: 'date', label: { en: 'Due date', ta: 'காலக்கெடு', hi: 'नियत तारीख' }, re: /due date|deadline|காலக்கெடு|नियत तारीख/i },
    { id: 'status', key: 'status', exportKey: 'status', label: { en: 'Status', ta: 'நிலை', hi: 'स्थिति' }, re: /status|நிலை|स्थिति/i },
  ],
  attendance: [
    { id: 'student', key: 'student_name', exportKey: 'student_name', label: { en: 'Student', ta: 'மாணவர்', hi: 'छात्र' }, re: /student|athlete|name|மாணவ|பெயர்|छात्र|नाम/i },
    { id: 'event', key: 'event', exportKey: 'event', label: { en: 'Event', ta: 'நிகழ்வு', hi: 'घटना' }, re: /event|entry|exit|scanner|நிகழ்வு|वर्ग|प्रवेश|निकासी/i },
    { id: 'date', key: 'date', exportKey: 'date', type: 'date', label: { en: 'Date', ta: 'தேதி', hi: 'तारीख' }, re: /date|day|தேதி|तारीख/i },
    { id: 'time', key: 'time', exportKey: 'time', label: { en: 'Time', ta: 'நேரம்', hi: 'समय' }, re: /time|hour|நேரம்|समय/i },
    { id: 'location', key: 'location', exportKey: 'location', label: { en: 'Location', ta: 'இடம்', hi: 'स्थान' }, re: /location|where|இடம்|स्थान/i },
  ],
  achievements: [
    { id: 'student', key: 'student_name', exportKey: 'student_name', label: { en: 'Student', ta: 'மாணவர்', hi: 'छात्र' }, re: /student|athlete|name|மாணவ|பெயர்|छात्र|नाम/i },
    { id: 'sport', key: 'sport', exportKey: 'sport', label: { en: 'Sport', ta: 'விளையாட்டு', hi: 'खेल' }, re: /sport|விளையாட்டு|खेल/i },
    { id: 'medal', key: 'medal', exportKey: 'medal', label: { en: 'Medal', ta: 'பதக்கம்', hi: 'पदक' }, re: /medal|gold|silver|bronze|பதக்க|पदक|स्वर्ण|रजत/i },
    { id: 'level', key: 'category1', exportKey: 'category1', label: { en: 'Level', ta: 'நிலை', hi: 'स्तर' }, re: /level|district|state|national|international|நிலை|स्तर|राज्य|राष्ट्रीय/i },
    { id: 'category', key: 'category2', exportKey: 'category2', label: { en: 'Category', ta: 'பிரிவு', hi: 'श्रेणी' }, re: /category|junior|senior|sub-junior|youth|பிரிவு|श्रेणी/i },
    { id: 'date', key: 'match_date', exportKey: 'match_date', type: 'date', label: { en: 'Date', ta: 'தேதி', hi: 'तारीख' }, re: /date|when|தேதி|तारीख/i },
  ],
  stock: [
    { id: 'sport', key: 'sport', exportKey: 'sport', label: { en: 'Sport', ta: 'விளையாட்டு', hi: 'खेल' }, re: /sport|விளையாட்டு|खेल/i },
    { id: 'item', key: 'item', exportKey: 'item', label: { en: 'Item', ta: 'பொருள்', hi: 'वस्तु' }, re: /item|equipment|name|பொருள்|உபகரண|वस्तु|उपकरण|नाम/i },
    { id: 'quantity', key: 'quantity', exportKey: 'quantity', label: { en: 'In stock', ta: 'இருப்பில்', hi: 'स्टॉक में' }, re: /quantity|stock|available|low|இருப்பு|कमी|स्टॉक/i },
    { id: 'price', key: 'unit_price', exportKey: 'unit_price', type: 'money', label: { en: 'Unit price', ta: 'அலகு விலை', hi: 'इकाई मूल्य' }, re: /price|cost|விலை|मूल्य/i },
    { id: 'reorder', key: 'reorder_level', exportKey: 'reorder_level', label: { en: 'Reorder at', ta: 'மறு ஆர்டர்', hi: 'पुनः ऑर्डर' }, re: /reorder|threshold|மறு ஆர்டர்|पुनः ऑर्डर/i },
  ],
  income: [
    { id: 'source', key: 'source', exportKey: 'source', label: { en: 'Source', ta: 'மூலம்', hi: 'स्रोत' }, re: /source|from|மூலம்|स्रोत/i },
    { id: 'sport', key: 'sport', exportKey: 'sport', label: { en: 'Sport', ta: 'விளையாட்டு', hi: 'खेल' }, re: /sport|விளையாட்டு|खेल/i },
    { id: 'amount', key: 'amount', exportKey: 'amount', type: 'money', label: { en: 'Amount', ta: 'தொகை', hi: 'राशि' }, re: /amount|income|revenue|expense|தொகை|வருவாய்|राशि|आय|व्यय/i },
    { id: 'date', key: 'date', exportKey: 'date', type: 'date', label: { en: 'Date', ta: 'தேதி', hi: 'तारीख' }, re: /date|when|தேதि|तारीख/i },
    { id: 'description', key: 'description', exportKey: 'description', label: { en: 'Description', ta: 'விவரம்', hi: 'विवरण' }, re: /description|details|note|விவரம்|विवरण/i },
  ],
  announcements: [
    { id: 'title', key: 'title', exportKey: 'title', label: { en: 'Title', ta: 'தலைப்பு', hi: 'शीर्षक' }, re: /title|subject|தலைப்பு|शीर्षक/i },
    { id: 'body', key: 'body', exportKey: 'body', label: { en: 'Message', ta: 'செய்தி', hi: 'संदेश' }, re: /message|body|text|செய்தி|संदेश/i },
    { id: 'date', key: 'date', exportKey: 'date', type: 'date', label: { en: 'Date', ta: 'தேதி', hi: 'तारीख' }, re: /date|when|தேதि|तारीख/i },
    { id: 'author', key: 'author', exportKey: 'author', label: { en: 'Author', ta: 'வெளியிட்டவர்', hi: 'प्रकाशक' }, re: /author|by|who|வெளியிட்ட|प्रकाशक/i },
  ],
};
const DEFAULT_CHAT_FIELDS = {
  students: ['name', 'sport', 'coach'],
  fees: ['student', 'type', 'amount', 'status'],
  attendance: ['student', 'event', 'date', 'time'],
  achievements: ['student', 'medal', 'level', 'date'],
  stock: ['sport', 'item', 'quantity'],
  income: ['source', 'amount', 'date'],
  announcements: ['title', 'date'],
};
const LIST_HINT_RE = /list|show|give|details|names|records|who|which|காட்ட|பட்டியல்|விவர|தரவு|दिखाओ|सूची|विवरण|नाम/i;
const COUNT_RE = /how many|count|total number|number of|எத்தனை|கணக்கு|कितने|कुल संख्या/i;

function shortDate(v) {
  if (!v) return '—';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toISOString().slice(0, 10);
}
function fieldValue(row, spec) {
  let value = row[spec.key];
  if (value === undefined && spec.fallback) value = row[spec.fallback];
  if (Array.isArray(value)) value = value.join(', ');
  if (value && typeof value === 'object') value = JSON.stringify(value);
  if (value === undefined || value === null || value === '') return '—';
  if (spec.type === 'money') return money(value);
  if (spec.type === 'date') return shortDate(value);
  return String(value);
}
function rowHasValue(row, specs, term) {
  const needle = String(term).toLowerCase();
  return specs.some((spec) => {
    const raw = row[spec.exportKey] ?? row[spec.key] ?? (spec.fallback ? row[spec.fallback] : undefined);
    const text = Array.isArray(raw) ? raw.join(', ') : (raw && typeof raw === 'object' ? JSON.stringify(raw) : raw);
    return text != null && String(text).toLowerCase().includes(needle);
  });
}
function projectChatData(dataset, req, message, lang) {
  const specs = FIELD_SPECS[dataset] || [];
  if (!specs.length) return null;
  const matched = specs.filter((s) => s.re.test(message));
  const isCount = COUNT_RE.test(message);
  const wantsList = LIST_HINT_RE.test(message);
  if (isCount && matched.length < 2) return null;
  if (!wantsList && matched.length < 2) return null;

  const ids = matched.length >= 2 ? matched.map((s) => s.id) : (DEFAULT_CHAT_FIELDS[dataset] || []);
  const chosen = specs.filter((s) => ids.includes(s.id));
  if (!chosen.length) return null;

  const scoped = exportRows(req, dataset);
  if (scoped === null) return { denied: true };
  const lowerMessage = message.toLowerCase();
  const values = new Set();
  for (const row of scoped) {
    for (const spec of specs) {
      const raw = row[spec.exportKey] ?? row[spec.key] ?? (spec.fallback ? row[spec.fallback] : undefined);
      const text = Array.isArray(raw) ? raw.join(', ') : (raw && typeof raw === 'object' ? JSON.stringify(raw) : raw);
      const value = text == null ? '' : String(text).trim();
      if (value.length >= 3 && lowerMessage.includes(value.toLowerCase())) values.add(value);
    }
  }
  const terms = [...values].sort((a, b) => b.length - a.length);
  let rows = scoped;
  if (terms.length) {
    const every = scoped.filter((row) => terms.every((term) => rowHasValue(row, specs, term)));
    rows = every.length ? every : scoped.filter((row) => terms.some((term) => rowHasValue(row, specs, term)));
  }
  const total = rows.length;
  const limited = rows.slice(0, CHAT_ROW_LIMIT);
  const fields = chosen.map((s) => ({ key: s.key, label: s.label[lang] || s.label.en }));
  const display = limited.map((r) => {
    const out = {};
    chosen.forEach((s) => { out[s.key] = fieldValue(r, s); });
    return out;
  });
  const head = lang === 'ta'
    ? `கோரப்பட்ட தகவல் (${limited.length}/${total}):`
    : lang === 'hi'
      ? `अनुरोधित जानकारी (${limited.length}/${total}):`
      : `Requested details (${limited.length}/${total}):`;
  const lines = display.map((r, i) => `${i + 1}. ${chosen.map((s) => `${s.label[lang] || s.label.en}: ${r[s.key]}`).join(' · ')}`);
  const more = total > limited.length
    ? (lang === 'ta' ? `${total - limited.length} பதிவுகள் மேலும் உள்ளன. அறிக்கையைப் பதிவிறக்கவும்.` : lang === 'hi' ? `${total - limited.length} और रिकॉर्ड हैं। रिपोर्ट डाउनलोड करें।` : `${total - limited.length} more records. Download the report for all of them.`)
    : '';
  const text = total
    ? [head, ...lines, more].filter(Boolean).join('\n')
    : (lang === 'ta' ? 'உங்கள் அனுமதியில் பதிவுகள் இல்லை.' : lang === 'hi' ? 'आपकी अनुमति में कोई रिकॉर्ड नहीं है।' : 'No records found in your access scope.');
  return {
    fields,
    rows: display,
    total,
    text,
    downloadFields: [...new Set(chosen.map((s) => s.exportKey).filter(Boolean))],
    downloadMatch: terms.join(','),
  };
}

const INTENTS = [
  { key: 'download', re: /download|export|report|\bpdf\b|excel|xlsx|spreadsheet|பதிவிறக்க|அறிக்கை|रिपोर्ट|डाउनलोड|एक्सेल/i },
  { key: 'fees', re: /\bfee|\bfees|pending|due|payment|கட்டண|நிலுவை|பணம்|शुल्क|फी|बकाया|भुगतान/i, dataset: 'fees' },
  { key: 'attendance', re: /attend|present|absent|entry|exit|scanner|வருகை|हाज़री|उपस्थिति|अनुपस्थिति/i, dataset: 'attendance' },
  { key: 'achievements', re: /medal|achieve|prize|winner|trophy|பதக்க|விருது|विजय|पदक|पुरस्कार/i, dataset: 'achievements' },
  { key: 'stock', re: /stock|inventory|equipment|purchase|sold|இருப்பு|உபகரண|स्टॉक|उपकरण|खरीद/i, dataset: 'stock' },
  { key: 'income', re: /income|finance|revenue|expense|money collection|வருவாய்|நிதி|आय|वित्त|व्यय/i, dataset: 'income' },
  { key: 'announcements', re: /announce|notice|circular|அறிவிப்பு|घोषणा|सूचना/i },
  { key: 'students', re: /student|enroll|admission|how many|coach|trainer|மாணவ|சேர்க்கை|பயிற்சியாளர்|छात्र|नामांकन|कोच|प्रशिक्षक/i, dataset: 'students' },
  { key: 'help', re: /\bhelp\b|\bhi\b|\bhello\b|what can you|உதவி|வணக்கம்|सहायता|नमस्ते|मदद/i }
];
function detectIntents(message) {
  return INTENTS.filter((i) => i.re.test(String(message || ''))).map((i) => i.key);
}
function money(n) { return `₹${Math.round(n).toLocaleString('en-IN')}`; }
function deniedReply(lang) {
  if (lang === 'ta') return 'இந்தத் தகவலைப் பார்க்க உங்களுக்கு அனுமதி இல்லை. அறிக்கைகள் பற்றி நான் உதவ முடியும்.';
  if (lang === 'hi') return 'इस जानकारी को देखने की आपके पास अनुमति नहीं है। मैं रिपोर्टों में मदद कर सकता हूँ।';
  return 'You do not have permission to view that information. I can still help with reports and announcements.';
}
function chatContent(intent, req, lang) {
  const role = req.user.role;
  const profile = studentOf(req);
  const students = scopedStudents(req);
  const fees = scopedFees(req);
  const attendance = scopedAttendance(req);
  const achievements = scopedAchievements(req);
  const stock = scopedStock(req);
  const announcements = scopedAnnouncements(req);
  const entryCount = attendance.filter((a) => a.event === 'entry').length;
  const pending = fees.filter((f) => num(f.amount) > num(f.paid_amount));
  const pendingAmount = pending.reduce((acc, f) => acc + Math.max(0, num(f.amount) - num(f.paid_amount)), 0);
  const gold = achievements.filter((a) => a.medal === 'Gold').length;
  const medalCount = achievements.filter((a) => a.medal !== 'Participation').length;
  const lowStock = stock.filter((s) => num(s.quantity) <= num(s.reorder_level)).length;
  const latest = announcements[0]?.title || 'No new announcements';

  if (intent === 'fees') {
    if (role === 'student') {
      const own = fees.filter((f) => f.student_id === profile?.id);
      const amt = own.reduce((acc, f) => acc + Math.max(0, num(f.amount) - num(f.paid_amount)), 0);
      if (lang === 'ta') return `உங்கள் நிலுவைக் கட்டணம் ${money(amt)}. ${own.length} கட்டணப் பதிவுகள் உள்ளன.`;
      if (lang === 'hi') return `आपका बकाया शुल्क ${money(amt)} है। ${own.length} शुल्क रिकॉर्ड हैं।`;
      return `You have ${money(amt)} in pending fees across ${own.length} fee records.`;
    }
    if (role === 'staff' && !hasPermission(req, 'fees', 'can_view')) return deniedReply(lang);
    if (lang === 'ta') return `${pending.length} கட்டணப் பதிவுகளில் நிலுவையாக ${money(pendingAmount)} உள்ளது.`;
    if (lang === 'hi') return `${pending.length} रिकॉर्ड में ${money(pendingAmount)} बकाया शुल्क है।`;
    return `Pending fees total ${money(pendingAmount)} across ${pending.length} records${role === 'staff' ? ' for your students' : ' academy-wide'}.`;
  }
  if (intent === 'attendance') {
    if (role === 'staff' && !hasPermission(req, 'attendance', 'can_view')) return deniedReply(lang);
    if (lang === 'ta') return `கடந்த 30 நாட்களில் ${entryCount} வருகை நிகழ்வுகள் பதிவாகியுள்ளன${role === 'student' ? '' : ' (உங்கள் எல்லைக்குள்)'}. கடைசி நிகழ்வு: ${attendance[0]?.date || 'இல்லை'}.`;
    if (lang === 'hi') return `पिछले 30 दिनों में ${entryCount} उपस्थिति घटनाएँ दर्ज हैं। अंतिम घटना: ${attendance[0]?.date || 'कोई नहीं'}।`;
    return `There are ${entryCount} entry events in the recent attendance records${role === 'owner' ? ' academy-wide' : ''}. Latest: ${attendance[0]?.date || 'none'}.`;
  }
  if (intent === 'achievements') {
    if (role === 'staff' && !hasPermission(req, 'achievements', 'can_view')) return deniedReply(lang);
    if (lang === 'ta') return `ரெக்கார்டுகளில் ${medalCount} பதக்கங்கள் உள்ளன, அவற்றில் ${gold} தங்கப் பதக்கங்கள்.`;
    if (lang === 'hi') return `रिकॉर्ड में ${medalCount} पदक हैं, जिनमें ${gold} स्वर्ण पदक हैं।`;
    return `There are ${medalCount} medals on record, including ${gold} gold medals${role === 'student' ? ' won by you' : ''}.`;
  }
  if (intent === 'stock') {
    if (role === 'student' || (role === 'staff' && !hasPermission(req, 'stock', 'can_view'))) return deniedReply(lang);
    if (lang === 'ta') return `${stock.length} பொருட்கள் இருப்பில் உள்ளன; ${lowStock} மறு-ஆர்டர் அளவிற்குக் குறைவாக உள்ளன.`;
    if (lang === 'hi') return `स्टॉक में ${stock.length} आइटम हैं; ${lowStock} पुनः-ऑर्डर स्तर से कम हैं।`;
    return `There are ${stock.length} stock items, and ${lowStock} are below their reorder level.`;
  }
  if (intent === 'income') {
    if (role === 'student' || (role === 'staff' && !hasPermission(req, 'finance', 'can_view'))) return deniedReply(lang);
    const incomeRows = all('SELECT amount FROM income');
    const expense = sumRows(all("SELECT amount FROM equipment_txns WHERE type = 'purchase'"), 'amount');
    const incomeTotal = sumRows(incomeRows, 'amount');
    if (lang === 'ta') return `மொத்த வருவாய் ${money(incomeTotal)}; மொத்த செலவு ${money(expense)}.`;
    if (lang === 'hi') return `कुल आय ${money(incomeTotal)} है; कुल व्यय ${money(expense)} है।`;
    return `Total recorded income is ${money(incomeTotal)} and expenses are ${money(expense)}.`;
  }
  if (intent === 'announcements') {
    if (lang === 'ta') return `சமீபத்திய அறிவிப்பு: ${latest}. மொத்தம் ${announcements.length} அறிவிப்புகள் உள்ளன.`;
    if (lang === 'hi') return `नवीनतम घोषणा: ${latest}। कुल ${announcements.length} घोषणाएँ हैं।`;
    return `The latest announcement is "${latest}". There are ${announcements.length} announcements for you.`;
  }
  if (intent === 'students') {
    if (role === 'student') {
      if (lang === 'ta') return `நீங்கள் ${profile?.sport || 'விளையாட்டு'} பிரிவில் சேர்ந்துள்ளீர்கள்.`;
      if (lang === 'hi') return `आप ${profile?.sport || 'खेल'} अनुशासन में नामांकित हैं।`;
      return `You are enrolled in ${profile?.sport || 'the academy'} with ${profile?.ongoing_years || 1} years completed.`;
    }
    if (lang === 'ta') return `தற்போது ${students.length} மாணவர்கள் பதிவு செய்யப்பட்டுள்ளனர். பெயர், விளையாட்டு, பயிற்சியாளர் போன்ற குறிப்பிட்ட தகவல்களைக் கேளுங்கள்.`;
    if (lang === 'hi') return `वर्तमान में ${students.length} छात्र पंजीकृत हैं। नाम, खेल, कोच जैसी विशेष जानकारी माँगें।`;
    return `There are ${students.length} students enrolled${role === 'staff' ? ' in your scope' : ' across the academy'}. Ask for specific fields, e.g. "student name, sport and coach".`;
  }
  if (intent === 'download') {
    if (lang === 'ta') return 'அந்த அறிக்கையை நான் தயார் செய்ய முடியும். கீழே உள்ள பதிவிறக்க விருப்பத்தைப் பயன்படுத்தவும்.';
    if (lang === 'hi') return 'मैं वह रिपोर्ट तैयार कर सकता हूँ। नीचे दिए गए डाउनलोड विकल्प का उपयोग करें।';
    return 'I can prepare that report for you. Use the download option below to get it as a file.';
  }
  if (lang === 'ta') {
    return 'நான் கட்டணங்கள், வருகை, பதக்கங்கள், சரக்கு, நிதி, அறிவிப்புகள், மாணவர் எண்ணிக்கை மற்றும் அறிக்கைகள் பற்றி உதவ முடியும். எடுத்துக்காட்டு: "நிலுவைக் கட்டணம் உள்ளதா?"';
  }
  if (lang === 'hi') {
    return 'मैं शुल्क, उपस्थिति, पदक, स्टॉक, वित्त, घोषणाएँ, छात्र संख्या और रिपोर्ट में मदद कर सकता हूँ। उदाहरण: "बकाया शुल्क दिखाओ"।';
  }
  return 'I can help with fees, attendance, medals, stock, finance, announcements, student counts and report downloads. Try: "show pending fees" or "download attendance report".';
}

router.post('/chat', (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message) return fail(res, 400, 'message is required');
  const lang = ['en', 'ta', 'hi'].includes(req.body?.lang) ? req.body.lang : 'en';
  const intents = detectIntents(message);
  const primary = intents.find((i) => i !== 'download' && i !== 'help') || intents[0] || 'help';
  const projection = intents.includes('students') || intents.includes('fees') || intents.includes('attendance') ||
    intents.includes('achievements') || intents.includes('stock') || intents.includes('income') || intents.includes('announcements')
    ? projectChatData(primary, req, message, lang)
    : null;
  const reply = projection ? projection.text : chatContent(primary, req, lang);
  const suggestions = lang === 'ta'
    ? ['மாணவர் பெயர், விளையாட்டு, பயிற்சியாளர்', 'நிலுவைக் கட்டணம்', 'பதக்கங்கள்', 'அறிக்கை பதிவிறக்கு']
    : lang === 'hi'
      ? ['छात्र नाम, खेल, कोच', 'बकाया शुल्क', 'पदक', 'रिपोर्ट डाउनलोड करें']
      : ['Student name, sport and coach', 'Show pending fees', 'Recent medals', 'Download stock report'];
  const payload = { reply, suggestions };
  if (projection && !projection.denied) {
    payload.fields = projection.fields;
    payload.rows = projection.rows;
    payload.total = projection.total;
  }
  if (intents.includes('download')) {
    const allowed = ['students', 'fees', 'income', 'stock', 'attendance', 'achievements', 'announcements'];
    const wanted = intents.find((i) => i !== 'download' && allowed.includes(i));
    const dataset = wanted || (req.user.role === 'student' ? 'fees' : 'students');
    const requestedFields = projection?.downloadFields?.length ? projection.downloadFields : undefined;
    const suffix = projection?.fields?.length
      ? ` (${projection.fields.map((f) => f.label).join(', ')})`
      : '';
    payload.download = {
      format: /\bpdf\b/i.test(message) ? 'pdf' : 'xlsx',
      dataset,
      fields: requestedFields,
      match: projection?.downloadMatch || undefined,
      label: `${dataset.charAt(0).toUpperCase() + dataset.slice(1)} report${suffix}`
    };
  }
  run('INSERT INTO chat_messages (user_id, role, message, lang, reply, created_at) VALUES (?,?,?,?,?,?)',
    [req.user.id, req.user.role, message, lang, reply, nowIso()]);
  ok(res, payload);
});

router.get('/chat/history', (req, res) => {
  ok(res, all('SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 30', [req.user.id]));
});

/* -------------------------------- exports ----------------------------- */

const EXPORT_FIELDS = {
  students: [
    ['student_code', 'Code'], ['name', 'Name'], ['age', 'Age'], ['sport', 'Sport'],
    ['staffName', 'Coach'], ['joined_date', 'Joined'], ['ongoing_years', 'Years'],
    ['email', 'Email'], ['phone', 'Phone'], ['fees_pending', 'Fees Pending'], ['status', 'Status']
  ],
  fees: [
    ['student_name', 'Student'], ['sport', 'Sport'], ['type', 'Type'], ['amount', 'Amount'],
    ['paid_amount', 'Paid'], ['period', 'Period'], ['due_date', 'Due Date'], ['status', 'Status']
  ],
  income: [['source', 'Source'], ['sport', 'Sport'], ['amount', 'Amount'], ['date', 'Date'], ['description', 'Description']],
  stock: [['sport', 'Sport'], ['item', 'Item'], ['quantity', 'Quantity'], ['unit', 'Unit'], ['unit_price', 'Unit Price'], ['reorder_level', 'Reorder Level']],
  attendance: [['student_name', 'Student'], ['event', 'Event'], ['date', 'Date'], ['time', 'Time'], ['location', 'Location'], ['notes', 'Notes']],
  achievements: [['student_name', 'Student'], ['sport', 'Sport'], ['category1', 'Level'], ['category2', 'Category'], ['medal', 'Medal'], ['match_name', 'Event'], ['match_date', 'Date']],
  staff: [['name', 'Name'], ['email', 'Email'], ['category', 'Category'], ['experience', 'Experience'], ['achievement', 'Achievement'], ['sports', 'Sports']],
  announcements: [['title', 'Title'], ['body', 'Body'], ['audience', 'Audience'], ['date', 'Date'], ['author', 'Author']]
};

function exportRows(req, dataset) {
  switch (dataset) {
    case 'students': return scopedStudents(req, 'students', true);
    case 'fees': return scopedFees(req, true);
    case 'income': return req.user.role === 'owner' ? all('SELECT * FROM income ORDER BY date DESC') : null;
    case 'stock': return scopedStock(req, true);
    case 'attendance': return scopedAttendance(req, true);
    case 'achievements': return scopedAchievements(req, true);
    case 'staff': return req.user.role === 'owner'
      ? all('SELECT s.*, u.email FROM staff s JOIN users u ON u.id = s.user_id ORDER BY s.id').map(serializeStaff) : null;
    case 'announcements': return scopedAnnouncements(req);
    default: return null;
  }
}
function flatten(dataset, rows, requestedKeys) {
  const allFields = EXPORT_FIELDS[dataset] || Object.keys(rows[0] || {}).map((k) => [k, k]);
  const wanted = Array.isArray(requestedKeys) && requestedKeys.length ? new Set(requestedKeys) : null;
  const fields = wanted ? allFields.filter(([key]) => wanted.has(key)) : allFields;
  const prepared = rows.map((r) => {
    const out = {};
    for (const [key, label] of fields) {
      const value = r[key];
      out[label] = typeof value === 'object' && value !== null ? JSON.stringify(value) : (value ?? '');
    }
    return out;
  });
  return { headers: fields.map(([, label]) => label), rows: prepared };
}

router.get('/export/:format', (req, res) => {
  const format = req.params.format;
  const dataset = String(req.query.dataset || 'students');
  if (!['pdf', 'xlsx'].includes(format)) return fail(res, 400, 'format must be pdf or xlsx');
  if (!EXPORT_FIELDS[dataset]) return fail(res, 400, `Invalid dataset. Allowed: ${Object.keys(EXPORT_FIELDS).join(', ')}`);
  let data = exportRows(req, dataset);
  if (data === null) return fail(res, 403, 'You are not allowed to export this dataset');
  const matchTerms = String(req.query.match || '').split(',').map((s) => s.trim()).filter((s) => s.length >= 2);
  if (matchTerms.length) {
    const has = (row, term) => Object.values(row).some((v) => v != null && String(v).toLowerCase().includes(term.toLowerCase()));
    const every = data.filter((row) => matchTerms.every((term) => has(row, term)));
    data = every.length ? every : data.filter((row) => matchTerms.some((term) => has(row, term)));
  }
  const requested = String(req.query.fields || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (requested.length && !EXPORT_FIELDS[dataset].some(([key]) => requested.includes(key))) {
    return fail(res, 400, 'None of the requested fields are available for this report');
  }
  const { headers, rows } = flatten(dataset, data, requested);
  const date = nowIso().slice(0, 10);
  const filename = `gsa-${dataset}-${date}`;
  const label = `${dataset.charAt(0).toUpperCase() + dataset.slice(1)} report`;

  if (format === 'xlsx') {
    const sheet = XLSX.utils.json_to_sheet(rows.length ? rows : [headers.reduce((o, h) => ({ ...o, [h]: '' }), {})]);
    sheet['!cols'] = headers.map((h) => ({ wch: Math.max(14, String(h).length + 3) }));
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, dataset.slice(0, 31));
    const buffer = XLSX.write(book, { bookType: 'xlsx', type: 'buffer' });
    res.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.set('Content-Disposition', `attachment; filename="${filename}.xlsx"`);
    return res.send(buffer);
  }

  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  doc.setFontSize(16);
  doc.text('Global Sports Academy - ' + label, 14, 16);
  doc.setFontSize(10);
  doc.text(`Generated: ${date}     Records: ${rows.length}`, 14, 23);
  autoTable(doc, {
    head: [headers], body: rows.map((r) => headers.map((h) => String(r[h]))),
    startY: 28, styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [14, 116, 144], textColor: 255 }
  });
  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `attachment; filename="${filename}.pdf"`);
  res.send(Buffer.from(doc.output('arraybuffer')));
});

export default router;
