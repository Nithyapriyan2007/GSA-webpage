package com.globalsports.academy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
