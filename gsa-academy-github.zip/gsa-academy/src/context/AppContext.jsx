import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api, clearToken, getToken, setToken } from '../lib/api'

const AppContext = createContext(null)

const THEMES = ['aurora', 'ember', 'pro']
const normalizeTheme = (value) => (THEMES.includes(value) ? value : 'aurora')

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}

export function AppProvider({ children }) {
  const [theme, setThemeState] = useState(() => normalizeTheme(localStorage.getItem('gsa_theme')))
  const [user, setUser] = useState(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [bootstrap, setBootstrap] = useState(null)
  const [dashboard, setDashboard] = useState(null)
  const [notifications, setNotifications] = useState([])
  const [toasts, setToasts] = useState([])

  const setTheme = useCallback((next) => {
    const safe = normalizeTheme(next)
    setThemeState(safe)
    localStorage.setItem('gsa_theme', safe)
  }, [])

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    document.documentElement.style.colorScheme = theme === 'pro' ? 'light' : 'dark'
  }, [theme])

  const toast = useCallback((message, tone = 'info') => {
    const id = `${Date.now()}-${Math.random()}`
    setToasts((prev) => [...prev.slice(-3), { id, message, tone }])
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4200)
  }, [])

  const loadBootstrap = useCallback(async () => {
    try {
      const data = await api('/bootstrap')
      setBootstrap(data)
    } catch { /* public bootstrap is optional */ }
  }, [])

  const loadDashboard = useCallback(async () => {
    if (!getToken()) return null
    try {
      const data = await api('/dashboard')
      setDashboard(data)
      return data
    } catch (err) {
      if (err.status === 401) return null
      throw err
    }
  }, [])

  const loadNotifications = useCallback(async () => {
    if (!getToken()) return
    try {
      const data = await api('/notifications')
      const rows = Array.isArray(data) ? data : data.items || []
      setNotifications(rows.map((n) => ({ ...n, is_read: n.is_read ?? n.read ?? 0 })))
    } catch { /* silent */ }
  }, [])

  const refresh = useCallback(async () => {
    await Promise.allSettled([loadDashboard(), loadNotifications(), loadBootstrap()])
  }, [loadDashboard, loadNotifications, loadBootstrap])

  useEffect(() => {
    let alive = true
    ;(async () => {
      if (!getToken()) {
        setAuthLoading(false)
        await loadBootstrap()
        return
      }
      try {
        const data = await api('/auth/me')
        if (!alive) return
        setUser(data.user)
        await Promise.allSettled([loadDashboard(), loadNotifications(), loadBootstrap()])
      } catch {
        clearToken()
      } finally {
        if (alive) setAuthLoading(false)
      }
    })()
    return () => { alive = false }
  }, [loadBootstrap, loadDashboard, loadNotifications])

  useEffect(() => {
    const onLogout = () => {
      setUser(null)
      setDashboard(null)
      setNotifications([])
    }
    window.addEventListener('gsa:logout', onLogout)
    return () => window.removeEventListener('gsa:logout', onLogout)
  }, [])

  // Light polling keeps dashboards, attendance and announcements fresh across portals.
  useEffect(() => {
    if (!user) return undefined
    const id = setInterval(() => {
      loadNotifications()
      loadDashboard()
    }, 20000)
    return () => clearInterval(id)
  }, [user, loadNotifications, loadDashboard])

  const login = useCallback(async (role, identifier, password) => {
    const data = await api('/auth/login', { method: 'POST', body: { role, identifier, password } })
    setToken(data.token)
    setUser(data.user)
    await Promise.allSettled([loadDashboard(), loadNotifications(), loadBootstrap()])
    return data.user
  }, [loadDashboard, loadNotifications, loadBootstrap])

  const logout = useCallback(() => {
    clearToken()
    setUser(null)
    setDashboard(null)
    setNotifications([])
    toast('You have been signed out safely.')
  }, [toast])

  const markRead = useCallback(async (id) => {
    try {
      await api(`/notifications/${id}/read`, { method: 'PATCH' })
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: 1, read: 1 } : n)))
    } catch { /* silent */ }
  }, [])

  const unread = useMemo(() => notifications.filter((n) => !n.is_read).length, [notifications])

  const value = useMemo(
    () => ({
      theme, setTheme, toggleTheme: () => setTheme(THEMES[(THEMES.indexOf(theme) + 1) % THEMES.length]),
      user, authLoading, bootstrap, dashboard, notifications, unread, toasts, toast,
      login, logout, refresh, loadDashboard, loadNotifications, loadBootstrap, markRead,
    }),
    [theme, setTheme, user, authLoading, bootstrap, dashboard, notifications, unread, toasts, toast,
      login, logout, refresh, loadDashboard, loadNotifications, loadBootstrap, markRead],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
