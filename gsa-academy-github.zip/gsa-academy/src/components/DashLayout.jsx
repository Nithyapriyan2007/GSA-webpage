import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Award, BadgeIndianRupee, Bell, Boxes, CalendarDays, ChartNoAxesCombined, ClipboardList,
  FileBarChart, GraduationCap, LayoutDashboard, LogOut, Menu, MessageCircleQuestion,
  Package, ShieldCheck, Users, X,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import { Brand, ThemeToggle } from './SiteChrome'
import NotificationCenter from './NotificationCenter'
import ChatBot from './ChatBot'
import { Avatar } from './ui'
import { titleCase } from '../lib/api'

const ICONS = {
  overview: LayoutDashboard, students: Users, staff: ClipboardList, sports: Award,
  attendance: CalendarDays, achievements: Award, fees: BadgeIndianRupee, stock: Package,
  finance: ChartNoAxesCombined, announcements: Bell, reports: FileBarChart,
  access: ShieldCheck, queries: MessageCircleQuestion, notifications: Bell,
  leaves: CalendarDays, profile: GraduationCap, equipment: Boxes,
}

const SHORT = {
  overview: 'Home', students: 'Students', profile: 'Profile', attendance: 'Attendance',
  announcements: 'News', notifications: 'Alerts', achievements: 'Medals', fees: 'Fees',
}

function navFor(user, dashboard) {
  const p = dashboard?.permissionMap || {}
  const can = (m) => user?.role === 'owner' || !!p[m]?.can_view
  const all = [
    { key: 'overview', label: 'Overview', group: 'Workspace', roles: ['owner', 'staff', 'student'] },
    { key: 'students', label: 'Students', group: 'Academy', roles: ['owner', 'staff'] },
    { key: 'profile', label: 'My Profile', group: 'Academy', roles: ['student'] },
    { key: 'staff', label: 'Staff & Coaches', group: 'Academy', roles: ['owner'] },
    { key: 'sports', label: 'Sports & Disciplines', group: 'Academy', roles: ['owner', 'student'] },
    { key: 'attendance', label: 'Biometric Attendance', group: 'Academy', roles: ['owner', 'staff', 'student'] },
    { key: 'achievements', label: 'Medals & Achievements', group: 'Academy', roles: ['owner', 'staff', 'student'] },
    { key: 'fees', label: 'Fees & Billing', group: 'Operations', roles: ['owner', 'student'], allow: can('fees') },
    { key: 'stock', label: 'Equipment Stock', group: 'Operations', roles: ['owner', 'staff'], allow: can('stock') },
    { key: 'finance', label: 'Finance & Growth', group: 'Operations', roles: ['owner'] },
    { key: 'reports', label: 'Reports & Exports', group: 'Operations', roles: ['owner'] },
    { key: 'access', label: 'Role-based Access', group: 'Operations', roles: ['owner'] },
    { key: 'leaves', label: 'Leave Requests', group: 'Personal', roles: ['owner', 'staff', 'student'] },
    { key: 'announcements', label: 'Announcement Board', group: 'Personal', roles: ['owner', 'staff', 'student'] },
    { key: 'queries', label: 'Queries & Help', group: 'Personal', roles: ['owner', 'staff', 'student'] },
    { key: 'notifications', label: 'Notifications', group: 'Personal', roles: ['owner', 'staff', 'student'] },
  ]
  return all.filter((i) => i.roles.includes(user?.role) && i.allow !== false)
}

export default function DashLayout() {
  const { user, dashboard, logout, theme } = useApp()
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const items = navFor(user, dashboard)
  const active = items.find((i) => pathname === `/app/${i.key}`)
  const Icon = ICONS[active?.key] || LayoutDashboard

  useEffect(() => setOpen(false), [pathname])

  const groups = [...new Set(items.map((i) => i.group))]
  const quickKeys = user?.role === 'student'
    ? ['overview', 'profile', 'attendance', 'announcements', 'notifications']
    : ['overview', 'students', 'attendance', 'announcements', 'notifications']
  const quick = quickKeys.map((k) => items.find((i) => i.key === k)).filter(Boolean)

  return (
    <div className="dash-shell">
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-head" style={{ justifyContent: 'space-between' }}>
          <Brand compact />
          <button className="btn-icon drawer-close" onClick={() => setOpen(false)} aria-label="Close menu"><X size={16} /></button>
        </div>
        <div className="sidebar-scroll">
          {groups.map((g) => (
            <div key={g}>
              <div className="nav-group-label">{g}</div>
              {items.filter((i) => i.group === g).map((item) => {
                const I = ICONS[item.key] || LayoutDashboard
                return (
                  <NavLink key={item.key} to={`/app/${item.key}`} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                    <I size={17} />
                    <span>{item.label}</span>
                    {item.key === 'announcements' && dashboard?.announcements?.length > 0 && <span className="nav-badge">{dashboard.announcements.length}</span>}
                  </NavLink>
                )
              })}
            </div>
          ))}
        </div>
        <div className="sidebar-foot">
          <div className="user-mini">
            <Avatar name={user?.name} tone={user?.role === 'owner' ? '' : 'violet'} />
            <div style={{ minWidth: 0 }}>
              <strong>{user?.name}</strong>
              <small>{user?.role}</small>
            </div>
            <button className="btn-icon" style={{ marginLeft: 'auto', width: 30, height: 30 }} onClick={() => { logout(); navigate('/') }} title="Sign out"><LogOut size={14} /></button>
          </div>
        </div>
      </aside>

      <div className="dash-main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="btn-icon" onClick={() => setOpen((v) => !v)} style={{ display: window.innerWidth <= 860 ? 'inline-grid' : 'none' }} aria-label="Menu"><Menu size={18} /></button>
            <div>
              <div className="topbar-title">{active?.label || titleCase(pathname.split('/').at(-1))}</div>
              <div className="topbar-sub">{user?.role === 'owner' ? 'Global Sports Academy · Command centre' : user?.role === 'staff' ? 'Coach workspace · Role-scoped view' : 'My GSA athlete journey'}</div>
            </div>
          </div>
          <div className="topbar-actions">
            <span className="chip"><span style={{ width: 6, height: 6, borderRadius: 6, background: 'var(--accent)', boxShadow: '0 0 10px var(--accent)' }} /> {theme === 'aurora' ? 'Lavender / Blue' : theme === 'ember' ? 'Orange' : 'Professional White'} theme</span>
            <ThemeToggle />
            <NotificationCenter />
          </div>
        </header>
        <main className="page-content">
          <motion.div key={pathname} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .35 }}>
            <Outlet />
          </motion.div>
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Quick navigation">
        {quick.map((item) => {
          const I = ICONS[item.key] || LayoutDashboard
          return (
            <NavLink key={item.key} to={`/app/${item.key}`} className={({ isActive }) => `mobile-nav-item ${isActive ? 'active' : ''}`}>
              <I size={19} />
              <span>{SHORT[item.key] || item.label.split(' ')[0]}</span>
              {item.key === 'announcements' && dashboard?.announcements?.length > 0 && <i className="mobile-dot" />}
            </NavLink>
          )
        })}
      </nav>
      {open && <div onClick={() => setOpen(false)} style={{ position: 'fixed', inset: 0, background: 'var(--overlay)', zIndex: 45 }} />}
      <ChatBot />
    </div>
  )
}
