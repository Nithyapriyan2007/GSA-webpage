import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Bell, CheckCheck } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { fmtDate } from '../lib/api'

export default function NotificationCenter() {
  const { notifications, unread, markRead } = useApp()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [])

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button className="btn-icon" onClick={() => setOpen((v) => !v)} aria-label="Notifications">
        <Bell size={18} />
        {unread > 0 && <span style={{ position: 'absolute', top: -3, right: -3, minWidth: 17, height: 17, borderRadius: 9, background: 'var(--rose)', color: '#fff', fontSize: '.6rem', display: 'grid', placeItems: 'center', fontWeight: 700 }}>{unread}</span>}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div className="popover glass glass-strong" initial={{ opacity: 0, y: -8, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '.4rem .5rem .7rem' }}>
              <strong>Notifications</strong>
              <span className="badge warn">{unread} new</span>
            </div>
            <div style={{ maxHeight: 330, overflowY: 'auto' }}>
              {notifications.length === 0 && <div className="empty tiny">You're all caught up.</div>}
              {notifications.slice(0, 12).map((n) => (
                <div key={n.id} className={`notif-row ${!n.is_read ? 'unread' : ''}`}>
                  {!n.is_read && <span className="notif-dot" />}
                  <div style={{ flex: 1 }}>
                    <strong style={{ display: 'block', fontSize: '.83rem' }}>{n.title}</strong>
                    <span className="muted" style={{ fontSize: '.75rem', lineHeight: 1.5 }}>{n.body}</span>
                    <div className="faint tiny" style={{ marginTop: '.3rem' }}>{fmtDate(n.created_at)}</div>
                  </div>
                  {!n.is_read && <button className="btn-icon" style={{ width: 28, height: 28 }} onClick={() => markRead(n.id)} title="Mark read"><CheckCheck size={13} /></button>}
                </div>
              ))}
            </div>
            <Link to="/app/notifications" className="btn btn-ghost btn-sm" style={{ width: '100%', marginTop: '.6rem' }} onClick={() => setOpen(false)}>View all notifications</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
