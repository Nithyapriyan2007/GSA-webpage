import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowUpRight, Flame, Instagram, Mail, MapPin, Menu, Phone, Sparkles, Sun, X, Youtube } from 'lucide-react'
import { useApp } from '../context/AppContext'

export function Brand({ compact = false }) {
  return (
    <Link to="/" className="brand" aria-label="Global Sports Academy home">
      <span className="brand-mark">
        <span className="logo-liquid">
          <motion.i className="b1" animate={{ x: [0, 6, -3, 0], y: [0, -4, 4, 0], scale: [1, 1.15, .9, 1] }} transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }} />
          <motion.i className="b2" animate={{ x: [0, -5, 4, 0], y: [0, 5, -3, 0], scale: [1, .9, 1.12, 1] }} transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut' }} />
          <motion.i className="b3" animate={{ x: [0, 4, -4, 0], y: [0, 3, -5, 0], scale: [1, 1.1, .95, 1] }} transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }} />
        </span>
        <span className="logo-letter">G</span>
      </span>
      <span>
        GSA <span className="gradient-text">Global</span>
        {!compact && <small>Sports Academy</small>}
      </span>
    </Link>
  )
}

const THEME_ORDER = ['aurora', 'ember', 'pro']
const THEME_LABELS = { aurora: 'Lavender / Blue', ember: 'Orange', pro: 'Professional White' }
const THEME_ICONS = { aurora: Sparkles, ember: Flame, pro: Sun }

export function ThemeToggle() {
  const { theme, toggleTheme } = useApp()
  const next = THEME_ORDER[(THEME_ORDER.indexOf(theme) + 1) % THEME_ORDER.length]
  const ThemeIcon = THEME_ICONS[theme] || Sparkles
  return (
    <button className="btn-icon" onClick={toggleTheme} title={`Switch to ${THEME_LABELS[next]} theme`} aria-label={`Current theme: ${THEME_LABELS[theme]}`}>
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={theme}
          initial={{ rotate: -90, opacity: 0, scale: .6 }}
          animate={{ rotate: 0, opacity: 1, scale: 1 }}
          exit={{ rotate: 90, opacity: 0, scale: .6 }}
          transition={{ duration: .22 }}
          style={{ display: 'grid', color: 'var(--accent)' }}
        >
          <ThemeIcon size={18} />
        </motion.span>
      </AnimatePresence>
    </button>
  )
}

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/#sports', label: 'Sports' },
  { to: '/#programmes', label: 'Programmes' },
  { to: '/#app', label: 'App' },
  { to: '/#gallery', label: 'Gallery' },
  { to: '/#contact', label: 'Contact' },
]

export function PublicNav() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const { user } = useApp()
  const { pathname, hash } = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])
  useEffect(() => setOpen(false), [pathname, hash])

  const go = (to) => {
    if (to.includes('#')) {
      const id = to.split('#')[1]
      if (pathname === '/') {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
      } else {
        window.location.href = `/#${id}`
      }
    }
  }

  return (
    <header className={`pnav ${scrolled ? 'scrolled' : ''}`}>
      <div className="admit-bar">
        <span className="admit-pill">Admissions open</span>
        <span>Fencing, Table Tennis, Carrom, Chess &amp; Fitness. Book a trial class today.</span>
        <button type="button" className="admit-link" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>Book now</button>
      </div>
      <div className="pnav-inner">
        <Brand />
        <nav className={`nav-links ${open ? 'open' : ''}`}>
          {links.map((l) => (
            <NavLink
              key={l.label}
              to={l.to}
              end={l.end}
              onClick={(e) => { if (l.to.includes('#')) { e.preventDefault(); go(l.to); setOpen(false) } }}
              className={({ isActive }) => (l.to.includes('#') ? '' : isActive ? 'active' : '')}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="nav-actions">
          <ThemeToggle />
          <Link className="btn btn-primary btn-sm" to={user ? '/app' : '/login'}>
            {user ? 'Dashboard' : 'Portal Login'} <ArrowUpRight size={15} />
          </Link>
          <button className="btn-icon menu-btn" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>
    </header>
  )
}

export function PublicFooter() {
  return (
    <footer className="footer" id="contactfooter">
      <div className="container">
        <div className="footer-grid">
          <div>
            <Brand />
            <p style={{ marginTop: '1rem', maxWidth: 320 }}>
              Not just a sports academy — a launchpad. From the first fencing step to national medals, sports-quota admissions and government careers, we walk the whole path with every athlete.
            </p>
            <div style={{ display: 'flex', gap: '.5rem', marginTop: '1rem' }}>
              <a className="btn-icon" href="https://wa.me/919042999507" target="_blank" rel="noreferrer" title="WhatsApp"><Mail size={16} /></a>
              <a className="btn-icon" href="https://www.instagram.com/" target="_blank" rel="noreferrer" title="Instagram"><Instagram size={16} /></a>
              <a className="btn-icon" href="https://www.youtube.com/" target="_blank" rel="noreferrer" title="YouTube"><Youtube size={16} /></a>
            </div>
          </div>
          <div>
            <h4>Explore</h4>
            <Link to="/#sports">Our Sports</Link>
            <Link to="/#programmes">Programmes</Link>
            <Link to="/#app">Academy App</Link>
            <Link to="/#gallery">Gallery</Link>
            <Link to="/#pathway">Sports Quota Path</Link>
          </div>
          <div>
            <h4>Portals</h4>
            <Link to="/login?role=owner">Owner Login</Link>
            <Link to="/login?role=staff">Staff Login</Link>
            <Link to="/login?role=student">Student Login</Link>
          </div>
          <div>
            <h4>Reach us</h4>
            <a href="tel:9042999507"><Phone size={13} style={{ display: 'inline' }} /> 9042999507</a>
            <a href="mailto:globalsportsnkl@gmail.com"><Mail size={13} style={{ display: 'inline' }} /> globalsportsnkl@gmail.com</a>
            <p><MapPin size={13} style={{ display: 'inline' }} /> Global Sports Academy</p>
            <p>Nochipattiyar Thottam, Mudhalaipatti, Namakkal</p>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Global Sports Academy. Built for champions.</span>
          <span>25 years of coaching · 8 disciplines · One family</span>
        </div>
      </div>
    </footer>
  )
}
