import { useEffect, useRef, useState } from 'react'
import { motion, useInView, useMotionValue, useSpring, animate } from 'framer-motion'
import { Inbox, X } from 'lucide-react'
import { initials, statusTone } from '../lib/api'

export function Reveal({ children, delay = 0, y = 28, className = '', once = true }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: '-60px' }}
      transition={{ duration: .65, delay, ease: [.2, .8, .2, 1] }}
    >
      {children}
    </motion.div>
  )
}

export function Counter({ to = 0, suffix = '', prefix = '', decimals = 0, duration = 1.8 }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-50px' })
  const [value, setValue] = useState(0)
  useEffect(() => {
    if (!inView) return undefined
    const controls = animate(0, Number(to) || 0, {
      duration,
      ease: [.2, .8, .2, 1],
      onUpdate: (v) => setValue(v),
    })
    return () => controls.stop()
  }, [inView, to, duration])
  return (
    <span ref={ref}>
      {prefix}{value.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}{suffix}
    </span>
  )
}

export function TiltCard({ children, className = '', max = 7 }) {
  const ref = useRef(null)
  const rx = useSpring(useMotionValue(0), { stiffness: 180, damping: 18 })
  const ry = useSpring(useMotionValue(0), { stiffness: 180, damping: 18 })
  const onMove = (e) => {
    const r = ref.current?.getBoundingClientRect()
    if (!r) return
    rx.set(((e.clientY - r.top) / r.height - .5) * -max)
    ry.set(((e.clientX - r.left) / r.width - .5) * max)
  }
  const reset = () => { rx.set(0); ry.set(0) }
  return (
    <motion.div
      ref={ref}
      className={className}
      onMouseMove={onMove}
      onMouseLeave={reset}
      style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }}
    >
      {children}
    </motion.div>
  )
}

export function SectionHeading({ eyebrow, title, description, center, children }) {
  return (
    <div className={`section-head ${center ? 'center' : ''}`}>
      <Reveal>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2 className="h2">{title}</h2>
        {description && <p className="lead">{description}</p>}
        {children}
      </Reveal>
    </div>
  )
}

export function Badge({ children, tone, className = '' }) {
  const t = tone || statusTone(children)
  return <span className={`badge ${t} ${className}`}>{children}</span>
}

export function Avatar({ name, tone = '', size }) {
  return (
    <div className={`avatar ${tone}`} style={size ? { width: size, height: size } : undefined} title={name}>
      {initials(name)}
    </div>
  )
}

export function EmptyState({ title = 'Nothing here yet', text }) {
  return (
    <div className="empty">
      <div className="ic"><Inbox size={22} /></div>
      <strong>{title}</strong>
      {text && <p className="tiny">{text}</p>}
    </div>
  )
}

export function Modal({ open, onClose, title, subtitle, children, wide, footer }) {
  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && onClose?.()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  if (!open) return null
  return (
    <motion.div className="modal-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
      <motion.div className={`modal glass glass-strong ${wide ? 'wide' : ''}`} initial={{ scale: .94, y: 18 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 260, damping: 24 }}>
        <div className="modal-head">
          <div>
            <h3 className="h3">{title}</h3>
            {subtitle && <p className="muted tiny" style={{ margin: '.3rem 0 0' }}>{subtitle}</p>}
          </div>
          <button className="btn-icon" onClick={onClose} aria-label="Close"><X size={17} /></button>
        </div>
        {children}
        {footer && <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1.2rem' }}>{footer}</div>}
      </motion.div>
    </motion.div>
  )
}

export function RingProgress({ value = 0, size = 104, stroke = 9, color = 'var(--gold)', label }) {
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const pct = Math.max(0, Math.min(100, Number(value) || 0))
  return (
    <div className="ring-wrap" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--chip)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (pct / 100) * c }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
        />
      </svg>
      <div className="ring-label">
        <b>{Math.round(pct)}%</b>
        {label && <small className="muted">{label}</small>}
      </div>
    </div>
  )
}
