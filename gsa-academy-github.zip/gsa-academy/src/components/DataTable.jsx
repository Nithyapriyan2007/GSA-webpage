import { useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight, Search } from 'lucide-react'
import { EmptyState } from './ui'

export default function DataTable({ data = [], columns = [], searchKeys = [], pageSize = 8, toolbar, emptyText }) {
  const [q, setQ] = useState('')
  const [sort, setSort] = useState(null)
  const [page, setPage] = useState(0)

  const filtered = useMemo(() => {
    let rows = [...data]
    const needle = q.toLowerCase().trim()
    if (needle) {
      rows = rows.filter((r) => searchKeys.length
        ? searchKeys.some((k) => String(r[k] ?? '').toLowerCase().includes(needle))
        : Object.values(r).some((v) => String(v ?? '').toLowerCase().includes(needle)))
    }
    if (sort) {
      rows.sort((a, b) => {
        const av = a[sort] ?? '', bv = b[sort] ?? ''
        const n = Number(av) - Number(bv)
        return Number.isNaN(n) ? String(av).localeCompare(String(bv)) : n
      })
    }
    return rows
  }, [data, q, sort, searchKeys])

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const current = Math.min(page, pages - 1)
  const rows = filtered.slice(current * pageSize, (current + 1) * pageSize)

  return (
    <div>
      <div className="table-tools">
        <div className="input-wrap" style={{ flex: 1, minWidth: 200, maxWidth: 330 }}>
          <Search size={15} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} />
          <input className="input" style={{ paddingLeft: '2.2rem' }} value={q} onChange={(e) => { setQ(e.target.value); setPage(0) }} placeholder="Search records…" />
        </div>
        {toolbar}
        <span className="chip" style={{ marginLeft: 'auto' }}>{filtered.length} records</span>
      </div>
      {rows.length === 0 ? <EmptyState text={emptyText || 'Try a different search.'} /> : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {columns.map((c) => (
                  <th key={c.key || c.label} onClick={() => c.sortable !== false && c.key && setSort(sort === c.key ? null : c.key)} style={{ cursor: c.sortable === false ? 'default' : 'pointer' }}>
                    {c.label}{sort === c.key ? ' ↕' : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={row.id ?? i}>
                  {columns.map((c) => <td key={c.key || c.label}>{c.render ? c.render(row, i) : row[c.key] ?? '—'}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {filtered.length > pageSize && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}>
          <span className="faint tiny">Page {current + 1} of {pages}</span>
          <button className="btn-icon" disabled={current === 0} onClick={() => setPage(current - 1)}><ChevronLeft size={15} /></button>
          <button className="btn-icon" disabled={current >= pages - 1} onClick={() => setPage(current + 1)}><ChevronRight size={15} /></button>
        </div>
      )}
    </div>
  )
}
