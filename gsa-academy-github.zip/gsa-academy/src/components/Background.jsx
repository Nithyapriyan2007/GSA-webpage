import { motion, useReducedMotion } from 'framer-motion'

const TOPO_LINES = Array.from({ length: 9 }, (_, i) => {
  const y = 70 + i * 88
  return {
    base: `M -200 ${y} C 180 ${y - 72} 520 ${y + 88} 860 ${y} S 1320 ${y - 58} 1700 ${y + 34}`,
    width: i % 3 === 0 ? 1.4 : 0.9,
  }
})

function TopographicField() {
  const reduced = useReducedMotion()
  return (
    <div className="bg-topo">
      <svg viewBox="0 0 1440 900" preserveAspectRatio="none" aria-hidden="true">
        {TOPO_LINES.map((line, i) => (
          <motion.path
            key={i}
            d={line.base}
            style={{ strokeWidth: line.width, transformOrigin: 'center' }}
            animate={reduced ? undefined : { y: [0, -10 + i, 0], scaleX: [1, 1.04, 1], opacity: [.7, 1, .7] }}
            transition={{ duration: 18 + i * 1.8, repeat: Infinity, ease: 'easeInOut' }}
          />
        ))}
      </svg>
    </div>
  )
}

export default function Background() {
  return (
    <div className="bg-stage" aria-hidden="true">
      <div className="bg-grid" />
      <TopographicField />
      <div className="orb a" />
      <div className="orb b" />
      <div className="orb c" />
      <div className="bg-scan" />
      <div className="bg-noise" />
    </div>
  )
}
