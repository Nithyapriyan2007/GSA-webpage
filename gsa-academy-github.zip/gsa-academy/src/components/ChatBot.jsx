import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Bot, Download, Mic, Send, Sparkles, Volume2, VolumeX, X } from 'lucide-react'
import { api, downloadReport, fmtDate } from '../lib/api'
import { useApp } from '../context/AppContext'

const LANGS = [
  { id: 'en', label: 'EN', voice: 'en-IN' },
  { id: 'ta', label: 'அம்', voice: 'ta-IN' },
  { id: 'hi', label: 'हिं', voice: 'hi-IN' },
]

const GREETINGS = {
  owner: { en: 'Owner console ready. Ask me about fees, attendance, medals, stock, finance or ask me to download a report.', ta: 'உரிமையாளர் கன்சோல் தயார். கட்டணம், வருகை, பதக்கங்கள், இருப்பு, நிதி அல்லது அறிக்கை பதிவிறக்கம் கேளுங்கள்.', hi: 'ओनर कंसोल तैयार है। फी, उपस्थिति, पदक, स्टॉक, वित्त या रिपोर्ट डाउनलोड के बारे में पूछें।' },
  staff: { en: 'Coach assistant ready. I only show data your owner has permitted for your role.', ta: 'பயிற்சியாளர் உதவியாளர் தயார். உரிமையாளர் உங்கள் பங்குக்கு அனுமதித்த தகவலை மட்டும் காண்பிப்பேன்.', hi: 'कोच सहायक तैयार है। मैं केवल वही डेटा दिखाऊँगा जो मालिक ने आपकी भूमिका के लिए अनुमोदित किया है।' },
  student: { en: 'Athlete assistant ready. Ask about your attendance, fees, medals, leave or academy announcements.', ta: 'விளையாட்டு உதவியாளர் தயார். உங்கள் வருகை, கட்டணம், பதக்கங்கள், விடுதலை அல்லது அறிவிப்புகளைக் கேளுங்கள்.', hi: 'एथलीट सहायक तैयार है। अपनी उपस्थिति, फी, पदक, छुट्टी या घोषणाओं के बारे में पूछें।' },
}

const SUGGESTIONS = {
  owner: ['Show pending fees', 'Download students PDF', 'Today attendance', 'Low stock items', 'Academy income'],
  staff: ['My students', 'Medals this year', 'Download attendance', 'Announcements', 'Help'],
  student: ['My medals', 'My fees', 'My attendance', 'Download my report', 'Announcements'],
}

export default function ChatBot() {
  const { user } = useApp()
  const [open, setOpen] = useState(false)
  const [lang, setLang] = useState('en')
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [speak, setSpeak] = useState(false)
  const [messages, setMessages] = useState([])
  const bodyRef = useRef(null)
  const role = user?.role || 'owner'
  const greeting = GREETINGS[role][lang]

  useEffect(() => {
    if (!open || !user) return
    api('/chat/history').then((d) => {
      const rows = Array.isArray(d) ? d : d.messages || []
      setMessages(rows.map((m) => ({ from: m.role === 'user' ? 'me' : 'bot', text: m.message || m.text })))
    }).catch(() => {})
  }, [open, user])

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, busy])

  useEffect(() => () => window.speechSynthesis?.cancel(), [])

  const talk = (value) => {
    if (!speak || !('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(value)
    u.lang = LANGS.find((l) => l.id === lang)?.voice || 'en-IN'
    u.rate = .95
    window.speechSynthesis.speak(u)
  }

  const send = async (value) => {
    const message = (value ?? text).trim()
    if (!message || busy) return
    setMessages((prev) => [...prev, { from: 'me', text: message }])
    setText('')
    setBusy(true)
    try {
      const res = await api('/chat', { method: 'POST', body: { message, lang } })
      setMessages((prev) => [
        ...prev,
        { from: 'bot', text: res.reply, suggestions: res.suggestions, download: res.download, fields: res.fields, rows: res.rows, total: res.total },
      ])
      talk(res.reply)
    } catch (err) {
      setMessages((prev) => [...prev, { from: 'bot', text: `⚠️ ${err.message}` }])
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div className="chat-panel glass glass-strong" initial={{ opacity: 0, y: 24, scale: .95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 18, scale: .96 }} transition={{ type: 'spring', stiffness: 260, damping: 24 }}>
            <div className="chat-head">
              <div className="avatar" style={{ width: 40, height: 40 }}><Bot size={19} /></div>
              <div style={{ flex: 1 }}>
                <strong style={{ fontSize: '.9rem' }}>GSA Assist</strong>
                <div className="faint tiny">{role === 'owner' ? 'Full academy access' : role === 'staff' ? 'Role-scoped access' : 'Your athlete data'} · speaks EN / தமிழ் / हिंदी</div>
              </div>
              <div className="lang-switch">
                {LANGS.map((l) => <button key={l.id} className={lang === l.id ? 'active' : ''} onClick={() => setLang(l.id)}>{l.label}</button>)}
              </div>
              <button className="btn-icon" onClick={() => setSpeak((v) => !v)} title={speak ? 'Mute voice' : 'Enable voice'}>{speak ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
              <button className="btn-icon" onClick={() => setOpen(false)}><X size={16} /></button>
            </div>
            <div className="chat-body" ref={bodyRef}>
              <div className="bubble bot"><Sparkles size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />{greeting}</div>
              {messages.map((m, i) => (
                <div key={i} style={{ display: 'contents' }}>
                  <div className={`bubble ${m.from}`}>{m.text}</div>
                  {m.from === 'bot' && m.fields?.length > 0 && m.rows?.length > 0 && (
                    <div className="chat-data">
                      <div className="chat-data-head">
                        {m.fields.length} {m.fields.length === 1 ? 'field' : 'fields'} · showing {m.rows.length} of {m.total}
                      </div>
                      <div className="chat-table-wrap">
                        <table className="chat-table">
                          <thead><tr>{m.fields.map((f) => <th key={f.key}>{f.label}</th>)}</tr></thead>
                          <tbody>
                            {m.rows.map((row, ri) => (
                              <tr key={ri}>{m.fields.map((f) => <td key={f.key}>{row[f.key]}</td>)}</tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                  {m.download && (
                    <button className="btn btn-outline btn-sm" style={{ alignSelf: 'flex-start' }} onClick={() => downloadReport(m.download.format, m.download.dataset, m.download.dataset, m.download.fields, m.download.match)}>
                      <Download size={13} /> {m.download.label || `Download ${m.download.dataset}.${m.download.format}`}
                    </button>
                  )}
                </div>
              ))}
              {busy && <div className="bubble bot"><span className="spinner" style={{ width: 16, height: 16, display: 'inline-block', verticalAlign: 'middle' }} /> Thinking…</div>}
            </div>
            <div className="chat-suggest">
              {(messages.at(-1)?.suggestions || SUGGESTIONS[role]).slice(0, 4).map((s) => (
                <button key={s} onClick={() => send(s)}>{s}</button>
              ))}
            </div>
            <form className="chat-input-row" onSubmit={(e) => { e.preventDefault(); send() }}>
              <button type="button" className="btn-icon" title="Ask by voice" onClick={() => {
                const SR = window.SpeechRecognition || window.webkitSpeechRecognition
                if (!SR) { setText('Voice input not supported in this browser'); return }
                const r = new SR(); r.lang = LANGS.find((l) => l.id === lang)?.voice || 'en-IN'
                r.onresult = (e) => setText(e.results[0][0].transcript)
                r.start()
              }}><Mic size={16} /></button>
              <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder={lang === 'ta' ? 'கேள்வியைத் தட்டச்சு செய்யுங்கள்…' : lang === 'hi' ? 'अपना सवाल लिखें…' : 'Ask about fees, medals, reports…'} />
              <button className="btn btn-primary btn-sm" type="submit" disabled={busy || !text.trim()}><Send size={15} /></button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button className="chat-fab" onClick={() => setOpen((v) => !v)} whileHover={{ scale: 1.06 }} aria-label="Open GSA assistant">
        {open ? <X size={24} /> : <Bot size={26} />}
      </motion.button>
    </>
  )
}
