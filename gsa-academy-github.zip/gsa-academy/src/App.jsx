import { Link, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { CheckCircle2, Info, TriangleAlert } from 'lucide-react'
import Background from './components/Background'
import DashLayout from './components/DashLayout'
import { useApp } from './context/AppContext'
import Home from './pages/public/Home'
import Login from './pages/public/Login'
import Overview from './pages/dash/Overview'
import {
  AnnouncementsPage, LeavesPage, NotificationsPage, QueriesPage,
} from './pages/dash/CommonPages'
import {
  OwnerAccess, OwnerReports, OwnerSports, OwnerStaff, OwnerStudents,
} from './pages/dash/OwnerPages'
import {
  AchievementsPage, AttendancePage, FeesPage, FinancePage, StockPage,
} from './pages/dash/OperationsPages'
import { StaffProfile, StaffStudents, StudentProfile, StudentSports } from './pages/dash/RolePages'

function ProtectedRoute({ children }) {
  const { user, authLoading } = useApp()
  const location = useLocation()
  if (authLoading) return <div className="loader"><div className="spinner" /></div>
  if (!user) return <Navigate to="/login" state={{ from: location.pathname }} replace />
  return children
}

function Only({ roles, children }) {
  const { user } = useApp()
  return roles.includes(user?.role) ? children : <Navigate to="/app/overview" replace />
}

function ToastHost() {
  const { toasts } = useApp()
  return (
    <div className="toast-wrap">
      {toasts.map((t) => (
        <div className={`toast glass glass-strong ${t.tone}`} key={t.id}>
          {t.tone === 'bad' ? <TriangleAlert size={17} color="var(--rose)" /> : t.tone === 'warn' ? <Info size={17} color="var(--gold)" /> : <CheckCircle2 size={17} color="var(--green)" />}
          <span>{t.message}</span>
        </div>
      ))}
    </div>
  )
}

function NotFound() {
  return (
    <div className="container section center" style={{ minHeight: '70vh', display: 'grid', placeItems: 'center' }}>
      <div>
        <div className="gradient-text" style={{ fontSize: '7rem', fontWeight: 800, lineHeight: 1 }}>404</div>
        <h2 className="h2">This path isn’t on the map.</h2>
        <p className="lead center" style={{ margin: '0 auto 1.5rem' }}>Let’s get you back to the academy.</p>
        <Link className="btn btn-primary" to="/">Go home</Link>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <>
      <Background />
      <Routes>
        <Route path="/" element={<><Home /></>} />
        <Route path="/login" element={<Login />} />
        <Route path="/app" element={<ProtectedRoute><DashLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="overview" replace />} />
          <Route path="overview" element={<Overview />} />

          <Route path="students" element={<ProtectedRoute>{/* role switch */}<StudentsRouter /></ProtectedRoute>} />
          <Route path="staff" element={<Only roles={['owner']}><OwnerStaff /></Only>} />
          <Route path="sports" element={<Only roles={['owner', 'student']}><SportsRouter /></Only>} />
          <Route path="finance" element={<Only roles={['owner']}><FinancePage /></Only>} />
          <Route path="reports" element={<Only roles={['owner']}><OwnerReports /></Only>} />
          <Route path="access" element={<Only roles={['owner']}><OwnerAccess /></Only>} />

          <Route path="attendance" element={<AttendancePage />} />
          <Route path="achievements" element={<AchievementsPage />} />
          <Route path="fees" element={<Only roles={['owner', 'student']}><FeesPage /></Only>} />
          <Route path="stock" element={<Only roles={['owner', 'staff']}><StockPage /></Only>} />
          <Route path="leaves" element={<LeavesPage />} />
          <Route path="announcements" element={<AnnouncementsPage />} />
          <Route path="queries" element={<QueriesPage />} />
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="profile" element={<ProfileRouter />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
      <ToastHost />
    </>
  )
}

function StudentsRouter() {
  const { user } = useApp()
  if (user?.role === 'owner') return <OwnerStudents />
  if (user?.role === 'staff') return <StaffStudents />
  return <Navigate to="/app/profile" replace />
}

function SportsRouter() {
  const { user } = useApp()
  return user?.role === 'owner' ? <OwnerSports /> : <StudentSports />
}

function ProfileRouter() {
  const { user } = useApp()
  if (user?.role === 'student') return <StudentProfile />
  if (user?.role === 'staff') return <StaffProfile />
  return <Navigate to="/app/staff" replace />
}
