import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, useScroll, useTransform } from 'framer-motion'
import {
  ArrowRight, BadgeCheck, Camera, Crosshair, Dumbbell, GraduationCap,
  HeartPulse, Landmark, Mail, MapPin, Medal, MessageCircle, Phone, ScanFace, ShieldCheck, Trophy,
} from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { Reveal, Counter, TiltCard, SectionHeading, Badge } from '../../components/ui'
import { PublicFooter, PublicNav } from '../../components/SiteChrome'

const MAP_URL = 'https://maps.app.goo.gl/diXTb2Q2biaQ7ePq6'
const MAP_EMBED_URL = 'https://www.google.com/maps?q=11.2543918,78.1574524&output=embed&z=17'

const DEFAULT_SPORTS = [
  { name: 'Fencing', icon: '🤺', color: '#f5b942', types: ['Foil', 'Épée', 'Sabre', 'Team Events'], description: 'Our flagship discipline — technique, timing and tactical intelligence.', featured: 1 },
  { name: 'Chess', icon: '♟️', color: '#a78bfa', types: ['Classical', 'Rapid', 'Blitz'], description: 'Calculated thinking and competitive patience from day one.' },
  { name: 'Carrom', icon: '🎯', color: '#5eead4', types: ['Singles', 'Doubles', 'Board Practice'], description: 'Precision, focus and calm under pressure.' },
  { name: 'Yoga', icon: '🧘', color: '#6aa9ff', types: ['Hatha', 'Flow', 'Breathwork'], description: 'Body control and recovery that supports every sport.' },
  { name: 'Drawing', icon: '🎨', color: '#fb7185', types: ['Sketching', 'Painting', 'Mixed Media'], description: 'Creative focus and a confident visual voice.' },
  { name: 'Cricket', icon: '🏏', color: '#4ade80', types: ['Batting', 'Bowling', 'Fielding'], description: 'Fundamentals, match temperament and team play.' },
  { name: 'Archery', icon: '🏹', color: '#f5b942', types: ['Recurve', 'Compound', 'Indoor'], description: 'Steady aim, breath control and repeatable form.' },
  { name: 'Table Tennis', icon: '🏓', color: '#5eead4', types: ['Singles', 'Doubles', 'Footwork Drills'], description: 'Quick reflexes and sharphand-eye coordination.' },
]

const FACILITIES = [
  { icon: Camera, title: '24 × 7 CCTV Coverage', text: 'Round-the-clock surveillance with a complete 360° view of the academy — a safe space, every hour of every day.', tint: 'teal' },
  { icon: ScanFace, title: 'Biometric Attendance', text: 'Every entry and exit is recorded with date, time and identity. Parents get live notifications on the website and app.', tint: '' },
  { icon: ShieldCheck, title: 'Safety Guarantee', text: 'Professional, sport-specific equipment, supervised drills and strict safety protocols for every training session.', tint: 'violet' },
  { icon: Dumbbell, title: 'Athlete-Only Training Zone', text: 'Our strength and conditioning area is reserved only for students in training, so each athlete builds the exact fitness their sport needs.', tint: 'rose' },
]

const PATH = [
  { n: '01', title: 'Classes 10 – 12', text: 'We identify each athlete’s sport early and build a disciplined training plan alongside school academics.' },
  { n: '02', title: 'District → State → National medals', text: 'Structured competition exposure in Sub-Junior, Junior, Senior and Youth categories. Every medal is a documented stepping stone.' },
  { n: '03', title: 'College through sports quota', text: 'Medal records and guided applications help athletes enter top-ranked universities and private colleges through sports quota — including Anna University.' },
  { n: '04', title: 'Government career pathways', text: 'If athletes continue the sport and keep winning, we guide them toward government jobs and teams where sports-quota seats are reserved.' },
]

const FAQS = [
  { q: 'What age can my child start?', a: 'Children can begin from the Sub Junior group. Coaches place each student in the right age category and level after a short assessment.' },
  { q: 'Can we try a class before joining?', a: 'Yes. Share your name, phone number, sport and your child’s age in the trial form below, or call 9042999507. We will confirm the right batch and book a trial class.' },
  { q: 'Which sport is the academy best known for?', a: 'Fencing is our flagship discipline — Foil, Épée and Sabre — with 25 years of coaching experience. We also teach Table Tennis, Carrom, Chess, Cricket, Archery, Yoga and Drawing.' },
  { q: 'How do I follow my child’s progress?', a: 'The parent view in the website and Android app shows attendance, fee status, medals, coach remarks and announcements. Arrival alerts and late/absent flags keep you informed every day.' },
  { q: 'How are fees collected?', a: 'Each sport has a clear fee plan. Bills, due dates and payment confirmations are recorded in the app, with reminders for pending fees.' },
  { q: 'Is my child’s information safe?', a: 'Yes. The academy owner, coaches and students each see only the data their role allows. Medical details and private records are role-scoped, with 24/7 CCTV and biometric entry records for physical safety.' },
  { q: 'How can I talk to the academy?', a: 'Call or WhatsApp 9042999507, email globalsportsnkl@gmail.com, or find Global Sports Academy on Google Maps. Queries, suggestions and help are also available inside every portal.' },
]

function Hero() {
  const ref = useState(null)[0]
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '22%'])
  const op = useTransform(scrollYProgress, [0, .8], [1, 0])
  const { bootstrap } = useApp()

  return (
    <section className="hero" ref={ref}>
      <motion.div className="container hero-grid" style={{ opacity: op }}>
        <div>
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }}>
            <span className="eyebrow">Indoor sports academy · Namakkal · Since 2001</span>
          </motion.div>
          <motion.h1 className="h1" initial="hidden" animate="show" variants={{ show: { transition: { staggerChildren: .12, delayChildren: .1 } } }}>
            <motion.span className="block" variants={{ hidden: { opacity: 0, y: 40 }, show: { opacity: 1, y: 0, transition: { duration: .7 } } }}>Where young athletes</motion.span>
            <motion.span className="block gradient-text" variants={{ hidden: { opacity: 0, y: 40 }, show: { opacity: 1, y: 0, transition: { duration: .7 } } }}>train, compete</motion.span>
            <motion.span className="block" variants={{ hidden: { opacity: 0, y: 40 }, show: { opacity: 1, y: 0, transition: { duration: .7 } } }}>and win.</motion.span>
          </motion.h1>
          <motion.p className="lead" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .5, duration: .6 }}>
            Fencing, Table Tennis, Carrom, Chess, Cricket, Archery, Yoga, Drawing and physical fitness — certified coaching for every age category, plus an app that keeps coaches, parents and athletes on the same page.
          </motion.p>
          <motion.div className="hero-actions" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .65 }}>
            <a className="btn btn-primary" href="#contact">Book a trial class <ArrowRight size={17} /></a>
            <a className="btn btn-ghost" href="tel:9042999507"><Phone size={16} /> 9042999507</a>
          </motion.div>
          <div className="hero-mini-stats">
            {[
              ['25+', 'Years of coaching'],
              [String(bootstrap?.highlights?.students || '500+'), 'Athletes trained'],
              ['8', 'Sports + fitness'],
              ['Web + App', 'Live parent alerts'],
            ].map(([n, l]) => <div key={l}><b className="gradient-text">{n}</b><small>{l}</small></div>)}
          </div>
        </div>

        <motion.div className="hero-visual" style={{ y }}>
          <div className="orbit-wrap">
            <div className="orbit"><span className="dot" /></div>
            <div className="orbit"><span className="dot" /></div>
            <div className="orbit"><span className="dot" /></div>
            <motion.div
              className="hero-core"
              animate={{ rotate: [0, 2, -2, 0], scale: [1, 1.035, 1] }}
              transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
            >
              <div className="orb-glass">
                <div>
                  <div className="core-mark">GSA</div>
                  <small>Global Sports Academy</small>
                </div>
              </div>
            </motion.div>
          </div>
          {[
            ['🤺 Fencing', 'Flagship programme'],
            ['🥇 State & National', 'Medal pathway'],
            ['🎓 Sports Quota', 'College admission'],
            ['🏛️ Government Jobs', 'Reserved seats'],
          ].map(([t, s], i) => (
            <motion.div className="float-chip" key={t} initial={{ opacity: 0, scale: .8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: .8 + i * .15 }}>
              <span>{t}</span><span className="faint tiny" style={{ display: 'block' }}>{s}</span>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
      <div className="scroll-cue">SCROLL</div>
    </section>
  )
}

function Marquee({ sports }) {
  const items = [...sports, ...sports]
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee-track">
        {items.map((s, i) => <span key={i}>{s.icon} {s.name} <i>✦</i></span>)}
      </div>
    </div>
  )
}

export default function Home() {
  const { bootstrap, toast } = useApp()
  const sports = bootstrap?.sports?.length ? bootstrap.sports : DEFAULT_SPORTS
  const [faq, setFaq] = useState(0)
  const [gallery, setGallery] = useState('All')
  const [enquiry, setEnquiry] = useState({ name: '', phone: '', sport: 'Fencing', age: '' })

  useEffect(() => {
    const hash = window.location.hash.slice(1)
    if (hash) setTimeout(() => document.getElementById(hash)?.scrollIntoView({ behavior: 'smooth' }), 180)
  }, [])

  const submitEnquiry = (e) => {
    e.preventDefault()
    if (!enquiry.name.trim() || !enquiry.phone.trim()) {
      toast('Please add your name and phone number.', 'warn')
      return
    }
    const message = `Trial class enquiry — Global Sports Academy\nName: ${enquiry.name}\nPhone: ${enquiry.phone}\nSport: ${enquiry.sport}\nChild age: ${enquiry.age || 'Not specified'}`
    window.open(`https://wa.me/919042999507?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }

  return (
    <>
      <PublicNav />
      <Hero />
      <Marquee sports={sports} />

      <section className="section" id="about">
        <div className="container">
          <div className="grid g-21" style={{ alignItems: 'center' }}>
            <Reveal>
              <span className="eyebrow">Why we exist</span>
              <h2 className="h2">A academy that is <span className="gradient-text">not here just to earn.</span></h2>
              <p className="lead">
                We measure success in the years after the medal. GSA was built by a coach with <b>25 years in sports and coaching</b> who saw too many talented athletes stop at school. So we created a complete route: disciplined training, real competition records, sports-quota college guidance and continued support for athletes who reach state, national and international levels.
              </p>
              <p className="lead" style={{ fontSize: '1rem', marginTop: '1rem' }}>
                Our students have earned medals in classes 10 to 12 at district, state and national levels — and those achievements become the documents that open doors at Anna University and top private colleges, and later to government jobs with sports-reserved seats.
              </p>
              <div style={{ display: 'flex', gap: '.6rem', flexWrap: 'wrap', marginTop: '1.6rem' }}>
                <Badge tone="good"><BadgeCheck size={13} /> 25 years of coaching</Badge>
                <Badge tone="warn"><Medal size={13} /> Medal-to-career path</Badge>
                <Badge tone="neutral"><GraduationCap size={13} /> Anna University & top colleges</Badge>
              </div>
            </Reveal>
            <Reveal delay={.15}>
              <div className="glass quote-card">
                <p style={{ position: 'relative', fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', lineHeight: 1.65, fontWeight: 500, margin: 0 }}>
                  “A medal is proof of hard work. But the real victory is when that medal becomes a seat in college, a career, and a life an athlete never thought possible.”
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '.9rem', marginTop: '1.8rem' }}>
                  <div className="avatar" style={{ width: 48, height: 48, fontSize: '1rem' }}>GS</div>
                  <div><strong>Founder & Head Coach</strong><div className="faint tiny">25 years in sports & coaching · Global Sports Academy</div></div>
                </div>
              </div>
            </Reveal>
          </div>

          <div className="stat-grid" style={{ marginTop: '3.5rem' }}>
            {[
              { n: 25, s: '+', l: 'Years of experience', icon: Trophy },
              { n: 8, s: '', l: 'Sports disciplines', icon: Crosshair },
              { n: 500, s: '+', l: 'Athletes trained', icon: UsersIcon },
              { n: 24, s: '/7', l: 'CCTV surveillance', icon: Camera },
            ].map((s, i) => (
              <Reveal key={s.l} delay={i * .08}>
                <div className="glass stat-card glass-hover">
                  <s.icon size={19} color="var(--gold)" />
                  <b><Counter to={s.n} suffix={s.s} /></b>
                  <span className="muted tiny">{s.l}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="sports">
        <div className="container">
          <SectionHeading center eyebrow="Eight disciplines · One standard" title={<>Find your sport. <span className="gradient-text">Master your craft.</span></>} description="Every programme has structured types, qualified coaching and its own equipment stock. Fencing remains our flagship, with the rest of the academy built around the same culture of excellence." />
          <div className="sport-grid">
            {sports.map((s, i) => (
              <Reveal key={s.name || i} delay={(i % 4) * .07}>
                <TiltCard className="glass sport-card glass-hover featured" >
                  <div className="glow-dot" style={{ '--sport-color': s.color }} />
                  <div className="sport-emoji">{s.icon}</div>
                  {s.featured && <span className="badge warn" style={{ position: 'absolute', top: 14, right: 14 }}>Flagship</span>}
                  <h3>{s.name}</h3>
                  <p>{s.description}</p>
                  <div className="types">
                    {(Array.isArray(s.types) ? s.types : JSON.parse(s.types || '[]')).map((t) => <span className="chip" key={t}>{t}</span>)}
                  </div>
                </TiltCard>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="programmes">
        <div className="container">
          <SectionHeading center eyebrow="Programmes" title={<>A path for <span className="gradient-text">every age.</span></>} description="Students train with players their own age and move up as they grow. Each stage has its own drills, goals and competitive exposure." />
          <div className="program-grid">
            {[
              ['01', 'Sub Junior', 'Fun drills, strong basics and a lifelong love for the game.'],
              ['02', 'Cadet', 'Technique, discipline and the first competitive matches.'],
              ['03', 'Junior', 'Serious training, rated play and district-level events.'],
              ['04', 'Senior', 'Advanced coaching for zonal, state and national circuits.'],
            ].map(([n, t, d], i) => (
              <Reveal key={t} delay={i * .08}>
                <div className="glass program-card glass-hover">
                  <span className="program-num">{n}</span>
                  <h3 className="h3" style={{ margin: '.5rem 0' }}>{t}</h3>
                  <p className="muted" style={{ margin: 0, fontSize: '.86rem', lineHeight: 1.65 }}>{d}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={.2}>
            <div className="glass card" style={{ marginTop: '1.2rem' }}>
              <h3 className="h3" style={{ marginBottom: '1rem' }}>The competition pathway</h3>
              <div className="pathway-steps">
                {['Beginner', 'District', 'Zonal', 'State', 'National'].map((stage, i) => (
                  <span className="pathway-step" key={stage}><b>{i + 1}</b> {stage}</span>
                ))}
              </div>
              <p className="muted" style={{ margin: '1rem 0 0', fontSize: '.88rem', lineHeight: 1.7 }}>Every match and medal is recorded with its level and age category in the student’s athlete passport.</p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section" id="pathway">
        <div className="container">
          <SectionHeading eyebrow="The GSA pathway" title={<>Medals today. <span className="gradient-text">Doors tomorrow.</span></>} description="We stay with the athlete beyond the scoreboard — from school competitions to sports-quota admissions and reserved government opportunities." />
          <div className="grid g-2" style={{ alignItems: 'start' }}>
            <Reveal>
              <div className="timeline">
                {PATH.map((p) => (
                  <div className="timeline-item" key={p.n}>
                    <span className="eyebrow">Step {p.n}</span>
                    <h3>{p.title}</h3>
                    <p>{p.text}</p>
                  </div>
                ))}
              </div>
            </Reveal>
            <Reveal delay={.15}>
              <div className="glass card" style={{ padding: '1.8rem' }}>
                <h3 className="h3" style={{ marginBottom: '1.2rem' }}>What an athlete leaves with</h3>
                {[
                  [Medal, 'Verified medal & match records', 'District, state, national and international categories with full match detail.'],
                  [GraduationCap, 'Sports-quota application support', 'Documented achievements for Anna University and top-ranked private colleges.'],
                  [Landmark, 'Government opportunity guidance', 'Awareness of sports-reserved seats and career pathways for continuing athletes.'],
                  [HeartPulse, 'Lifelong discipline & fitness', 'Yoga, strength and recovery built into every athlete’s training week.'],
                ].map(([I, t, d]) => (
                  <div key={t} style={{ display: 'flex', gap: '.9rem', marginBottom: '1.2rem' }}>
                    <div className="feature-icon" style={{ width: 40, height: 40, flex: 'none' }}><I size={18} /></div>
                    <div><strong style={{ fontSize: '.92rem' }}>{t}</strong><p className="muted" style={{ margin: '.25rem 0 0', fontSize: '.82rem', lineHeight: 1.6 }}>{d}</p></div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="section" id="facilities">
        <div className="container">
          <SectionHeading center eyebrow="Safety is part of training" title={<>Professional setup. <span className="gradient-text">Peace of mind.</span></>} description="Parents always know where their child is, how they are training, and that the equipment around them is proper and maintained." />
          <div className="feature-grid">
            {FACILITIES.map((f, i) => (
              <Reveal key={f.title} delay={i * .08}>
                <TiltCard className="glass feature-card glass-hover">
                  <div className="feature-icon"><f.icon size={22} /></div>
                  <h3 className="h3" style={{ margin: '1.1rem 0 .5rem' }}>{f.title}</h3>
                  <p className="muted" style={{ margin: 0, lineHeight: 1.7, fontSize: '.9rem' }}>{f.text}</p>
                </TiltCard>
              </Reveal>
            ))}
          </div>
          <Reveal delay={.2}>
            <div className="glass card" style={{ marginTop: '1.2rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <h3 className="h3">Live biometric notifications</h3>
                <p className="muted" style={{ margin: '.4rem 0 0', fontSize: '.88rem' }}>Entry and exit alerts with date, time and basic details reach parents through the website and app. Late or low attendance alerts are automatic.</p>
              </div>
              <Link className="btn btn-outline" to="/login?role=student">See student portal <ArrowRight size={15} /></Link>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section" id="app">
        <div className="container">
          <SectionHeading center eyebrow="The academy app" title={<>An app that knows <span className="gradient-text">every athlete.</span></>} description="Parents, students and coaches use one simple platform on the website and on Android. Sign up, get approved by the academy, and follow everything in one place." />
          <div className="app-feature-grid">
            {[
              [Camera, 'Know the moment they arrive', 'Parents get an alert when a child checks in, and a flag when they are late or absent.'],
              [BadgeCheck, 'Athlete passport', 'Sports, levels, matches, medals, academics and coach remarks in one record.'],
              [Landmark, 'Clear fees', 'Fee plans per sport, bills with due dates and quick confirmation — no paper chasing.'],
              [ShieldCheck, 'Private by design', 'Owner, coach and student each see only what they should, medical details included.'],
              [Medal, 'Achievements by level', 'District, zonal and state results tracked by age category, ready to show.'],
              [ScanFace, 'Attendance records', 'Daily attendance with history and PDF / Excel exports for the academy.'],
            ].map(([I, t, d], i) => (
              <Reveal key={t} delay={(i % 3) * .08}>
                <div className="glass app-feature glass-hover">
                  <div className="feature-icon"><I size={20} /></div>
                  <h3 className="h3" style={{ margin: '1rem 0 .5rem' }}>{t}</h3>
                  <p className="muted" style={{ margin: 0, fontSize: '.86rem', lineHeight: 1.65 }}>{d}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <div className="hero-actions" style={{ justifyContent: 'center' }}>
            <a className="btn btn-primary" href="#contact">Join the academy <ArrowRight size={16} /></a>
            <a className="btn btn-ghost" href="/GSA-Academy.apk" download>Download Android app</a>
          </div>
          <p className="faint tiny center" style={{ marginTop: '.9rem' }}>Works on Android 6 and above. Allow “Install from this source” if Android asks.</p>
        </div>
      </section>

      <section className="section" id="gallery">
        <div className="container">
          <SectionHeading center eyebrow="Gallery" title={<>Life at <span className="gradient-text">the academy.</span></>} description="A closer look at training, tournaments and the people behind every medal." />
          <div className="gallery-tabs" role="tablist" aria-label="Gallery filters">
            {['All', ...sports.map((s) => s.name), 'Physical Fitness'].map((name) => (
              <button key={name} type="button" role="tab" aria-selected={gallery === name} className={`gallery-tab ${gallery === name ? 'active' : ''}`} onClick={() => setGallery(name)}>{name}</button>
            ))}
          </div>
          <div className="gallery-grid">
            {(gallery === 'All' ? sports.slice(0, 5) : sports.filter((s) => s.name === gallery)).map((s) => (
              <div className="glass gallery-card" key={s.name}>
                <div className="gallery-emoji">{s.icon}</div>
                <strong>{s.name}</strong>
                <span className="faint tiny">Photos coming soon</span>
              </div>
            ))}
            {gallery === 'Physical Fitness' && (
              <div className="glass gallery-card">
                <div className="gallery-emoji">💪</div>
                <strong>Physical Fitness</strong>
                <span className="faint tiny">Photos coming soon</span>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="section" id="faq">
        <div className="container">
          <div className="grid g-2" style={{ alignItems: 'start' }}>
            <SectionHeading eyebrow="Good questions" title={<>Everything you <span className="gradient-text">want to know.</span></>} />
            <Reveal delay={.1}>
              <div className="glass card">
                {FAQS.map((f, i) => (
                  <div className="faq-item" key={f.q}>
                    <button className="faq-q" onClick={() => setFaq(faq === i ? -1 : i)}>{f.q}<span style={{ color: 'var(--gold)' }}>{faq === i ? '−' : '+'}</span></button>
                    {faq === i && <motion.div className="faq-a" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>{f.a}</motion.div>}
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="section" id="contact">
        <div className="container">
          <SectionHeading center eyebrow="Come train with us" title={<>Start your journey <span className="gradient-text">with us.</span></>} description="Visit the academy, call us, or send an enquiry. We reply quickly." />
          <div className="contact-grid">
            <div className="grid" style={{ gap: '.8rem', alignContent: 'start' }}>
              {[
                [Phone, 'Call us', '9042999507', 'tel:9042999507'],
                [MessageCircle, 'WhatsApp', '9042999507', 'https://wa.me/919042999507'],
                [Mail, 'Email', 'globalsportsnkl@gmail.com', 'mailto:globalsportsnkl@gmail.com'],
              ].map(([I, l, v, href]) => (
                <a key={l} className="contact-row" href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer">
                  <span className="ic"><I size={19} /></span>
                  <span><small className="faint" style={{ display: 'block' }}>{l}</small><strong>{v}</strong></span>
                  <ArrowRight size={16} style={{ marginLeft: 'auto', color: 'var(--gold)' }} />
                </a>
              ))}
              <div className="contact-row">
                <span className="ic"><MapPin size={19} /></span>
                <span><small className="faint" style={{ display: 'block' }}>Find us</small><strong>Global Sports Academy</strong><small className="faint" style={{ display: 'block', marginTop: '.2rem' }}>Nochipattiyar Thottam, Mudhalaipatti, Namakkal</small></span>
              </div>
              <a className="btn btn-primary" href={bootstrap?.contact?.mapUrl || MAP_URL} target="_blank" rel="noreferrer">Open in Google Maps <ArrowRight size={16} /></a>
            </div>
            <form className="glass enquiry-form" onSubmit={submitEnquiry}>
              <h3 className="h3 full">Send an enquiry</h3>
              <p className="muted full" style={{ margin: '-.4rem 0 .4rem', fontSize: '.85rem' }}>Tell us a little and we will get back to you.</p>
              <label className="field">
                <span>Your name</span>
                <input className="input" value={enquiry.name} onChange={(e) => setEnquiry({ ...enquiry, name: e.target.value })} placeholder="Parent or student name" required />
              </label>
              <label className="field">
                <span>Phone number</span>
                <input className="input" type="tel" value={enquiry.phone} onChange={(e) => setEnquiry({ ...enquiry, phone: e.target.value })} placeholder="9042999507" required />
              </label>
              <label className="field">
                <span>Sport</span>
                <select className="input" value={enquiry.sport} onChange={(e) => setEnquiry({ ...enquiry, sport: e.target.value })}>
                  {[...sports.map((s) => s.name), 'Physical Fitness'].map((name) => <option key={name}>{name}</option>)}
                </select>
              </label>
              <label className="field">
                <span>Child age</span>
                <input className="input" value={enquiry.age} onChange={(e) => setEnquiry({ ...enquiry, age: e.target.value })} placeholder="e.g. 12" />
              </label>
              <button className="btn btn-primary full" type="submit">Request a trial class <ArrowRight size={16} /></button>
            </form>
          </div>
          <div className="glass" style={{ padding: '.5rem', marginTop: '1.2rem' }}>
            <iframe
              className="map-frame"
              title="Global Sports Academy on Google Maps"
              src={MAP_EMBED_URL}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
      <PublicFooter />
    </>
  )
}

function UsersIcon(props) { return <svg {...props} viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></svg> }
