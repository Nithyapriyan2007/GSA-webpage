import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowLeft, ArrowRight, BadgeCheck, Eye, EyeOff, KeyRound, LockKeyhole, Mail, Server, ShieldCheck, Sparkles, UserRound } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { api } from '../../lib/api'
import { getApiBase, setApiBase } from '../../lib/apiBase'
import { Brand, ThemeToggle } from '../../components/SiteChrome'

const ROLES = [
  { id: 'owner', label: 'Owner', icon: ShieldCheck, hint: 'Owner username: owner' },
  { id: 'staff', label: 'Staff', icon: UserRound, hint: 'Sign in with your academy email' },
  { id: 'student', label: 'Student', icon: Sparkles, hint: 'Sign in with your academy email' },
]

function strength(pw) {
  const checks = [
    pw.length >= 8,
    /[A-Z]/.test(pw),
    /[a-z]/.test(pw),
    /\d/.test(pw),
    /[^A-Za-z0-9]/.test(pw),
  ]
  return { checks, score: checks.filter(Boolean).length, valid: checks.every(Boolean) }
}

export default function Login() {
  const { login, toast, user } = useApp()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [role, setRole] = useState(['owner', 'staff', 'student'].includes(params.get('role')) ? params.get('role') : 'student')
  const [stage, setStage] = useState('login')
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [code, setCode] = useState('')
  const [issuedCode, setIssuedCode] = useState('')
  const [newPw, setNewPw] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [serverOpen, setServerOpen] = useState(false)
  const [serverInput, setServerInput] = useState(() => getApiBase())

  useEffect(() => { if (user) navigate('/app', { replace: true }) }, [user, navigate])
  useEffect(() => { setError(''); setStage('login') }, [role])

  const pw = useMemo(() => strength(newPw), [newPw])

  const saveServer = (e) => {
    e.preventDefault()
    setApiBase(serverInput)
    window.location.replace('/')
  }

  const submitLogin = async (e) => {
    e.preventDefault()
    setError(''); setBusy(true)
    try {
      await login(role, identifier.trim(), password)
      toast(`Welcome to your ${role} workspace.`)
      navigate('/app', { replace: true })
    } catch (err) {
      setError(err.message)
    } finally { setBusy(false) }
  }

  const requestReset = async (e) => {
    e.preventDefault()
    setError(''); setBusy(true)
    try {
      const res = await api('/auth/forgot/request', { method: 'POST', body: { email: identifier.trim(), role } })
      setIssuedCode(res.code || '')
      setStage('reset')
      toast('Demo reset code generated.', 'warn')
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  const resetPassword = async (e) => {
    e.preventDefault()
    setError('')
    if (!pw.valid) { setError('Password must satisfy every rule listed below.'); return }
    setBusy(true)
    try {
      await api('/auth/forgot/reset', { method: 'POST', body: { email: identifier.trim(), code: code.trim(), password: newPw } })
      toast('Password updated. Please sign in.', 'good')
      setStage('login'); setPassword(''); setNewPw(''); setCode('')
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="auth-page">
      <section className="auth-art">
        <div style={{ position: 'relative', zIndex: 1 }}>
          <Brand />
        </div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div className="big-gsa">GSA</div>
          <h2 className="h2" style={{ maxWidth: 460, marginTop: '-2rem' }}>Your portal to a <span className="gradient-text">champion’s journey.</span></h2>
          <p className="lead" style={{ fontSize: '1rem' }}>Owner, coach or athlete — every role has a purpose-built workspace with live academy data, announcements and a multilingual assistant.</p>
          <div style={{ display: 'flex', gap: '.6rem', flexWrap: 'wrap', marginTop: '1.5rem' }}>
            <span className="chip"><BadgeCheck size={13} /> Role-based access</span>
            <span className="chip"><LockKeyhole size={13} /> Secure sessions</span>
            <span className="chip"><Sparkles size={13} /> AI assistant</span>
          </div>
        </div>
        <div className="faint tiny" style={{ position: 'relative', zIndex: 1 }}>© {new Date().getFullYear()} Global Sports Academy · Forge champions. For life.</div>
      </section>

      <section className="auth-panel">
        <div className="auth-card glass glass-strong">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <span className="eyebrow">{stage === 'login' ? 'Secure portal' : 'Account recovery'}</span>
              <h1 className="h3" style={{ fontSize: '1.6rem', marginTop: '.6rem' }}>
                {stage === 'login' ? 'Welcome back' : stage === 'request' ? 'Forgot password?' : 'Set a new password'}
              </h1>
              <p className="muted" style={{ fontSize: '.85rem', margin: '.35rem 0 0' }}>
                {stage === 'login' ? 'Choose your role and sign in to continue.' : stage === 'request' ? 'Enter your registered academy email to get a reset code.' : 'Use the code and create a strong password.'}
              </p>
            </div>
            <ThemeToggle />
          </div>

          <div className="role-tabs">
            {ROLES.map((r) => (
              <button key={r.id} className={`role-tab ${role === r.id ? 'active' : ''}`} onClick={() => setRole(r.id)} disabled={stage !== 'login'}>
                <r.icon size={15} style={{ verticalAlign: 'middle', marginRight: 5 }} />{r.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.form
              key={stage}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              onSubmit={stage === 'login' ? submitLogin : stage === 'request' ? requestReset : resetPassword}
            >
              <div className="field">
                <label>{role === 'owner' ? 'Owner username' : 'Email address'}</label>
                <div className="input-wrap">
                  {role === 'owner' ? <UserRound size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} /> : <Mail size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} />}
                  <input className="input" style={{ paddingLeft: '2.3rem' }} autoComplete="username" value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder={role === 'owner' ? 'owner' : 'you@academy.com'} required />
                </div>
                <div className="faint tiny" style={{ marginTop: '.4rem' }}>{ROLES.find((r) => r.id === role).hint}</div>
              </div>

              {stage === 'login' && (
                <div className="field">
                  <label>Password</label>
                  <div className="input-wrap">
                    <LockKeyhole size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} />
                    <input className="input" style={{ paddingLeft: '2.3rem' }} type={show ? 'text' : 'password'} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required />
                    <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? 'Hide password' : 'Show password'}>{show ? <EyeOff size={17} /> : <Eye size={17} />}</button>
                  </div>
                </div>
              )}

              {stage === 'reset' && (
                <>
                  <div className="field">
                    <label>Reset code</label>
                    <div className="input-wrap">
                      <KeyRound size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} />
                      <input className="input" style={{ paddingLeft: '2.3rem' }} value={code} onChange={(e) => setCode(e.target.value)} placeholder="6-digit code" required />
                    </div>
                    {issuedCode && <div className="demo-creds">Demo code: <b>{issuedCode}</b> <span className="faint">(no email service is configured in this build)</span></div>}
                  </div>
                  <div className="field">
                    <label>New password</label>
                    <div className="input-wrap">
                      <LockKeyhole size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--faint)' }} />
                      <input className="input" style={{ paddingLeft: '2.3rem' }} type={show ? 'text' : 'password'} value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="Create a strong password" required />
                      <button type="button" onClick={() => setShow((v) => !v)}>{show ? <EyeOff size={17} /> : <Eye size={17} />}</button>
                    </div>
                    <div className="meter">{pw.checks.map((ok, i) => <i key={i} className={ok ? (pw.score === 5 ? 'strong' : 'on') : ''} />)}</div>
                    <div className="policy-list">
                      {[['8+ characters', 0], ['Uppercase', 1], ['Lowercase', 2], ['Number', 3], ['Special character', 4]].map(([l, i]) => (
                        <span key={l} className={pw.checks[i] ? 'ok' : ''}>{pw.checks[i] ? '✓' : '○'} {l}</span>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {error && <div className="badge bad" style={{ display: 'block', marginBottom: '.8rem', whiteSpace: 'normal' }}>{error}</div>}

              <button className="btn btn-primary" style={{ width: '100%' }} disabled={busy}>
                {busy ? 'Please wait…' : stage === 'login' ? 'Sign in securely' : stage === 'request' ? 'Get reset code' : 'Update password'}
                {!busy && <ArrowRight size={16} />}
              </button>

              {stage === 'login' && (
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
                  <span className="auth-hint" style={{ margin: 0 }}>Staff & students: your email is your username.</span>
                  <button type="button" className="link" style={{ border: 0, background: 'none', fontSize: '.8rem' }} onClick={() => { if (!identifier.trim()) { setError('Enter your email first, then click Forgot password.'); return } setStage('request') }}>Forgot password?</button>
                </div>
              )}
              {stage !== 'login' && (
                <button type="button" className="btn btn-ghost btn-sm" style={{ width: '100%', marginTop: '.8rem' }} onClick={() => { setStage('login'); setError('') }}><ArrowLeft size={14} /> Back to sign in</button>
              )}
            </motion.form>
          </AnimatePresence>

          {stage === 'login' && role === 'owner' && (
            <div className="demo-creds">
              <b>Owner credentials (demo):</b> username <b>owner</b> · password <b>9042999507</b><br />
              Only this exact username can access the owner console.
            </div>
          )}
          {stage === 'login' && role !== 'owner' && (
            <div className="demo-creds">
              <b>Sample accounts:</b> ravi.kumar@gsa.ac.in (staff) · player1@gsa.ac.in (student)<br />
              Default passwords: <b>Coach@123</b> (staff) · <b>Player@123</b> (student)
            </div>
          )}
          <div className="server-box">
            <button type="button" className="server-toggle" onClick={() => setServerOpen((v) => !v)}>
              <Server size={14} /> Server: <b>{getApiBase() || 'same device'}</b> <span>{serverOpen ? '– close' : '– change'}</span>
            </button>
            {serverOpen && (
              <form onSubmit={saveServer} className="server-form">
                <input
                  className="input"
                  value={serverInput}
                  onChange={(e) => setServerInput(e.target.value)}
                  placeholder="http://192.168.1.10:4000"
                  aria-label="Backend server address"
                />
                <button className="btn btn-primary btn-sm" type="submit">Save & reload</button>
                <small>Use the Wi-Fi IP of the computer running <b>npm run dev</b>. Leave blank to use the same device.</small>
              </form>
            )}
          </div>

          <p className="auth-hint" style={{ textAlign: 'center' }}>By continuing you agree to use the portals only for academy purposes. <Link to="/" className="link">Back to website</Link></p>
        </div>
      </section>
    </div>
  )
}
