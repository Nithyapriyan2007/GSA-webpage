import { useState } from 'react'
import { Award, CalendarDays, FileText, Medal, Trophy } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { api, fmtDate, fmtMoney, statusTone } from '../../lib/api'
import { Badge, EmptyState, Modal, RingProgress } from '../../components/ui'
import DataTable from '../../components/DataTable'
import { PageHead, useFetch } from './CommonPages'

/* ---------------- Staff: students (view only, RBAC scoped) ---------------- */
export function StaffStudents() {
  const { toast } = useApp()
  const { data, loading } = useFetch('/students')
  const [view, setView] = useState(null)
  return (
    <>
      <PageHead eyebrow="Assigned athletes" title="Student records" subtitle="View-only access to athletes in your sports, filtered by the permissions granted by the owner." action={<span className="badge warn"><Award size={13} /> View only</span>} />
      <div className="glass card">
        {loading && <div className="skeleton" />}
        {!loading && <DataTable data={data} searchKeys={['name', 'email', 'sport_name', 'sport']} columns={[
          { key: 'name', label: 'Athlete', render: (r) => <b>{r.name}</b> },
          { key: 'sport_name', label: 'Sport', render: (r) => <Badge tone="warn">{r.sport_name || r.sport}</Badge> },
          { key: 'age', label: 'Age' },
          { key: 'ongoing_years', label: 'Years' },
          { key: 'school_name', label: 'School' },
          { key: 'medal_count', label: 'Medals' },
          { key: 'id', label: 'Record', sortable: false, render: (r) => <button className="btn-icon" onClick={() => setView(r)}><FileText size={14} /></button> },
        ]} />}
      </div>
      <Modal open={!!view} onClose={() => setView(null)} title={view?.name || 'Athlete'} subtitle="Read-only student record" wide>
        {view && <div className="passport-grid">
          {[['Email', view.email], ['Phone', view.phone], ['Age', view.age], ['Sport', view.sport_name || view.sport], ['Joined', fmtDate(view.joined_date)], ['Years', view.ongoing_years], ['School', view.school_name], ['College', view.college_name], ['Academic year', view.academic_year], ['Fee pending', fmtMoney(view.fees_pending)], ['Allergies', view.allergy], ['Remarks', view.remarks]].map(([l, v]) => <div key={l}><small>{l}</small><b>{v || '—'}</b></div>)}
        </div>}
      </Modal>
    </>
  )
}

/* ---------------- Student: sports ---------------- */
export function StudentSports() {
  const { bootstrap } = useApp()
  const sports = bootstrap?.sports || []
  return (
    <>
      <PageHead eyebrow="Programmes" title="Sports & disciplines" subtitle="Explore every GSA discipline and the types you can train in." />
      <div className="sport-grid">
        {sports.map((s) => (
          <div className="glass sport-card glass-hover" key={s.id}>
            <div className="glow-dot" style={{ '--sport-color': s.color }} />
            <div className="sport-emoji">{s.icon}</div>
            <h3>{s.name}</h3>
            <p>{s.description}</p>
            <div className="types">{(Array.isArray(s.types) ? s.types : JSON.parse(s.types || '[]')).map((t) => <span className="chip" key={t}>{t}</span>)}</div>
          </div>
        ))}
      </div>
    </>
  )
}

/* ---------------- Student: full profile / passport ---------------- */
export function StudentProfile() {
  const { dashboard: d } = useApp()
  const p = d?.profile || {}
  return (
    <>
      <PageHead eyebrow="Identity" title="Athlete passport" subtitle="Your official GSA record — identity, family, academics, sport and medical details." />
      <div className="glass passport">
        <div className="passport-head">
          <div className="passport-photo"><Trophy size={34} color="var(--gold)" /></div>
          <div style={{ flex: 1 }}>
            <span className="eyebrow">Global Sports Academy</span>
            <h2 className="h3" style={{ fontSize: '1.8rem', marginTop: '.4rem' }}>{p.name}</h2>
            <p className="muted">Passport {d?.passport?.id} · {p.sportName || p.sport_name || p.sport} · Coach {p.staffName || p.staff_name || '—'}</p>
            <div style={{ display: 'flex', gap: '.4rem', flexWrap: 'wrap', marginTop: '.6rem' }}><Badge tone="good">Active</Badge><Badge tone="warn">{p.ongoing_years} years</Badge><Badge>{p.category2 || 'Junior'}</Badge></div>
          </div>
          <RingProgress value={Math.min(100, (d?.achievements?.length || 0) * 10)} size={96} label="progress" />
        </div>
        <div className="passport-grid">
          {[
            ['Age', p.age], ['Body', p.body], ['Place of birth', p.place_of_birth], ['Identification mark', p.identification_mark],
            ['Phone', p.phone], ['Email', p.email], ['Address', p.address], ['Joined date', fmtDate(p.joined_date)],
            ['School', p.school_name], ['School details', p.school_details], ['College', p.college_name], ['College details', p.college_details],
            ['Academic year', p.academic_year], ['Father', p.father_name], ['Father phone', p.father_phone], ['Father occupation', p.father_occupation],
            ['Mother', p.mother_name], ['Mother phone', p.mother_phone], ['Mother occupation', p.mother_occupation],
            ['Medicine', p.regular_medicine], ['Allergies', p.allergy], ['Surgery', p.surgery], ['Health issues', p.health_issues],
            ['Equipment purchased', p.equipment_purchased], ['Damage', p.damage], ['Fees pending', fmtMoney(p.fees_pending)], ['Remarks', p.remarks],
          ].map(([l, v]) => <div key={l}><small>{l}</small><b>{v || '—'}</b></div>)}
        </div>
      </div>
    </>
  )
}

/* ---------------- Staff profile ---------------- */
export function StaffProfile() {
  const { user } = useApp()
  const u = user || {}
  return (
    <>
      <PageHead eyebrow="Staff identity" title="Coach profile" subtitle="Your professional record with the academy." />
      <div className="glass passport">
        <div className="passport-head">
          <div className="passport-photo">🎽</div>
          <div style={{ flex: 1 }}>
            <span className="eyebrow">Coaching staff</span>
            <h2 className="h3" style={{ fontSize: '1.8rem', marginTop: '.4rem' }}>{u.name}</h2>
            <p className="muted">{u.email} · {u.sports}</p>
            <div style={{ display: 'flex', gap: '.4rem', marginTop: '.6rem' }}><Badge tone="warn">{u.role}</Badge><Badge tone="good">Active</Badge></div>
          </div>
        </div>
        <div className="passport-grid">
          {[['Age', u.age], ['Body', u.body], ['Place', u.place], ['Experience', `${u.experience ?? '—'} years`], ['Category', u.category], ['Achievement', u.achievement], ['Sports', u.sports], ['Previously worked', u.previously_worked]].map(([l, v]) => <div key={l}><small>{l}</small><b>{v || '—'}</b></div>)}
        </div>
      </div>
    </>
  )
}
