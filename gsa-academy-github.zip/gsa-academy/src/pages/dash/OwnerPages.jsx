import { useState } from 'react'
import {
  Download, FileSpreadsheet, FileText, KeyRound, Pencil, Plus, ShieldCheck, Trash2,
} from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { api, downloadReport, fmtDate, fmtMoney, statusTone } from '../../lib/api'
import { Badge, EmptyState, Modal } from '../../components/ui'
import DataTable from '../../components/DataTable'
import { PageHead, PhotoLink, useFetch } from './CommonPages'

const EMPTY_STUDENT = {
  name: '', email: '', password: 'Player@123', phone: '', age: '', body: '', place_of_birth: '',
  identification_mark: '', address: '', father_name: '', father_phone: '', father_email: '',
  father_address: '', father_occupation: '', mother_name: '', mother_phone: '', mother_email: '',
  mother_address: '', mother_occupation: '', joined_date: new Date().toISOString().slice(0, 10),
  ongoing_years: '1', sport: 'Fencing', staff_id: '', school_name: '', school_details: '',
  college_name: '', college_details: '', academic_year: '', remarks: '', regular_medicine: '',
  allergy: '', surgery: '', health_issues: '', damage: '', equipment_purchased: '',
  fees_pending: '0', prize_photo: '', status: 'active',
}

const STUDENT_FIELDS = [
  ['Full name', 'name'], ['Email (username)', 'email'], ['Initial password', 'password'], ['Phone', 'phone'],
  ['Age', 'age'], ['Body / build', 'body'], ['Place of birth', 'place_of_birth'], ['Identification mark', 'identification_mark'],
  ['Address', 'address', 'full'], ['Father name', 'father_name'], ['Father phone', 'father_phone'],
  ['Father email', 'father_email'], ['Father address', 'father_address'], ['Father occupation', 'father_occupation'],
  ['Mother name', 'mother_name'], ['Mother phone', 'mother_phone'], ['Mother email', 'mother_email'],
  ['Mother address', 'mother_address'], ['Mother occupation', 'mother_occupation'],
  ['Joined date', 'joined_date'], ['Ongoing years', 'ongoing_years'], ['Sport', 'sport'], ['Coach (staff id)', 'staff_id'],
  ['School name', 'school_name'], ['School details', 'school_details'], ['College name', 'college_name'],
  ['College details', 'college_details'], ['Academic year', 'academic_year'], ['Remarks', 'remarks', 'full'],
  ['Regular medicine', 'regular_medicine'], ['Allergies', 'allergy'], ['Past surgery', 'surgery'],
  ['Health issues', 'health_issues'], ['Damage by student', 'damage'], ['Equipment purchased', 'equipment_purchased'],
  ['Fees pending', 'fees_pending'], ['Prize photo link', 'prize_photo', 'full'], ['Status', 'status'],
]

function FormFields({ fields, form, setForm }) {
  return (
    <div className="form-grid">
      {fields.map(([label, key, span]) => (
        <div className={`field ${span === 'full' ? 'full' : ''}`} key={key}>
          <label>{label}</label>
          {['remarks', 'address', 'mother_address', 'father_address', 'health_issues', 'school_details', 'college_details', 'equipment_purchased'].includes(key)
            ? <textarea className="input" value={form[key] ?? ''} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />
            : <input className="input" type={key === 'joined_date' ? 'date' : key === 'age' || key === 'ongoing_years' || key === 'fees_pending' ? 'number' : key === 'password' ? 'password' : 'text'} value={form[key] ?? ''} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />}
        </div>
      ))}
    </div>
  )
}

/* ---------------- Students ---------------- */
export function OwnerStudents() {
  const { toast, refresh } = useApp()
  const { data, reload } = useFetch('/students')
  const { data: staff } = useFetch('/staff')
  const [view, setView] = useState(null)
  const [edit, setEdit] = useState(null)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState(EMPTY_STUDENT)
  const [busy, setBusy] = useState(false)

  const save = async (e) => {
    e.preventDefault(); setBusy(true)
    try {
      if (form.id) await api(`/students/${form.id}`, { method: 'PUT', body: form })
      else await api('/students', { method: 'POST', body: form })
      toast(form.id ? 'Student record updated.' : 'Student admitted and login created.', 'good')
      setOpen(false); setForm(EMPTY_STUDENT); reload(); refresh()
    } catch (err) { toast(err.message, 'bad') } finally { setBusy(false) }
  }
  const remove = async (id) => {
    if (!window.confirm('Delete this student record permanently?')) return
    try { await api(`/students/${id}`, { method: 'DELETE' }); toast('Student removed.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Academy directory" title="Students & athletes" subtitle="Every athlete’s identity, family, academics, sport, medical record, fees and remarks." action={<button className="btn btn-primary" onClick={() => { setForm(EMPTY_STUDENT); setEdit(null); setOpen(true) }}><Plus size={16} /> Admit student</button>} />
      <div className="glass card">
        <DataTable
          data={data}
          searchKeys={['name', 'email', 'sport_name', 'sport', 'school_name', 'college_name']}
          toolbar={<select className="input" onChange={(e) => { /* client-side hint; reload from server not needed */ }}><option value="">All sports</option></select>}
          columns={[
            { key: 'name', label: 'Athlete', render: (r) => <b>{r.name}</b> },
            { key: 'sport_name', label: 'Sport', render: (r) => <Badge tone="warn">{r.sport_name || r.sport}</Badge> },
            { key: 'age', label: 'Age' },
            { key: 'ongoing_years', label: 'Years', render: (r) => `${r.ongoing_years ?? '—'} yr` },
            { key: 'staff_name', label: 'Coach' },
            { key: 'fees_pending', label: 'Fee due', render: (r) => <b style={{ color: Number(r.fees_pending) > 0 ? 'var(--rose)' : 'var(--green)' }}>{fmtMoney(r.fees_pending)}</b> },
            { key: 'id', label: 'Actions', sortable: false, render: (r) => (
              <div className="row-actions">
                <button className="btn-icon" title="View full record" onClick={() => setView(r)}><FileText size={14} /></button>
                <button className="btn-icon" title="Edit" onClick={() => { setForm(r); setEdit(r); setOpen(true) }}><Pencil size={14} /></button>
                <button className="btn-icon" title="Delete" onClick={() => remove(r.id)}><Trash2 size={14} /></button>
              </div>
            ) },
          ]}
        />
      </div>

      <Modal open={!!view} onClose={() => setView(null)} title={view?.name || 'Student record'} subtitle="Complete athlete profile" wide>
        {view && (
          <>
            <div className="passport-grid">
              {[
                ['Email', view.email], ['Phone', view.phone], ['Age', view.age], ['Body', view.body],
                ['Place of birth', view.place_of_birth], ['Identification mark', view.identification_mark],
                ['Joined', fmtDate(view.joined_date)], ['Years', view.ongoing_years], ['Sport', view.sport_name || view.sport], ['Coach', view.staff_name],
                ['School', view.school_name], ['College', view.college_name], ['Academic year', view.academic_year], ['Fee due', fmtMoney(view.fees_pending)],
              ].map(([l, v]) => <div key={l}><small>{l}</small><b>{v || '—'}</b></div>)}
            </div>
            <div className="divider" />
            <h3 className="h3" style={{ marginBottom: '.7rem' }}>Family & academics</h3>
            <p className="muted" style={{ fontSize: '.86rem', lineHeight: 1.8 }}>
              Address: {view.address || '—'}<br />
              Father: {view.father_name || '—'} · {view.father_phone || '—'} · {view.father_email || '—'} · {view.father_occupation || '—'} · {view.father_address || '—'}<br />
              Mother: {view.mother_name || '—'} · {view.mother_phone || '—'} · {view.mother_email || '—'} · {view.mother_occupation || '—'} · {view.mother_address || '—'}<br />
              School details: {view.school_details || '—'}<br />College details: {view.college_details || '—'}
            </p>
            <h3 className="h3" style={{ margin: '1.1rem 0 .7rem' }}>Medical & remarks</h3>
            <p className="muted" style={{ fontSize: '.86rem', lineHeight: 1.8 }}>
              Regular medicine: {view.regular_medicine || '—'}<br />Allergies: {view.allergy || '—'}<br />
              Surgery undergone: {view.surgery || '—'}<br />Health issues: {view.health_issues || '—'}<br />
              Damage by student: {view.damage || '—'}<br />Equipment purchased: {view.equipment_purchased || '—'}<br />Remarks: {view.remarks || '—'}
            </p>
            {view.prize_photo && <div style={{ marginTop: '1rem' }}><PhotoLink url={view.prize_photo} /></div>}
          </>
        )}
      </Modal>

      <Modal open={open} onClose={() => setOpen(false)} title={edit ? 'Edit student' : 'Admit a new athlete'} subtitle="Creates an academy login when an email is provided." wide>
        <form onSubmit={save}>
          <FormFields fields={STUDENT_FIELDS} form={form} setForm={setForm} />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}>
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button>
            <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : edit ? 'Save changes' : 'Admit student'}</button>
          </div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Staff ---------------- */
const EMPTY_STAFF = { name: '', email: '', password: 'Coach@123', phone: '', age: '', body: '', place: '', experience: '', category: '', achievement: '', sports: 'Fencing', previously_worked: '', status: 'active' }
const STAFF_FIELDS = [
  ['Full name', 'name'], ['Email (username)', 'email'], ['Initial password', 'password'], ['Phone', 'phone'],
  ['Age', 'age'], ['Body / build', 'body'], ['Place', 'place'], ['Experience (years)', 'experience'],
  ['Category', 'category'], ['Achievement', 'achievement'], ['Sports (comma separated)', 'sports'],
  ['Previously worked at', 'previously_worked', 'full'], ['Status', 'status'],
]

export function OwnerStaff() {
  const { toast, refresh } = useApp()
  const { data, reload } = useFetch('/staff')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState(EMPTY_STAFF)
  const [busy, setBusy] = useState(false)

  const save = async (e) => {
    e.preventDefault(); setBusy(true)
    try {
      if (form.id) await api(`/staff/${form.id}`, { method: 'PUT', body: form })
      else await api('/staff', { method: 'POST', body: form })
      toast('Staff record saved.', 'good'); setOpen(false); setForm(EMPTY_STAFF); reload(); refresh()
    } catch (err) { toast(err.message, 'bad') } finally { setBusy(false) }
  }
  const remove = async (id) => {
    if (!window.confirm('Remove this staff member?')) return
    try { await api(`/staff/${id}`, { method: 'DELETE' }); toast('Staff removed.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Coaching team" title="Staff & access" subtitle="Profiles, experience, achievements and the sports each coach handles." action={<button className="btn btn-primary" onClick={() => { setForm(EMPTY_STAFF); setOpen(true) }}><Plus size={16} /> Add staff</button>} />
      <div className="glass card">
        <DataTable data={data} searchKeys={['name', 'email', 'sports', 'category', 'place']} columns={[
          { key: 'name', label: 'Name', render: (r) => <b>{r.name}</b> },
          { key: 'sports', label: 'Sports', render: (r) => <Badge tone="warn">{Array.isArray(r.sports) ? r.sports.join(', ') : r.sports}</Badge> },
          { key: 'experience', label: 'Experience', render: (r) => `${r.experience ?? '—'} yrs` },
          { key: 'category', label: 'Category' },
          { key: 'place', label: 'Place' },
          { key: 'status', label: 'Status', render: (r) => <Badge tone={statusTone(r.status)}>{r.status}</Badge> },
          { key: 'id', label: 'Actions', sortable: false, render: (r) => <div className="row-actions"><button className="btn-icon" onClick={() => { setForm(r); setOpen(true) }}><Pencil size={14} /></button><button className="btn-icon" onClick={() => remove(r.id)}><Trash2 size={14} /></button></div> },
        ]} />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title={form.id ? 'Edit staff profile' : 'Add a coach / staff member'} wide>
        <form onSubmit={save}>
          <FormFields fields={STAFF_FIELDS} form={form} setForm={setForm} />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary" disabled={busy}>Save</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Sports ---------------- */
const EMPTY_SPORT = { name: '', icon: '🏅', color: '#f5b942', description: '', types: '' }
export function OwnerSports() {
  const { toast } = useApp()
  const { data, reload } = useFetch('/sports')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState(EMPTY_SPORT)
  const save = async (e) => {
    e.preventDefault()
    try {
      const body = { ...form, types: String(form.types).split(',').map((s) => s.trim()).filter(Boolean) }
      if (body.id) await api(`/sports/${body.id}`, { method: 'PUT', body })
      else await api('/sports', { method: 'POST', body })
      toast('Sport saved.', 'good'); setOpen(false); setForm(EMPTY_SPORT); reload()
    } catch (err) { toast(err.message, 'bad') }
  }
  const remove = async (id) => {
    if (!window.confirm('Delete this sport?')) return
    try { await api(`/sports/${id}`, { method: 'DELETE' }); reload(); toast('Sport removed.', 'good') } catch (err) { toast(err.message, 'bad') }
  }
  return (
    <>
      <PageHead eyebrow="Programmes" title="Sports & disciplines" subtitle="Each sport, its types, coaching focus and equipment catalogue." action={<button className="btn btn-primary" onClick={() => { setForm(EMPTY_SPORT); setOpen(true) }}><Plus size={16} /> Add sport</button>} />
      <div className="sport-grid">
        {data.map((s) => (
          <div className="glass sport-card" key={s.id}>
            <div className="glow-dot" style={{ '--sport-color': s.color }} />
            <div className="sport-emoji">{s.icon}</div>
            <h3>{s.name}</h3>
            <p>{s.description}</p>
            <div className="types">{(Array.isArray(s.types) ? s.types : JSON.parse(s.types || '[]')).map((t) => <span className="chip" key={t}>{t}</span>)}</div>
            <div className="row-actions" style={{ marginTop: '1rem' }}>
              <button className="btn-icon" onClick={() => { setForm({ ...s, types: (Array.isArray(s.types) ? s.types : JSON.parse(s.types || '[]')).join(', ') }); setOpen(true) }}><Pencil size={14} /></button>
              <button className="btn-icon" onClick={() => remove(s.id)}><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title={form.id ? 'Edit sport' : 'Add sport'}>
        <form onSubmit={save}>
          <div className="form-grid">
            <div className="field"><label>Name</label><input className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="field"><label>Icon (emoji)</label><input className="input" value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} /></div>
            <div className="field"><label>Accent colour</label><input className="input" type="color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></div>
            <div className="field"><label>Types (comma separated)</label><input className="input" value={form.types} onChange={(e) => setForm({ ...form, types: e.target.value })} placeholder="Foil, Épée, Sabre" /></div>
            <div className="field full"><label>Description</label><textarea className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Save</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Role-based access ---------------- */
const MODULES = ['students', 'achievements', 'fees', 'attendance', 'stock', 'finance', 'reports', 'announcements', 'queries']
export function OwnerAccess() {
  const { toast, refresh } = useApp()
  const { data, reload, loading } = useFetch('/permissions')
  const { data: staff } = useFetch('/staff')
  const setPerm = async (staffId, module, key, value) => {
    try {
      await api(`/permissions/${staffId}/${module}`, { method: 'PUT', body: { [key]: value ? 1 : 0 } })
      toast('Permission updated.', 'good'); reload(); refresh()
    } catch (err) { toast(err.message, 'bad') }
  }
  return (
    <>
      <PageHead eyebrow="Security" title="Role-based data access" subtitle="The owner controls exactly what each staff member can view or edit. Student accounts only see their own records." action={<span className="chip"><ShieldCheck size={14} /> Owner-only control</span>} />
      <div className="glass card">
        {loading && <div className="skeleton" />}
        {!loading && !data.length && <EmptyState text="Add staff to configure their permissions." />}
        {!!data.length && (
          <div className="table-wrap"><table>
            <thead><tr><th>Staff member</th>{MODULES.map((m) => <th key={m} style={{ textAlign: 'center' }}>{m}</th>)}</tr></thead>
            <tbody>
              {staff.filter((s) => s.id).map((s) => (
                <tr key={s.id}>
                  <td><b>{s.name}</b><div className="faint tiny">{s.sports}</div></td>
                  {MODULES.map((m) => {
                    const row = data.find((p) => p.staff_id === s.id && p.module === m) || {}
                    return (
                      <td key={m} style={{ textAlign: 'center' }}>
                        <div style={{ display: 'flex', justifyContent: 'center', gap: '.35rem' }}>
                          <button title={`Can view ${m}`} className={`btn-icon ${row.can_view ? '' : 'muted'}`} style={{ width: 28, height: 28, color: row.can_view ? 'var(--green)' : 'var(--faint)' }} onClick={() => setPerm(s.id, m, 'can_view', !row.can_view)}>V</button>
                          <button title={`Can edit ${m}`} className="btn-icon" style={{ width: 28, height: 28, color: row.can_edit ? 'var(--gold)' : 'var(--faint)' }} onClick={() => setPerm(s.id, m, 'can_edit', !row.can_edit)}>E</button>
                        </div>
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table></div>
        )}
        <p className="faint tiny" style={{ marginTop: '1rem' }}>V = view · E = edit. Changes apply immediately to the staff portal and the assistant.</p>
      </div>
    </>
  )
}

/* ---------------- Reports & exports ---------------- */
const DATASETS = [
  ['students', 'Students & athletes'], ['achievements', 'Medals & achievements'], ['fees', 'Fees & billing'],
  ['income', 'Income & finance'], ['stock', 'Equipment stock'], ['attendance', 'Biometric attendance'],
  ['staff', 'Staff directory'], ['announcements', 'Announcements'],
]
export function OwnerReports() {
  const { toast } = useApp()
  const { dashboard: d } = useApp()
  const exportIt = async (format, dataset) => {
    try { await downloadReport(format, dataset, `gsa-${dataset}`); toast(`${dataset} ${format.toUpperCase()} downloaded.`, 'good') }
    catch (err) { toast(err.message, 'bad') }
  }
  return (
    <>
      <PageHead eyebrow="Data & insights" title="Reports & exports" subtitle="Annual and monthly reports, financial status and academy growth — downloadable as PDF or Excel." action={<span className="chip"><Download size={14} /> {fmtDate(new Date())}</span>} />
      <div className="grid g-4">
        {[['Total income', fmtMoney(d?.summary?.totalIncome)], ['Total expense', fmtMoney(d?.summary?.totalExpense)], ['Pending fees', fmtMoney(d?.summary?.pendingFees)], ['Attendance rate', `${d?.summary?.attendanceRate ?? 0}%`]].map(([l, v]) => (
          <div className="glass card kpi" key={l}><div className="kpi-value" style={{ marginTop: 0 }}>{v}</div><div className="kpi-label">{l}</div></div>
        ))}
      </div>
      <div className="glass card" style={{ marginTop: '1rem' }}>
        <div className="card-head"><div><h3>Download centre</h3><p>Reports respect your role and active filters.</p></div></div>
        <div className="table-wrap"><table><thead><tr><th>Report</th><th style={{ width: 240 }}>Excel</th><th style={{ width: 240 }}>PDF</th></tr></thead>
          <tbody>{DATASETS.map(([id, label]) => (
            <tr key={id}><td><b>{label}</b></td>
              <td><button className="btn btn-ghost btn-sm" onClick={() => exportIt('xlsx', id)}><FileSpreadsheet size={14} /> Download .xlsx</button></td>
              <td><button className="btn btn-ghost btn-sm" onClick={() => exportIt('pdf', id)}><FileText size={14} /> Download .pdf</button></td>
            </tr>
          ))}</tbody>
        </table></div>
      </div>
      <div className="glass card" style={{ marginTop: '1rem' }}>
        <h3 className="h3">Monthly & annual status</h3>
        <p className="muted" style={{ fontSize: '.88rem', lineHeight: 1.7 }}>The overview dashboard carries a rolling 12-month income/expense series, sport-wise growth and live attendance health. Use the assistant in the corner to ask for any report — it can generate and download the file for you in English, Tamil or Hindi.</p>
      </div>
    </>
  )
}
