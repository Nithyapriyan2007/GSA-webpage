import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { BadgeIndianRupee, Download, PackagePlus, Plus, ScanLine, Trash2 } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { api, fmtDate, fmtMoney, statusTone } from '../../lib/api'
import { Badge, EmptyState, Modal, RingProgress } from '../../components/ui'
import DataTable from '../../components/DataTable'
import { PageHead, PhotoLink, useFetch } from './CommonPages'

/* ---------------- Fees ---------------- */
export function FeesPage() {
  const { user, toast, refresh } = useApp()
  const { data, reload } = useFetch('/fees')
  const { data: students } = useFetch(user?.role === 'owner' ? '/students' : '/students/me')
  const [open, setOpen] = useState(false)
  const [pay, setPay] = useState(null)
  const [form, setForm] = useState({ student_id: '', type: 'monthly', amount: '', units: '1', period: '', due_date: '', remarks: '' })
  const [payAmount, setPayAmount] = useState('')
  const isOwner = user?.role === 'owner'
  const paid = data.reduce((a, f) => a + Number(f.paid_amount || 0), 0)
  const due = data.reduce((a, f) => a + Math.max(0, Number(f.amount || 0) - Number(f.paid_amount || 0)), 0)

  const create = async (e) => {
    e.preventDefault()
    try { await api('/fees', { method: 'POST', body: form }); setOpen(false); toast('Fee entry created.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }
  const recordPayment = async (e) => {
    e.preventDefault()
    try { await api('/fees/pay', { method: 'POST', body: { id: pay.id, amount: Number(payAmount), method: 'scanner' } }); setPay(null); toast('Payment recorded. Receipt notification sent.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Billing" title={isOwner ? 'Fees & billing' : 'My fees'} subtitle="Fee structure, monthly/yearly units, current bill, payments and pending reminders." action={isOwner && <button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> New bill</button>} />
      <div className="grid g-3">
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0 }}>{fmtMoney(paid)}</div><div className="kpi-label">Collected</div></div>
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0, color: 'var(--rose)' }}>{fmtMoney(due)}</div><div className="kpi-label">Pending</div></div>
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0 }}>{data.length}</div><div className="kpi-label">Bills / installments</div></div>
      </div>
      <div className="glass card" style={{ marginTop: '1rem' }}>
        <DataTable data={data} searchKeys={['student_name', 'period', 'type', 'status']} columns={[
          { key: 'student_name', label: 'Athlete', render: (r) => <b>{r.student_name || '—'}</b> },
          { key: 'type', label: 'Type', render: (r) => <Badge tone={r.type === 'yearly' ? 'warn' : 'neutral'}>{r.type}</Badge> },
          { key: 'period', label: 'Period' },
          { key: 'units', label: 'Units' },
          { key: 'amount', label: 'Amount', render: (r) => fmtMoney(r.amount) },
          { key: 'paid_amount', label: 'Paid', render: (r) => fmtMoney(r.paid_amount) },
          { key: 'due_date', label: 'Due', render: (r) => fmtDate(r.due_date) },
          { key: 'status', label: 'Status', render: (r) => <Badge tone={statusTone(r.status)}>{r.status}</Badge> },
          { key: 'id', label: 'Action', sortable: false, render: (r) => isOwner && Number(r.paid_amount || 0) < Number(r.amount) ? <button className="btn btn-outline btn-sm" onClick={() => { setPay(r); setPayAmount(String(Number(r.amount) - Number(r.paid_amount || 0))) }}><ScanLine size={13} /> Collect</button> : '—' },
        ]} />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Create a fee bill">
        <form onSubmit={create}>
          <div className="form-grid">
            <div className="field full"><label>Athlete</label><select className="input" required value={form.student_id} onChange={(e) => setForm({ ...form, student_id: e.target.value })}><option value="">Select student</option>{(Array.isArray(students) ? students : [students]).filter(Boolean).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
            <div className="field"><label>Type</label><select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="monthly">Monthly</option><option value="yearly">Yearly</option><option value="entry">Entry fees</option><option value="equipment">Equipment</option></select></div>
            <div className="field"><label>Amount (₹)</label><input className="input" type="number" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            <div className="field"><label>Units</label><input className="input" type="number" value={form.units} onChange={(e) => setForm({ ...form, units: e.target.value })} /></div>
            <div className="field"><label>Period</label><input className="input" value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })} placeholder="Nov 2026" /></div>
            <div className="field"><label>Due date</label><input className="input" type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></div>
            <div className="field full"><label>Remarks</label><input className="input" value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Create bill</button></div>
        </form>
      </Modal>
      <Modal open={!!pay} onClose={() => setPay(null)} title="Record fee payment" subtitle="Scanner / cash payment entry. An alert is sent to the athlete.">
        <form onSubmit={recordPayment}>
          <p className="muted" style={{ fontSize: '.88rem' }}>{pay?.student_name || 'Athlete'} · {pay?.period} · Balance {fmtMoney(Number(pay?.amount || 0) - Number(pay?.paid_amount || 0))}</p>
          <div className="field"><label>Amount received (₹)</label><input className="input" type="number" required value={payAmount} onChange={(e) => setPayAmount(e.target.value)} /></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem' }}><button type="button" className="btn btn-ghost" onClick={() => setPay(null)}>Cancel</button><button className="btn btn-primary"><BadgeIndianRupee size={15} /> Confirm payment</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Equipment stock ---------------- */
export function StockPage() {
  const { user, toast } = useApp()
  const { data, reload } = useFetch('/stock')
  const { data: txns, reload: reloadTxns } = useFetch('/equipment-txns')
  const [add, setAdd] = useState(false)
  const [tx, setTx] = useState(false)
  const [form, setForm] = useState({ sport: 'Fencing', item: '', quantity: '', unit_price: '', reorder_level: '3' })
  const [tform, setTform] = useState({ sport: 'Fencing', item: '', qty: '', type: 'purchase', amount: '', party: '' })
  const isOwner = user?.role === 'owner'

  const saveItem = async (e) => {
    e.preventDefault()
    try { await api('/stock', { method: 'POST', body: form }); setAdd(false); toast('Equipment added to stock.', 'good'); reload() }
    catch (err) { toast(err.message, 'bad') }
  }
  const saveTxn = async (e) => {
    e.preventDefault()
    try { await api('/stock/transaction', { method: 'POST', body: tform }); setTx(false); toast(`${tform.type} recorded.`, 'good'); reload(); reloadTxns() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Inventory" title="Equipment stock" subtitle="Professional, sport-specific equipment with purchase, sale and amount earned per sport." action={isOwner && <div style={{ display: 'flex', gap: '.5rem' }}><button className="btn btn-ghost" onClick={() => setTx(true)}><PackagePlus size={16} /> Purchase / sell</button><button className="btn btn-primary" onClick={() => setAdd(true)}><Plus size={16} /> Add item</button></div>} />
      <div className="grid g-21">
        <div className="glass card">
          <DataTable data={data} searchKeys={['sport', 'item']} columns={[
            { key: 'sport', label: 'Sport', render: (r) => <Badge tone="warn">{r.sport}</Badge> },
            { key: 'item', label: 'Equipment', render: (r) => <b>{r.item}</b> },
            { key: 'quantity', label: 'In stock', render: (r) => <b style={{ color: Number(r.quantity) <= Number(r.reorder_level || 3) ? 'var(--rose)' : 'var(--green)' }}>{r.quantity}</b> },
            { key: 'reorder_level', label: 'Reorder at' },
            { key: 'unit_price', label: 'Unit price', render: (r) => fmtMoney(r.unit_price) },
            { key: 'value', label: 'Value', render: (r) => fmtMoney(Number(r.quantity || 0) * Number(r.unit_price || 0)) },
          ]} />
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Purchase & sales log</h3><p>Amount earned by sport</p></div></div>
          <div className="list">
            {txns.slice(0, 10).map((t) => <div className="list-row" key={t.id}><Badge tone={t.type === 'sold' ? 'good' : 'neutral'}>{t.type}</Badge><div className="grow"><strong>{t.item}</strong><small>{t.sport} · {t.party || '—'} · {fmtDate(t.date)}</small></div><b>{fmtMoney(t.amount)}</b></div>)}
            {!txns.length && <EmptyState text="No equipment transactions yet." />}
          </div>
        </div>
      </div>
      <Modal open={add} onClose={() => setAdd(false)} title="Add equipment to stock">
        <form onSubmit={saveItem}>
          <div className="form-grid">
            <div className="field"><label>Sport</label><select className="input" value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })}>{['Fencing', 'Chess', 'Carrom', 'Yoga', 'Drawing', 'Cricket', 'Archery', 'Table Tennis'].map((s) => <option key={s}>{s}</option>)}</select></div>
            <div className="field"><label>Item</label><input className="input" required value={form.item} onChange={(e) => setForm({ ...form, item: e.target.value })} /></div>
            <div className="field"><label>Quantity</label><input className="input" type="number" required value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
            <div className="field"><label>Unit price (₹)</label><input className="input" type="number" required value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: e.target.value })} /></div>
            <div className="field"><label>Reorder level</label><input className="input" type="number" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setAdd(false)}>Cancel</button><button className="btn btn-primary">Add</button></div>
        </form>
      </Modal>
      <Modal open={tx} onClose={() => setTx(false)} title="Equipment transaction">
        <form onSubmit={saveTxn}>
          <div className="form-grid">
            <div className="field"><label>Type</label><select className="input" value={tform.type} onChange={(e) => setTform({ ...tform, type: e.target.value })}><option value="purchase">Purchase</option><option value="sold">Sold</option></select></div>
            <div className="field"><label>Sport</label><input className="input" value={tform.sport} onChange={(e) => setTform({ ...tform, sport: e.target.value })} /></div>
            <div className="field"><label>Item</label><input className="input" required value={tform.item} onChange={(e) => setTform({ ...tform, item: e.target.value })} /></div>
            <div className="field"><label>Quantity</label><input className="input" type="number" required value={tform.qty} onChange={(e) => setTform({ ...tform, qty: e.target.value })} /></div>
            <div className="field"><label>Amount (₹)</label><input className="input" type="number" required value={tform.amount} onChange={(e) => setTform({ ...tform, amount: e.target.value })} /></div>
            <div className="field"><label>Party / vendor</label><input className="input" value={tform.party} onChange={(e) => setTform({ ...tform, party: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setTx(false)}>Cancel</button><button className="btn btn-primary">Record</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Finance ---------------- */
export function FinancePage() {
  const { toast, dashboard: d } = useApp()
  const { data, reload } = useFetch('/income')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ source: 'Student Fees', sport: 'Fencing', amount: '', description: '', date: new Date().toISOString().slice(0, 10) })
  const add = async (e) => {
    e.preventDefault()
    try { await api('/income', { method: 'POST', body: form }); setOpen(false); toast('Income entry recorded.', 'good'); reload() }
    catch (err) { toast(err.message, 'bad') }
  }
  const bySport = (d?.finance?.expenseBySport || []).slice(0, 8)
  return (
    <>
      <PageHead eyebrow="Money matters" title="Finance & growth" subtitle="Income from student fees, entry fees, cash prize entries and equipment sales — against expenses." action={<button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> Add income</button>} />
      <div className="grid g-4">
        {[['Total income', d?.summary?.totalIncome], ['Total expense', d?.summary?.totalExpense], ['Pending fees', d?.summary?.pendingFees], ['Monthly growth', `${d?.summary?.monthGrowth ?? 0}%`]].map(([l, v]) => <div className="glass card kpi" key={l}><div className="kpi-value" style={{ marginTop: 0 }}>{typeof v === 'number' ? fmtMoney(v) : v}</div><div className="kpi-label">{l}</div></div>)}
      </div>
      <div className="grid g-21" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Income ledger</h3><p>Every source tracked separately</p></div></div>
          <DataTable data={data} searchKeys={['source', 'sport', 'description']} columns={[
            { key: 'date', label: 'Date', render: (r) => fmtDate(r.date) },
            { key: 'source', label: 'Source', render: (r) => <Badge tone="warn">{r.source}</Badge> },
            { key: 'sport', label: 'Sport' },
            { key: 'description', label: 'Description' },
            { key: 'amount', label: 'Amount', render: (r) => <b style={{ color: 'var(--green)' }}>{fmtMoney(r.amount)}</b> },
          ]} />
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Expense by sport</h3><p>Equipment purchase & operations</p></div></div>
          <div className="chart-box sm"><ResponsiveContainer width="100%" height="100%"><BarChart data={bySport}><CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} /><XAxis dataKey="sport" tick={{ fill: 'var(--muted)', fontSize: 10 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: 'var(--muted)', fontSize: 10 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--glass-border)', borderRadius: 12, color: 'var(--text)' }} /><Bar dataKey="total" fill="#a78bfa" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div>
        </div>
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Record income">
        <form onSubmit={add}>
          <div className="form-grid">
            <div className="field"><label>Source</label><select className="input" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })}>{['Student Fees', 'Entry Fees', 'Cash Prize Entry', 'Equipment Sold', 'Other'].map((s) => <option key={s}>{s}</option>)}</select></div>
            <div className="field"><label>Sport</label><input className="input" value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} /></div>
            <div className="field"><label>Amount (₹)</label><input className="input" type="number" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            <div className="field"><label>Date</label><input className="input" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            <div className="field full"><label>Description</label><input className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Record</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Attendance ---------------- */
export function AttendancePage() {
  const { user, toast, refresh } = useApp()
  const { data, reload } = useFetch('/attendance')
  const { data: students } = useFetch(user?.role === 'student' ? '/students/me' : '/students')
  const [open, setOpen] = useState(false)
  const [scan, setScan] = useState(false)
  const [form, setForm] = useState({ student_id: '', event: 'entry', date: new Date().toISOString().slice(0, 10), time: new Date().toTimeString().slice(0, 5), location: 'Main academy', notes: '' })
  const [code, setCode] = useState('')
  const [codeEvent, setCodeEvent] = useState('entry')
  const canRecord = user?.role !== 'student'
  const entries = data.filter((a) => a.event === 'entry').length
  const exits = data.filter((a) => a.event === 'exit').length
  const rate = data.length ? Math.min(100, Math.round((entries / Math.max(1, exits || entries)) * 100)) : 0

  const submit = async (e) => {
    e.preventDefault()
    try { await api('/attendance', { method: 'POST', body: form }); setOpen(false); toast('Attendance recorded and parent notified.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }
  const scanSubmit = async (e) => {
    e.preventDefault()
    try { await api('/attendance/scan', { method: 'POST', body: { student_code: code, event: codeEvent } }); setScan(false); setCode(''); toast('Biometric scan accepted. Notification sent.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Biometric system" title="Attendance & movement" subtitle="Every entry and exit with date, time and details — alerts reach parents automatically." action={canRecord && <div style={{ display: 'flex', gap: '.5rem' }}><button className="btn btn-ghost" onClick={() => setScan(true)}><ScanLine size={16} /> Scanner</button><button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> Record event</button></div>} />
      <div className="grid g-4">
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0 }}>{entries}</div><div className="kpi-label">Entries</div></div>
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0 }}>{exits}</div><div className="kpi-label">Exits</div></div>
        <div className="glass card"><div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}><RingProgress value={rate} size={74} stroke={7} /><div><div className="kpi-label">Session completion</div><strong style={{ fontSize: '1.1rem' }}>{rate}%</strong></div></div></div>
        <div className="glass card kpi"><div className="kpi-value" style={{ marginTop: 0 }}>24/7</div><div className="kpi-label">CCTV + 360° coverage</div></div>
      </div>
      <div className="glass card" style={{ marginTop: '1rem' }}>
        <DataTable data={data} searchKeys={['student_name', 'event', 'location', 'date']} columns={[
          { key: 'student_name', label: 'Athlete', render: (r) => <b>{r.student_name || '—'}</b> },
          { key: 'event', label: 'Event', render: (r) => <Badge tone={r.event === 'entry' ? 'good' : 'neutral'}>{r.event}</Badge> },
          { key: 'date', label: 'Date', render: (r) => fmtDate(r.date) },
          { key: 'time', label: 'Time', render: (r) => String(r.time || '').slice(0, 5) },
          { key: 'location', label: 'Location' },
          { key: 'notes', label: 'Details' },
        ]} />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Record attendance event">
        <form onSubmit={submit}>
          <div className="form-grid">
            <div className="field full"><label>Athlete</label><select className="input" required value={form.student_id} onChange={(e) => setForm({ ...form, student_id: e.target.value })}><option value="">Select athlete</option>{(Array.isArray(students) ? students : [students]).filter(Boolean).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
            <div className="field"><label>Event</label><select className="input" value={form.event} onChange={(e) => setForm({ ...form, event: e.target.value })}><option value="entry">Entry</option><option value="exit">Exit</option></select></div>
            <div className="field"><label>Date</label><input className="input" type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            <div className="field"><label>Time</label><input className="input" type="time" required value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} /></div>
            <div className="field"><label>Location</label><input className="input" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
            <div className="field full"><label>Notes</label><input className="input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Save event</button></div>
        </form>
      </Modal>
      <Modal open={scan} onClose={() => setScan(false)} title="Biometric / QR scanner simulation" subtitle="Enter the athlete code (GSA-####) or registered phone number.">
        <form onSubmit={scanSubmit}>
          <div className="field"><label>Student code or phone</label><input className="input" required value={code} onChange={(e) => setCode(e.target.value)} placeholder="GSA-1001" /></div>
          <div className="field"><label>Event</label><select className="input" value={codeEvent} onChange={(e) => setCodeEvent(e.target.value)}><option value="entry">Entry</option><option value="exit">Exit</option></select></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem' }}><button type="button" className="btn btn-ghost" onClick={() => setScan(false)}>Cancel</button><button className="btn btn-primary"><ScanLine size={15} /> Accept scan</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Achievements ---------------- */
export function AchievementsPage() {
  const { user, toast, refresh } = useApp()
  const { data, reload } = useFetch('/achievements')
  const { data: students } = useFetch(user?.role === 'owner' ? '/students' : '/students/me')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ student_id: '', title: '', sport: 'Fencing', category1: 'State', category2: 'Junior', medal: 'Gold', match_name: '', match_date: '', match_details: '', prize_photo: '' })
  const isOwner = user?.role === 'owner'
  const add = async (e) => {
    e.preventDefault()
    try { await api('/achievements', { method: 'POST', body: form }); setOpen(false); toast('Achievement recorded.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }
  const remove = async (id) => {
    if (!window.confirm('Delete this achievement?')) return
    try { await api(`/achievements/${id}`, { method: 'DELETE' }); reload(); toast('Achievement removed.', 'good') } catch (err) { toast(err.message, 'bad') }
  }
  return (
    <>
      <PageHead eyebrow="Hall of champions" title="Medals & achievements" subtitle="District, state, national and international records across Sub-Junior, Junior, Senior and Youth categories." action={isOwner && <button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> Record medal</button>} />
      <div className="glass card">
        <DataTable data={data} searchKeys={['student_name', 'title', 'sport', 'category1', 'category2', 'medal']} columns={[
          { key: 'student_name', label: 'Athlete', render: (r) => <b>{r.student_name || '—'}</b> },
          { key: 'title', label: 'Achievement' },
          { key: 'sport', label: 'Sport', render: (r) => <Badge tone="warn">{r.sport}</Badge> },
          { key: 'category1', label: 'Level' },
          { key: 'category2', label: 'Category' },
          { key: 'medal', label: 'Medal', render: (r) => <Badge tone={String(r.medal).toLowerCase().includes('gold') ? 'warn' : 'good'}>{r.medal}</Badge> },
          { key: 'match_date', label: 'Date', render: (r) => fmtDate(r.match_date) },
          { key: 'prize_photo', label: 'Photo', sortable: false, render: (r) => <PhotoLink url={r.prize_photo} /> },
          { key: 'id', label: 'Action', sortable: false, render: (r) => isOwner ? <button className="btn-icon" onClick={() => remove(r.id)}><Trash2 size={14} /></button> : '—' },
        ]} />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Record an achievement">
        <form onSubmit={add}>
          <div className="form-grid">
            <div className="field full"><label>Athlete</label><select className="input" required value={form.student_id} onChange={(e) => setForm({ ...form, student_id: e.target.value })}><option value="">Select athlete</option>{(Array.isArray(students) ? students : [students]).filter(Boolean).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
            <div className="field"><label>Title</label><input className="input" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div className="field"><label>Sport</label><input className="input" value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} /></div>
            <div className="field"><label>Level</label><select className="input" value={form.category1} onChange={(e) => setForm({ ...form, category1: e.target.value })}>{['District', 'State', 'National', 'International'].map((s) => <option key={s}>{s}</option>)}</select></div>
            <div className="field"><label>Category</label><select className="input" value={form.category2} onChange={(e) => setForm({ ...form, category2: e.target.value })}>{['Sub-Junior', 'Junior', 'Senior', 'Youth'].map((s) => <option key={s}>{s}</option>)}</select></div>
            <div className="field"><label>Medal</label><select className="input" value={form.medal} onChange={(e) => setForm({ ...form, medal: e.target.value })}>{['Gold', 'Silver', 'Bronze', 'Participation'].map((s) => <option key={s}>{s}</option>)}</select></div>
            <div className="field"><label>Match name</label><input className="input" value={form.match_name} onChange={(e) => setForm({ ...form, match_name: e.target.value })} /></div>
            <div className="field"><label>Match date</label><input className="input" type="date" value={form.match_date} onChange={(e) => setForm({ ...form, match_date: e.target.value })} /></div>
            <div className="field full"><label>Match details</label><textarea className="input" value={form.match_details} onChange={(e) => setForm({ ...form, match_details: e.target.value })} /></div>
            <div className="field full"><label>Prize photo link (parents can download)</label><input className="input" value={form.prize_photo} onChange={(e) => setForm({ ...form, prize_photo: e.target.value })} placeholder="https://…" /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem', marginTop: '1rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Save achievement</button></div>
        </form>
      </Modal>
    </>
  )
}
