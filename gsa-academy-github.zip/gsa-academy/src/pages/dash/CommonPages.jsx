import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Bell, Check, CheckCheck, Download, Image as ImageIcon, MessageCircleQuestion, Plus,
  Send, Trash2,
} from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { api, fmtDate, fmtMoney, statusTone } from '../../lib/api'
import { Badge, EmptyState, Modal } from '../../components/ui'
import DataTable from '../../components/DataTable'

export function useFetch(path, deps = []) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await api(path)
      setData(Array.isArray(res) ? res : res.items || [])
      setError('')
    } catch (err) {
      setError(err.message)
      setData([])
    } finally { setLoading(false) }
  }, [path])
  useEffect(() => { load() }, [load, ...deps])
  return { data, loading, error, reload: load, setData }
}

function PageHead({ eyebrow, title, subtitle, action }) {
  return (
    <div className="page-head">
      <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{subtitle}</p></div>
      {action}
    </div>
  )
}

/* ---------------- Announcements ---------------- */
export function AnnouncementsPage() {
  const { user, toast, refresh } = useApp()
  const { data, reload } = useFetch('/announcements')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ title: '', body: '', audience: 'all' })
  const [busy, setBusy] = useState(false)
  const isOwner = user?.role === 'owner'

  const publish = async (e) => {
    e.preventDefault(); setBusy(true)
    try {
      await api('/announcements', { method: 'POST', body: form })
      setForm({ title: '', body: '', audience: 'all' }); setOpen(false)
      toast('Announcement published to the dashboard board.', 'good')
      reload(); refresh()
    } catch (err) { toast(err.message, 'bad') } finally { setBusy(false) }
  }

  const remove = async (id) => {
    try { await api(`/announcements/${id}`, { method: 'DELETE' }); toast('Announcement removed.', 'good'); reload(); refresh() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Notice board" title="Announcements" subtitle="Official messages published by the owner for students and staff." action={isOwner && <button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> New announcement</button>} />
      <div className="grid g-2">
        {data.map((a, i) => (
          <motion.div key={a.id} className="glass card glass-hover" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * .05 }}>
            <div className="card-head">
              <div><h3>{a.title}</h3><p>{fmtDate(a.date || a.created_at)} · {a.author || a.author_name || 'Academy owner'}</p></div>
              <div style={{ display: 'flex', gap: '.4rem' }}>
                <Badge tone={a.audience === 'all' ? 'neutral' : a.audience === 'staff' ? 'violet' : 'warn'}>{a.audience}</Badge>
                {isOwner && <button className="btn-icon" onClick={() => remove(a.id)} title="Delete"><Trash2 size={14} /></button>}
              </div>
            </div>
            <p style={{ color: 'var(--muted)', lineHeight: 1.75, fontSize: '.9rem', margin: 0, whiteSpace: 'pre-wrap' }}>{a.body || a.message}</p>
          </motion.div>
        ))}
        {!data.length && <div className="glass card"><EmptyState text="No announcements have been published yet." /></div>}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Publish announcement" subtitle="Delivered instantly to the dashboards and notification centre.">
        <form onSubmit={publish}>
          <div className="field"><label>Title</label><input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Inter-state fencing camp" required /></div>
          <div className="field"><label>Audience</label><select className="input" value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })}><option value="all">Everyone (students + staff)</option><option value="students">Students only</option><option value="staff">Staff only</option></select></div>
          <div className="field"><label>Message</label><textarea className="input" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder="Write the message…" required /></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary" disabled={busy}>{busy ? 'Publishing…' : 'Publish'}<Send size={15} /></button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Notifications ---------------- */
export function NotificationsPage() {
  const { notifications, unread, markRead } = useApp()
  return (
    <>
      <PageHead eyebrow="Alert centre" title="Notifications" subtitle="Biometric entry/exit alerts, fee reminders, attendance warnings and announcements." action={<span className="badge warn">{unread} unread</span>} />
      <div className="glass card">
        {!notifications.length && <EmptyState text="No notifications yet." />}
        <div className="list">
          {notifications.map((n) => (
            <div className={`list-row ${!n.is_read ? 'unread' : ''}`} key={n.id} style={!n.is_read ? { borderColor: 'rgba(245,185,66,.3)' } : undefined}>
              {!n.is_read ? <span className="notif-dot" /> : <Check size={15} color="var(--green)" />}
              <div className="grow"><strong>{n.title}</strong><small>{n.body}</small><div className="faint tiny" style={{ marginTop: '.25rem' }}>{fmtDate(n.created_at)}</div></div>
              <Badge tone={n.type || 'neutral'}>{n.type || 'info'}</Badge>
              {!n.is_read && <button className="btn btn-ghost btn-sm" onClick={() => markRead(n.id)}><CheckCheck size={13} /> Mark read</button>}
            </div>
          ))}
        </div>
      </div>
    </>
  )
}

/* ---------------- Queries / suggestions / help ---------------- */
export function QueriesPage() {
  const { user, toast } = useApp()
  const { data, reload } = useFetch('/queries')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ type: 'query', subject: '', message: '' })
  const [reply, setReply] = useState({})
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setBusy(true)
    try { await api('/queries', { method: 'POST', body: form }); setOpen(false); setForm({ type: 'query', subject: '', message: '' }); toast('Your message reached the academy.', 'good'); reload() }
    catch (err) { toast(err.message, 'bad') } finally { setBusy(false) }
  }
  const answer = async (id) => {
    try { await api(`/queries/${id}`, { method: 'PATCH', body: { reply: reply[id] || '', status: 'replied' } }); toast('Reply saved.', 'good'); reload() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="We’re here to help" title="Queries, suggestions & help" subtitle="Available to every student and staff member. The owner and coaching team respond here." action={<button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> New message</button>} />
      <div className="grid g-2">
        {data.map((q) => (
          <div className="glass card" key={q.id}>
            <div className="card-head"><div><h3>{q.subject}</h3><p>{q.author_name || 'Athlete'} · {fmtDate(q.created_at)}</p></div><div style={{ display: 'flex', gap: '.4rem' }}><Badge tone={q.type === 'help' ? 'bad' : q.type === 'suggestion' ? 'warn' : 'neutral'}>{q.type}</Badge><Badge tone={statusTone(q.status)}>{q.status}</Badge></div></div>
            <p className="muted" style={{ fontSize: '.88rem', lineHeight: 1.7 }}>{q.message}</p>
            {q.reply && <div style={{ padding: '.8rem', borderRadius: 12, background: 'rgba(94,234,212,.07)', border: '1px solid rgba(94,234,212,.2)', marginTop: '.8rem' }}><strong className="tiny" style={{ color: 'var(--teal)' }}>REPLY</strong><p className="muted" style={{ margin: '.3rem 0 0', fontSize: '.85rem' }}>{q.reply}</p></div>}
            {user?.role !== 'student' && !q.reply && <div style={{ display: 'flex', gap: '.5rem', marginTop: '.9rem' }}><input className="input" value={reply[q.id] || ''} onChange={(e) => setReply({ ...reply, [q.id]: e.target.value })} placeholder="Type a reply…" /><button className="btn btn-primary btn-sm" onClick={() => answer(q.id)}>Reply</button></div>}
          </div>
        ))}
        {!data.length && <div className="glass card"><EmptyState text="No messages yet. Ask a question or share a suggestion." /></div>}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Send a message">
        <form onSubmit={submit}>
          <div className="field"><label>Type</label><select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="query">Query</option><option value="suggestion">Suggestion</option><option value="help">Help</option></select></div>
          <div className="field"><label>Subject</label><input className="input" required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></div>
          <div className="field"><label>Message</label><textarea className="input" required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary" disabled={busy}>Send</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Leaves ---------------- */
export function LeavesPage() {
  const { user, toast } = useApp()
  const { data, reload } = useFetch('/leaves')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ from_date: '', to_date: '', reason: '' })
  const isStudent = user?.role === 'student'

  const submit = async (e) => {
    e.preventDefault()
    try { await api('/leaves', { method: 'POST', body: form }); setOpen(false); toast('Leave request sent.', 'good'); reload() }
    catch (err) { toast(err.message, 'bad') }
  }
  const decide = async (id, status) => {
    try { await api(`/leaves/${id}`, { method: 'PATCH', body: { status } }); toast(`Request ${status}.`, 'good'); reload() }
    catch (err) { toast(err.message, 'bad') }
  }

  return (
    <>
      <PageHead eyebrow="Time away" title="Leave requests" subtitle="Training leave with approval tracking for athletes and staff." action={isStudent && <button className="btn btn-primary" onClick={() => setOpen(true)}><Plus size={16} /> Request leave</button>} />
      <div className="glass card">
        <DataTable data={data} searchKeys={['reason', 'status', 'student_name']} columns={[
          { key: 'student_name', label: 'Athlete', render: (r) => <b>{r.student_name || r.name || '—'}</b> },
          { key: 'from_date', label: 'From', render: (r) => fmtDate(r.from_date) },
          { key: 'to_date', label: 'To', render: (r) => fmtDate(r.to_date) },
          { key: 'reason', label: 'Reason' },
          { key: 'status', label: 'Status', render: (r) => <Badge tone={statusTone(r.status)}>{r.status}</Badge> },
          { key: 'id', label: 'Action', sortable: false, render: (r) => !isStudent && r.status === 'requested' ? <div className="row-actions"><button className="btn btn-good btn-sm" style={{ color: 'var(--green)' }} onClick={() => decide(r.id, 'approved')}>Approve</button><button className="btn btn-danger btn-sm" onClick={() => decide(r.id, 'rejected')}>Reject</button></div> : '—' },
        ]} />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Request leave">
        <form onSubmit={submit}>
          <div className="form-grid">
            <div className="field"><label>From</label><input className="input" type="date" required value={form.from_date} onChange={(e) => setForm({ ...form, from_date: e.target.value })} /></div>
            <div className="field"><label>To</label><input className="input" type="date" required value={form.to_date} onChange={(e) => setForm({ ...form, to_date: e.target.value })} /></div>
            <div className="field full"><label>Reason</label><textarea className="input" required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '.6rem' }}><button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn btn-primary">Submit</button></div>
        </form>
      </Modal>
    </>
  )
}

/* ---------------- Generic prize-photo download helper ---------------- */
export function PhotoLink({ url }) {
  if (!url) return <span className="faint">—</span>
  return <a href={url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm"><ImageIcon size={13} /> View</a>
}

export { PageHead }
