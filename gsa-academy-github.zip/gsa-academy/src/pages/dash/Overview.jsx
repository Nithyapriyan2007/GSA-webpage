import { Link } from 'react-router-dom'
import {
  AlertTriangle, ArrowRight, Award, Banknote, CalendarCheck, CircleDollarSign, Medal,
  Package, TrendingUp, Trophy, UserCheck, Users,
} from 'lucide-react'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis,
} from 'recharts'
import { useApp } from '../../context/AppContext'
import { Badge, EmptyState, RingProgress } from '../../components/ui'
import { fmtDate, fmtMoney, statusTone } from '../../lib/api'

const COLORS = ['#f5b942', '#5eead4', '#a78bfa', '#6aa9ff', '#fb7185', '#4ade80']

function Kpi({ icon: Icon, label, value, trend, tone = '' }) {
  return (
    <div className="glass card kpi glass-hover">
      <div className={`kpi-ic ${tone}`}><Icon size={19} /></div>
      <div className="kpi-value">{value}</div>
      <div className="kpi-label">{label}</div>
      {trend !== undefined && <div className={`kpi-trend ${Number(trend) >= 0 ? 'up' : 'down'}`}><TrendingUp size={12} /> {trend}% vs last month</div>}
    </div>
  )
}

function OwnerOverview() {
  const { dashboard: d } = useApp()
  if (!d) return <div className="skeleton" />
  const s = d.summary || {}
  const monthly = d.monthly || []
  const sport = d.sportPerformance || []
  const income = d.finance?.incomeBySource || []
  const announcements = d.announcements || []

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">Command centre</span>
          <h1>Academy at a glance</h1>
          <p>Complete status of athletes, coaching, finance and operations — live from GSA.</p>
        </div>
        <Link to="/app/reports" className="btn btn-primary">Generate report <ArrowRight size={15} /></Link>
      </div>

      <div className="grid g-4">
        <Kpi icon={Users} label="Active athletes" value={s.students ?? '—'} trend={s.monthGrowth} />
        <Kpi icon={UserCheck} label="Coaching staff" value={s.staff ?? '—'} tone="violet" />
        <Kpi icon={Medal} label="Medals earned" value={s.medals ?? '—'} tone="teal" />
        <Kpi icon={CircleDollarSign} label="Total income" value={fmtMoney(s.totalIncome)} tone="rose" />
      </div>

      <div className="grid g-21" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Income vs Expense</h3><p>Last 12 months · all sports</p></div><span className="badge good">Growth {s.monthGrowth ?? 0}%</span></div>
          <div className="chart-box">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthly}>
                <defs>
                  <linearGradient id="gInc" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#f5b942" stopOpacity={.5} /><stop offset="100%" stopColor="#f5b942" stopOpacity={0} /></linearGradient>
                  <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#a78bfa" stopOpacity={.4} /><stop offset="100%" stopColor="#a78bfa" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} />
                <XAxis dataKey="month" tick={{ fill: 'var(--muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--glass-border)', borderRadius: 12, color: 'var(--text)' }} />
                <Area type="monotone" dataKey="income" name="Income" stroke="#f5b942" fill="url(#gInc)" strokeWidth={2} />
                <Area type="monotone" dataKey="expense" name="Expense" stroke="#a78bfa" fill="url(#gExp)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Where income comes from</h3><p>Fees · entries · prizes · sales</p></div></div>
          <div className="chart-box">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={income} dataKey="total" nameKey="source" innerRadius="52%" outerRadius="78%" paddingAngle={3} stroke="none">
                  {income.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--glass-border)', borderRadius: 12, color: 'var(--text)' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid" style={{ gap: '.35rem' }}>
            {income.slice(0, 5).map((r, i) => <div key={r.source} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.75rem' }}><span className="muted"><i style={{ display: 'inline-block', width: 7, height: 7, borderRadius: 4, background: COLORS[i % COLORS.length], marginRight: 6 }} />{r.source}</span><b>{fmtMoney(r.total)}</b></div>)}
          </div>
        </div>
      </div>

      <div className="grid g-2" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Sport-wise performance</h3><p>Athletes, medals and revenue by discipline</p></div></div>
          <div className="chart-box sm">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sport} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" horizontal={false} />
                <XAxis type="number" tick={{ fill: 'var(--muted)', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="sport" width={100} tick={{ fill: 'var(--muted)', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: 'var(--bg-2)', border: '1px solid var(--glass-border)', borderRadius: 12, color: 'var(--text)' }} />
                <Bar dataKey="medals" name="Medals" fill="#f5b942" radius={[0, 6, 6, 0]} barSize={11} />
                <Bar dataKey="students" name="Athletes" fill="#5eead4" radius={[0, 6, 6, 0]} barSize={11} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Attention needed</h3><p>Low stock, pending fees & attendance</p></div><AlertTriangle size={17} color="var(--gold)" /></div>
          <div className="list">
            <Link to="/app/stock" className="list-row"><span className="badge warn">{(d.stockAlerts || []).length}</span><div className="grow"><strong>Equipment items running low</strong><small>Review and purchase before training is affected</small></div><ArrowRight size={15} /></Link>
            <Link to="/app/fees" className="list-row"><span className="badge bad">{fmtMoney(s.pendingFees)}</span><div className="grow"><strong>Pending fee amounts</strong><small>Send reminders and record scanner/cash payments</small></div><ArrowRight size={15} /></Link>
            <Link to="/app/attendance" className="list-row"><span className="badge good">{s.attendanceRate ?? 0}%</span><div className="grow"><strong>Attendance health</strong><small>Biometric entries and exits across the academy</small></div><ArrowRight size={15} /></Link>
            <Link to="/app/finance" className="list-row"><span className="badge neutral">{fmtMoney(s.totalExpense)}</span><div className="grow"><strong>Total expenses</strong><small>Equipment purchase and other operating costs</small></div><ArrowRight size={15} /></Link>
          </div>
        </div>
      </div>

      <div className="grid g-2" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Recent medals</h3><p>Latest achievements across all sports</p></div><Link to="/app/achievements" className="link tiny">View all</Link></div>
          <div className="list">
            {(d.recentAchievements || []).slice(0, 5).map((a) => (
              <div className="list-row" key={a.id}><div className="avatar">{a.medal?.[0] || 'M'}</div><div className="grow"><strong>{a.student_name || a.title}</strong><small>{a.title} · {a.category1} · {a.category2}</small></div><Badge tone={String(a.medal).toLowerCase().includes('gold') ? 'warn' : 'good'}>{a.medal}</Badge></div>
            ))}
            {!(d.recentAchievements || []).length && <EmptyState text="No achievements recorded yet." />}
          </div>
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Announcement board</h3><p>Published by the academy owner</p></div><Link to="/app/announcements" className="link tiny">Manage</Link></div>
          <div className="list">
            {announcements.slice(0, 5).map((a) => (
              <div className="list-row" key={a.id}><div className="avatar violet"><Award size={15} /></div><div className="grow"><strong>{a.title}</strong><small>{String(a.body || a.message).slice(0, 90)}…</small></div><span className="faint tiny">{fmtDate(a.date || a.created_at)}</span></div>
            ))}
            {!announcements.length && <EmptyState text="No announcements yet." />}
          </div>
        </div>
      </div>
    </>
  )
}

function StaffOverview() {
  const { dashboard: d, user } = useApp()
  if (!d) return <div className="skeleton" />
  const s = d.summary || {}
  const students = d.students || []
  return (
    <>
      <div className="page-head">
        <div><span className="eyebrow">Coach workspace</span><h1>Welcome back, {user?.name?.split(' ')[0]}</h1><p>Your athletes, their records and the day’s activity — within the permissions set by the owner.</p></div>
        <Link to="/app/attendance" className="btn btn-primary">Mark attendance <ArrowRight size={15} /></Link>
      </div>
      <div className="grid g-4">
        <Kpi icon={Users} label="Athletes in scope" value={s.students ?? students.length} />
        <Kpi icon={Medal} label="Medals tracked" value={s.medals ?? (d.achievements || []).length} tone="violet" />
        <Kpi icon={CalendarCheck} label="Entries today" value={s.attendanceToday ?? 0} tone="teal" />
        <Kpi icon={Award} label="Sports handled" value={user?.sports?.length || '—'} tone="rose" />
      </div>
      <div className="grid g-21" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Athletes under your guidance</h3><p>View-only access by owner permission</p></div><Link to="/app/students" className="link tiny">Open directory</Link></div>
          <div className="table-wrap">
            <table><thead><tr><th>Athlete</th><th>Sport</th><th>Years</th><th>Achievements</th></tr></thead>
              <tbody>{students.slice(0, 8).map((st) => <tr key={st.id}><td><b>{st.name}</b><div className="faint tiny">{st.email}</div></td><td><Badge>{st.sport_name || st.sport}</Badge></td><td>{st.ongoing_years ?? '—'}</td><td>{st.medal_count ?? '—'}</td></tr>)}</tbody>
            </table>
          </div>
          {!students.length && <EmptyState text="No athletes are visible for your role yet." />}
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Announcement board</h3><p>From the academy owner</p></div></div>
          <div className="list">{(d.announcements || []).slice(0, 6).map((a) => <div className="list-row" key={a.id}><div className="notif-dot" /><div className="grow"><strong>{a.title}</strong><small>{String(a.body || a.message).slice(0, 95)}…</small></div></div>)}
            {!(d.announcements || []).length && <EmptyState text="No announcements yet." />}
          </div>
        </div>
      </div>
    </>
  )
}

function StudentOverview() {
  const { dashboard: d } = useApp()
  if (!d) return <div className="skeleton" />
  const p = d.profile || {}
  const pass = d.passport || {}
  const fees = d.fees || []
  const due = fees.filter((f) => Number(f.paid_amount || 0) < Number(f.amount || 0)).reduce((a, f) => a + (Number(f.amount) - Number(f.paid_amount || 0)), 0)
  const present = (d.attendance || []).filter((a) => a.event === 'entry').length
  const rate = (d.attendance || []).length ? Math.min(100, Math.round((present / ((d.attendance || []).length / 2 || 1)) * 100)) : 0

  return (
    <>
      <div className="page-head">
        <div><span className="eyebrow">My athlete journey</span><h1>Hello, {p.name?.split(' ')[0] || 'Champion'}</h1><p>Your passport, medals, attendance and fees — all in one place.</p></div>
        <Badge tone="warn"><Medal size={13} /> {p.sportName || p.sport_name || p.sport || 'Athlete'}</Badge>
      </div>

      <div className="glass passport">
        <div className="passport-head">
          <div className="passport-photo"><Trophy size={34} color="var(--gold)" /></div>
          <div style={{ flex: 1 }}>
            <span className="eyebrow">Athlete passport</span>
            <h2 className="h3" style={{ fontSize: '1.7rem', marginTop: '.4rem' }}>{p.name}</h2>
            <p className="muted" style={{ margin: '.3rem 0', fontSize: '.86rem' }}>{pass.id} · {p.sportName || p.sport_name || p.sport} · Coach {p.staffName || p.staff_name || '—'}</p>
            <div style={{ display: 'flex', gap: '.4rem', flexWrap: 'wrap' }}><Badge tone="good">Active athlete</Badge><Badge tone="warn">{p.ongoing_years || '—'} years at GSA</Badge></div>
          </div>
          <div className="ring-wrap" style={{ width: 110, height: 110 }}><RingProgress value={rate} label="Attendance" /></div>
        </div>
        <div className="passport-grid">
          {[['Joined', fmtDate(p.joined_date)], ['Academic year', p.academic_year], ['School', p.school_name], ['College', p.college_name || '—'], ['Category', p.category || 'Junior'], ['Medals', d.achievements?.length || 0]].map(([l, v]) => <div key={l}><small>{l}</small><b>{v}</b></div>)}
        </div>
      </div>

      <div className="grid g-3" style={{ marginTop: '1rem' }}>
        <Kpi icon={Medal} label="Medals & achievements" value={d.achievements?.length || 0} tone="violet" />
        <Kpi icon={Banknote} label="Fee due" value={fmtMoney(due)} tone="rose" />
        <Kpi icon={CalendarCheck} label="Attendance events" value={d.attendance?.length || 0} tone="teal" />
      </div>

      <div className="grid g-2" style={{ marginTop: '1rem' }}>
        <div className="glass card">
          <div className="card-head"><div><h3>Recent medals</h3><p>Your documented achievement record</p></div><Link className="link tiny" to="/app/achievements">All</Link></div>
          <div className="list">{(d.achievements || []).slice(0, 5).map((a) => <div className="list-row" key={a.id}><div className="avatar">{a.medal?.[0] || 'M'}</div><div className="grow"><strong>{a.title}</strong><small>{a.category1} · {a.category2} · {fmtDate(a.match_date)}</small></div><Badge tone={statusTone(a.medal)}>{a.medal}</Badge></div>)}
            {!(d.achievements || []).length && <EmptyState text="Your medal record will appear here." />}
          </div>
        </div>
        <div className="glass card">
          <div className="card-head"><div><h3>Announcements</h3><p>Messages from your academy</p></div></div>
          <div className="list">{(d.announcements || []).slice(0, 5).map((a) => <div className="list-row" key={a.id}><div className="notif-dot" /><div className="grow"><strong>{a.title}</strong><small>{String(a.body || a.message).slice(0, 110)}…</small></div></div>)}
            {!(d.announcements || []).length && <EmptyState text="No announcements yet." />}
          </div>
        </div>
      </div>
    </>
  )
}

export default function Overview() {
  const { user } = useApp()
  if (user?.role === 'staff') return <StaffOverview />
  if (user?.role === 'student') return <StudentOverview />
  return <OwnerOverview />
}
